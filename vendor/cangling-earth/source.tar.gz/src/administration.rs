//! China administrative labels and boundary paths, fetched as XYZ JSON.
//! A missing endpoint leaves the existing place-name layer intact.

use std::collections::{HashMap, HashSet, VecDeque};

#[cfg(not(target_arch = "wasm32"))]
use std::{thread, time::Duration};

use anyhow::{Context, Result};
use crossbeam_channel::{Receiver, Sender, unbounded};
use glam::{DVec3, Mat4, Vec2, Vec3};
use serde::Deserialize;
use serde_json::Value;
#[cfg(target_arch = "wasm32")]
use wasm_bindgen_futures::spawn_local;

use crate::{
    camera::OrbitCamera,
    geo,
    placenames::{LabelKind, Place, PlaceLabel, project_place, push_label, visible_tile_keys},
    terrain::TerrainLayer,
    tile::TileKey,
};

const PUBLIC_API: &str = "https://agri.cangling.cn:22002/cangling-map/api/admin/tiles";
#[cfg(target_arch = "wasm32")]
const PUBLIC_METADATA: &str = "https://agri.cangling.cn:22002/cangling-map/api/admin/metadata";
#[cfg(target_arch = "wasm32")]
const CACHE_PREFIX: &str = "cangling-admin-";
#[cfg(target_arch = "wasm32")]
const MAX_PERSISTENT_TILES: u32 = 2048;
const MAX_PENDING: usize = 8;
const MAX_RESIDENT: usize = 512;
const MAX_LABELS: usize = 90;
const MAX_TOWNSHIP_LABELS: usize = 48;
const RETRY_FRAMES: u64 = 900;

#[derive(Clone, Deserialize)]
struct AdminFeature {
    id: i64,
    name: String,
    longitude: f64,
    latitude: f64,
    admin_level: i64,
}

#[derive(Clone, Deserialize)]
struct Boundary {
    id: i64,
    geometry: Value,
}

#[derive(Deserialize)]
struct AdminTile {
    #[serde(default)]
    available: bool,
    features: Vec<AdminFeature>,
    boundaries: Vec<Boundary>,
    #[serde(default)]
    attribution: String,
}

#[cfg(target_arch = "wasm32")]
#[derive(Deserialize)]
struct AdminMetadata {
    dataset_revision: String,
}

struct TileResult {
    key: TileKey,
    result: Result<AdminTile>,
}

struct ResidentTile {
    tile: AdminTile,
    last_used: u64,
}

#[derive(Clone, Copy, PartialEq)]
struct ViewState {
    eye_m: DVec3,
    projection: Mat4,
    zoom: u8,
    viewport: (u32, u32),
}

pub struct Administration {
    loaded: HashMap<TileKey, ResidentTile>,
    pending: HashSet<TileKey>,
    retry_after: HashMap<TileKey, u64>,
    result_rx: Receiver<TileResult>,
    #[cfg(target_arch = "wasm32")]
    result_tx: Sender<TileResult>,
    #[cfg(target_arch = "wasm32")]
    revision_rx: Receiver<Result<String>>,
    #[cfg(target_arch = "wasm32")]
    revision_tx: Sender<Result<String>>,
    #[cfg(target_arch = "wasm32")]
    revision: Option<String>,
    #[cfg(target_arch = "wasm32")]
    revision_requested: bool,
    #[cfg(target_arch = "wasm32")]
    usage_rx: Receiver<Result<u64>>,
    #[cfg(target_arch = "wasm32")]
    usage_tx: Sender<Result<u64>>,
    #[cfg(target_arch = "wasm32")]
    usage_pending: bool,
    #[cfg(target_arch = "wasm32")]
    usage_bytes: Option<u64>,
    #[cfg(not(target_arch = "wasm32"))]
    request_tx: Sender<TileKey>,
    labels: Vec<PlaceLabel>,
    major_rings: Vec<Vec<[f64; 2]>>,
    minor_rings: Vec<Vec<[f64; 2]>>,
    boundary_bounds: Vec<[f64; 4]>,
    major_candidates: Vec<Place>,
    township_candidates: Vec<Place>,
    available: bool,
    attribution: String,
    frame: u64,
    last_view_state: Option<ViewState>,
}

impl Administration {
    /// Fade the finer tier in during the current emphasized boundary tier.
    /// The thresholds match select_zoom's zoom-in hysteresis: when the parent
    /// changes, the new child begins at 1% instead of inheriting the previous
    /// child's opacity.
    pub fn child_boundary_opacity(scale: f64, selected_zoom: u8) -> f32 {
        if (12..=14).contains(&selected_zoom) {
            return 0.2;
        }
        if !scale.is_finite() {
            return 0.01;
        }
        let (start, end) = match selected_zoom {
            0..=6 => (3.0, 6.25),      // country -> province
            7..=8 => (6.25, 8.25),     // province -> city
            9..=11 => (8.25, 11.25),   // city -> county
            12..=14 => (11.25, 14.25), // county -> township
            _ => (14.25, 15.25),       // township -> village
        };
        let progress = ((scale - start) / (end - start)).clamp(0.0, 1.0) as f32;
        let eased = progress * progress * (3.0 - 2.0 * progress);
        0.01 + 0.49 * eased
    }

    pub fn new() -> Self {
        let (result_tx, result_rx) = unbounded();
        #[cfg(target_arch = "wasm32")]
        let (revision_tx, revision_rx) = unbounded();
        #[cfg(target_arch = "wasm32")]
        let (usage_tx, usage_rx) = unbounded();
        #[cfg(not(target_arch = "wasm32"))]
        let request_tx = {
            let (request_tx, request_rx) = unbounded();
            let client = reqwest::blocking::Client::builder()
                .connect_timeout(Duration::from_secs(3))
                .timeout(Duration::from_secs(12))
                .user_agent("cangling-desktop/0.1 administration")
                .build()
                .expect("create administration client");
            let root =
                std::env::var("CANGLING_ADMIN_API_ROOT").unwrap_or_else(|_| PUBLIC_API.to_owned());
            for worker in 0..3 {
                let requests = request_rx.clone();
                let results = result_tx.clone();
                let client = client.clone();
                let root = root.clone();
                thread::Builder::new()
                    .name(format!("administration-{worker}"))
                    .spawn(move || {
                        for key in requests {
                            let result = client
                                .get(tile_url(&root, key))
                                .send()
                                .and_then(|response| response.error_for_status())
                                .and_then(|response| response.bytes())
                                .map_err(Into::into)
                                .and_then(|bytes| parse_tile(&bytes));
                            if results.send(TileResult { key, result }).is_err() {
                                break;
                            }
                        }
                    })
                    .expect("start administration worker");
            }
            request_tx
        };
        Self {
            loaded: HashMap::new(),
            pending: HashSet::new(),
            retry_after: HashMap::new(),
            result_rx,
            #[cfg(target_arch = "wasm32")]
            result_tx,
            #[cfg(target_arch = "wasm32")]
            revision_rx,
            #[cfg(target_arch = "wasm32")]
            revision_tx,
            #[cfg(target_arch = "wasm32")]
            revision: None,
            #[cfg(target_arch = "wasm32")]
            revision_requested: false,
            #[cfg(target_arch = "wasm32")]
            usage_rx,
            #[cfg(target_arch = "wasm32")]
            usage_tx,
            #[cfg(target_arch = "wasm32")]
            usage_pending: false,
            #[cfg(target_arch = "wasm32")]
            usage_bytes: None,
            #[cfg(not(target_arch = "wasm32"))]
            request_tx,
            labels: Vec::new(),
            major_rings: Vec::new(),
            minor_rings: Vec::new(),
            boundary_bounds: Vec::new(),
            major_candidates: Vec::new(),
            township_candidates: Vec::new(),
            available: false,
            attribution: String::new(),
            frame: 0,
            last_view_state: None,
        }
    }

    pub fn labels(&self) -> &[PlaceLabel] {
        &self.labels
    }

    pub fn major_rings(&self) -> &[Vec<[f64; 2]>] {
        &self.major_rings
    }

    pub fn minor_rings(&self) -> &[Vec<[f64; 2]>] {
        &self.minor_rings
    }

    pub fn has_data(&self) -> bool {
        self.available
    }

    pub fn attribution(&self) -> &str {
        &self.attribution
    }

    #[cfg(target_arch = "wasm32")]
    pub fn cache_usage_bytes(&self) -> Option<u64> {
        self.usage_bytes
    }

    /// Hysteresis around each integer threshold prevents a small drag or
    /// terrain-height update from changing the administrative boundary tier.
    pub fn select_zoom(previous: u8, scale: f64, country_mode: bool) -> u8 {
        if country_mode {
            return 3;
        }
        if !scale.is_finite() {
            return previous.clamp(4, 15);
        }
        let mut zoom = previous.clamp(4, 15);
        while zoom < 15 && scale > f64::from(zoom) + 0.25 {
            zoom += 1;
        }
        while zoom > 4 && scale < f64::from(zoom) - 1.25 {
            zoom -= 1;
        }
        zoom
    }

    pub fn update(
        &mut self,
        camera: &OrbitCamera,
        terrain: &TerrainLayer,
        visible_samples: &[Vec3],
        image_zoom: u8,
        viewport: (u32, u32),
        terrain_changed: &[TileKey],
    ) -> bool {
        self.frame += 1;
        let mut content_changed = false;
        #[cfg(target_arch = "wasm32")]
        self.update_web_cache_state();
        while let Ok(message) = self.result_rx.try_recv() {
            self.pending.remove(&message.key);
            match message.result {
                Ok(tile) if tile.available => {
                    content_changed = true;
                    self.retry_after.remove(&message.key);
                    if !tile.attribution.is_empty() {
                        self.attribution.clone_from(&tile.attribution);
                    }
                    self.loaded.insert(
                        message.key,
                        ResidentTile {
                            tile,
                            last_used: self.frame,
                        },
                    );
                }
                Ok(_) => {
                    self.retry_after
                        .insert(message.key, self.frame + RETRY_FRAMES);
                }
                Err(error) => {
                    log::warn!("admin tile {:?} failed: {error:#}", message.key);
                    self.retry_after
                        .insert(message.key, self.frame + RETRY_FRAMES);
                }
            }
        }

        let zoom = image_zoom.min(15);
        let (major_zoom, minor_zoom) = boundary_zoom_pair(zoom);
        let eye_m = camera.eye_m();
        let near_distance_m = visible_samples
            .iter()
            .map(|point| {
                (DVec3::new(point.x as f64, point.y as f64, point.z as f64) * geo::SEMI_MAJOR_M
                    - eye_m)
                    .length()
            })
            .reduce(f64::min)
            .unwrap_or(f64::INFINITY);
        let minor_samples: Vec<_> = visible_samples
            .iter()
            .copied()
            .filter(|point| {
                (DVec3::new(point.x as f64, point.y as f64, point.z as f64) * geo::SEMI_MAJOR_M
                    - eye_m)
                    .length()
                    <= near_distance_m * 3.2
            })
            .collect();
        for level_zoom in [major_zoom, minor_zoom] {
            let samples = if level_zoom == minor_zoom {
                &minor_samples
            } else {
                visible_samples
            };
            let desired = visible_tile_keys(samples, level_zoom);
            for &key in &desired {
                if let Some(tile) = self.loaded.get_mut(&key) {
                    tile.last_used = self.frame;
                } else if self.can_request()
                    && !self.pending.contains(&key)
                    && self.pending.len() < MAX_PENDING
                    && self
                        .retry_after
                        .get(&key)
                        .is_none_or(|&until| until <= self.frame)
                {
                    self.pending.insert(key);
                    self.request(key);
                }
            }
        }
        if self.loaded.len() > MAX_RESIDENT {
            let mut oldest: Vec<_> = self
                .loaded
                .iter()
                .map(|(&key, t)| (key, t.last_used))
                .collect();
            oldest.sort_by_key(|item| item.1);
            for (key, _) in oldest.into_iter().take(self.loaded.len() - MAX_RESIDENT) {
                self.loaded.remove(&key);
                content_changed = true;
            }
        }

        let view_state = ViewState {
            eye_m: camera.eye_m(),
            projection: camera.view_projection(),
            zoom,
            viewport,
        };
        let recent_tile_expired = self.loaded.iter().any(|(key, tile)| {
            (key.z == major_zoom || key.z == minor_zoom)
                && tile.last_used.saturating_add(121) == self.frame
        });
        let geometry_changed = content_changed
            || terrain_changed.iter().any(|&key| {
                self.boundary_bounds
                    .iter()
                    .any(|&bounds| tile_intersects_bounds(key, bounds))
            })
            || recent_tile_expired
            || self
                .last_view_state
                .is_none_or(|previous| previous.zoom != zoom);
        if !geometry_changed
            && terrain_changed.is_empty()
            && self.last_view_state == Some(view_state)
        {
            return false;
        }
        self.last_view_state = Some(view_state);
        if geometry_changed {
            self.major_rings.clear();
            self.minor_rings.clear();
            self.major_candidates.clear();
            self.township_candidates.clear();
            let show_townships = (12..=14).contains(&zoom);
            let major_available = collect_recent_layer(
                &self.loaded,
                self.frame,
                major_zoom,
                &mut self.major_rings,
                Some(&mut self.major_candidates),
            );
            let minor_available = collect_recent_layer(
                &self.loaded,
                self.frame,
                minor_zoom,
                &mut self.minor_rings,
                if show_townships {
                    Some(&mut self.township_candidates)
                } else {
                    None
                },
            );
            self.available = major_available || minor_available;
            self.boundary_bounds = self
                .major_rings
                .iter()
                .chain(&self.minor_rings)
                .map(|ring| ring_bounds(ring))
                .collect();
            self.major_candidates.sort_by_key(|place| place.id);
            self.township_candidates.sort_by_key(|place| place.id);
        }

        self.labels.clear();
        let mut occupied = Vec::new();
        let show_townships = (12..=14).contains(&zoom);
        // A recent tile can contain many western names. Reaching MAX_LABELS
        // while iterating tiles used to leave the eastern half without any
        // labels even though its boundaries and names were already loaded.
        for (group, child) in [
            (&self.major_candidates, false),
            (&self.township_candidates, true),
        ] {
            if child && !show_townships {
                continue;
            }
            let visible = group.iter().cloned().filter_map(|place| {
                project_place(camera, terrain, &place, viewport.0, viewport.1)
                    .map(|point| (point, place))
            });
            let limit = if child {
                (self.labels.len() + MAX_TOWNSHIP_LABELS).min(MAX_LABELS)
            } else if show_townships {
                MAX_LABELS - MAX_TOWNSHIP_LABELS / 2
            } else {
                MAX_LABELS
            };
            for place in balanced_screen_order(visible, viewport) {
                if self.labels.len() >= limit {
                    break;
                }
                if child && place.label_rank != 8 {
                    continue;
                }
                let kind = if child {
                    LabelKind::Township
                } else {
                    match place.label_rank {
                        2 => LabelKind::Country,
                        4 => LabelKind::Province,
                        _ => LabelKind::Region,
                    }
                };
                push_label(
                    &mut self.labels,
                    &mut occupied,
                    camera,
                    terrain,
                    &place,
                    kind,
                    viewport,
                );
            }
        }
        geometry_changed
    }

    fn request(&self, key: TileKey) {
        #[cfg(not(target_arch = "wasm32"))]
        if self.request_tx.send(key).is_err() {
            log::warn!("administration workers have stopped");
        }
        #[cfg(target_arch = "wasm32")]
        {
            let tx = self.result_tx.clone();
            let revision = self.revision.clone().unwrap_or_default();
            spawn_local(async move {
                let url = versioned_tile_url(PUBLIC_API, key, &revision);
                let cache_name = if revision.is_empty() {
                    String::new()
                } else {
                    format!("{CACHE_PREFIX}{revision}")
                };
                let result = crate::web_cache::fetch_bytes(&url, &cache_name)
                    .await
                    .and_then(|(bytes, _)| parse_tile(&bytes));
                let _ = tx.send(TileResult { key, result });
            });
        }
    }

    fn can_request(&self) -> bool {
        #[cfg(target_arch = "wasm32")]
        {
            self.revision.is_some()
        }
        #[cfg(not(target_arch = "wasm32"))]
        {
            true
        }
    }

    #[cfg(target_arch = "wasm32")]
    fn update_web_cache_state(&mut self) {
        if !self.revision_requested {
            self.revision_requested = true;
            let tx = self.revision_tx.clone();
            spawn_local(async move {
                let result = crate::web_cache::fetch_bytes(PUBLIC_METADATA, "")
                    .await
                    .and_then(|(bytes, _)| {
                        let metadata: AdminMetadata = serde_json::from_slice(&bytes)?;
                        if metadata.dataset_revision.len() != 64
                            || !metadata
                                .dataset_revision
                                .bytes()
                                .all(|byte| byte.is_ascii_hexdigit())
                        {
                            anyhow::bail!("invalid administration dataset revision");
                        }
                        Ok(metadata.dataset_revision)
                    });
                let _ = tx.send(result);
            });
        }
        while let Ok(result) = self.revision_rx.try_recv() {
            let revision = match result {
                Ok(revision) => revision,
                Err(error) => {
                    log::warn!("admin metadata failed; using live uncached tiles: {error:#}");
                    String::new()
                }
            };
            if !revision.is_empty() {
                let keep = format!("{CACHE_PREFIX}{revision}");
                spawn_local(async move {
                    let _ = crate::web_cache::delete_old_caches(CACHE_PREFIX, &keep).await;
                });
            }
            self.revision = Some(revision);
        }
        while let Ok(result) = self.usage_rx.try_recv() {
            self.usage_pending = false;
            if let Ok(bytes) = result {
                self.usage_bytes = Some(bytes);
            }
        }
        if !self.usage_pending && self.frame % 300 == 1 {
            self.usage_pending = true;
            let tx = self.usage_tx.clone();
            let cache_name = self
                .revision
                .as_deref()
                .filter(|revision| !revision.is_empty())
                .map(|revision| format!("{CACHE_PREFIX}{revision}"));
            spawn_local(async move {
                if let Some(cache_name) = cache_name {
                    let _ = crate::web_cache::trim_cache(&cache_name, MAX_PERSISTENT_TILES).await;
                }
                let _ = tx.send(crate::web_cache::storage_usage_bytes().await);
            });
        }
    }
}

fn ring_bounds(ring: &[[f64; 2]]) -> [f64; 4] {
    ring.iter().fold(
        [
            f64::INFINITY,
            f64::INFINITY,
            f64::NEG_INFINITY,
            f64::NEG_INFINITY,
        ],
        |bounds, coord| {
            [
                bounds[0].min(coord[0]),
                bounds[1].min(coord[1]),
                bounds[2].max(coord[0]),
                bounds[3].max(coord[1]),
            ]
        },
    )
}

fn tile_intersects_bounds(tile: TileKey, bounds: [f64; 4]) -> bool {
    if !bounds[0].is_finite() {
        return false;
    }
    let count = (1_u32 << tile.z.min(30)) as f64;
    let west = tile.x as f64 / count * 360.0 - 180.0;
    let east = (tile.x as f64 + 1.0) / count * 360.0 - 180.0;
    let latitude = |y: f64| {
        ((std::f64::consts::PI * (1.0 - 2.0 * y / count)).sinh())
            .atan()
            .to_degrees()
    };
    let north = latitude(tile.y as f64);
    let south = latitude(tile.y as f64 + 1.0);
    bounds[0] <= east && bounds[2] >= west && bounds[1] <= north && bounds[3] >= south
}

/// The stronger boundary is the parent tier; the finer tier supplies the
/// translucent detail. At globe scale both country and province are shown.
fn boundary_zoom_pair(zoom: u8) -> (u8, u8) {
    match zoom {
        0..=3 => (3, 4),
        4..=6 => (3, zoom),
        7..=8 => (6, zoom),
        9..=11 => (8, zoom),
        12..=14 => (11, zoom),
        _ => (14, zoom.min(15)),
    }
}

fn collect_recent_layer(
    loaded: &HashMap<TileKey, ResidentTile>,
    frame: u64,
    zoom: u8,
    rings: &mut Vec<Vec<[f64; 2]>>,
    mut labels: Option<&mut Vec<Place>>,
) -> bool {
    let mut recent: Vec<_> = loaded
        .iter()
        .filter(|(key, tile)| key.z == zoom && tile.last_used.saturating_add(120) >= frame)
        .map(|(&key, tile)| (key, tile.last_used))
        .collect();
    recent.sort_by_key(|(key, used)| (std::cmp::Reverse(*used), key.x, key.y));
    let mut seen_boundaries = HashSet::new();
    let mut seen_labels = HashSet::new();
    for (key, _) in &recent {
        let resident = &loaded[key];
        if let Some(candidates) = labels.as_mut() {
            for feature in &resident.tile.features {
                if seen_labels.insert(feature.id) {
                    candidates.push(Place {
                        id: feature.id,
                        name: feature.name.clone(),
                        longitude: feature.longitude,
                        latitude: feature.latitude,
                        label_rank: feature.admin_level,
                        min_zoom: 0.0,
                        population: None,
                    });
                }
            }
        }
        for boundary in &resident.tile.boundaries {
            if seen_boundaries.insert(boundary.id) {
                append_rings(&boundary.geometry, rings);
            }
        }
    }
    !recent.is_empty()
}

fn balanced_screen_order<T>(
    items: impl IntoIterator<Item = (Vec2, T)>,
    (width, height): (u32, u32),
) -> Vec<T> {
    const COLUMNS: usize = 6;
    const ROWS: usize = 4;
    let mut cells: [VecDeque<T>; COLUMNS * ROWS] = std::array::from_fn(|_| VecDeque::new());
    let mut remaining = 0;
    for (point, item) in items {
        let column = ((point.x / width.max(1) as f32 * COLUMNS as f32) as usize).min(COLUMNS - 1);
        let row = ((point.y / height.max(1) as f32 * ROWS as f32) as usize).min(ROWS - 1);
        cells[row * COLUMNS + column].push_back(item);
        remaining += 1;
    }
    let mut ordered = Vec::with_capacity(remaining);
    while remaining > 0 {
        for cell in &mut cells {
            if let Some(item) = cell.pop_front() {
                ordered.push(item);
                remaining -= 1;
            }
        }
    }
    ordered
}

fn tile_url(root: &str, key: TileKey) -> String {
    format!("{root}/{}/{}/{}?lang=zh", key.z, key.x, key.y)
}

#[cfg(target_arch = "wasm32")]
fn versioned_tile_url(root: &str, key: TileKey, revision: &str) -> String {
    let url = tile_url(root, key);
    if revision.is_empty() {
        url
    } else {
        format!("{url}&revision={revision}")
    }
}

fn parse_tile(bytes: &[u8]) -> Result<AdminTile> {
    serde_json::from_slice(bytes).context("decode administrative JSON tile")
}

fn append_rings(geometry: &Value, output: &mut Vec<Vec<[f64; 2]>>) {
    let Some(coordinates) = geometry.get("coordinates").and_then(Value::as_array) else {
        return;
    };
    let geometry_type = geometry.get("type").and_then(Value::as_str);
    let paths: Vec<&Value> = match geometry_type {
        Some("LineString") => vec![geometry.get("coordinates").unwrap()],
        Some("MultiLineString") | Some("Polygon") => coordinates.iter().collect(),
        Some("MultiPolygon") => coordinates
            .iter()
            .filter_map(Value::as_array)
            .flatten()
            .collect(),
        _ => return,
    };
    for path in paths {
        let Some(points) = path.as_array() else {
            continue;
        };
        let parsed: Vec<_> = points
            .iter()
            .filter_map(|point| {
                let pair = point.as_array()?;
                Some([pair.first()?.as_f64()?, pair.get(1)?.as_f64()?])
            })
            .collect();
        if parsed.len() >= 2 {
            output.push(parsed);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use winit::dpi::PhysicalSize;

    #[test]
    fn unchanged_view_reuses_administrative_geometry() {
        let mut administration = Administration::new();
        let camera = OrbitCamera::new(PhysicalSize::new(800, 600));
        let terrain = TerrainLayer::new();
        let update = |administration: &mut Administration, zoom, terrain_changed: &[TileKey]| {
            administration.update(&camera, &terrain, &[], zoom, (800, 600), terrain_changed)
        };
        assert!(update(&mut administration, 3, &[]));
        assert!(!update(&mut administration, 3, &[]));
        assert!(update(&mut administration, 4, &[]));
    }

    #[test]
    fn unrelated_dem_tile_does_not_rebuild_boundaries() {
        let mut administration = Administration::new();
        let camera = OrbitCamera::new(PhysicalSize::new(800, 600));
        let terrain = TerrainLayer::new();
        assert!(administration.update(&camera, &terrain, &[], 3, (800, 600), &[]));
        administration
            .boundary_bounds
            .push([108.0, 33.0, 110.0, 35.0]);
        let far = TileKey { z: 5, x: 2, y: 2 };
        let near = TileKey { z: 5, x: 25, y: 12 };
        assert!(!tile_intersects_bounds(
            far,
            administration.boundary_bounds[0]
        ));
        assert!(!administration.update(&camera, &terrain, &[], 3, (800, 600), &[far]));
        assert!(tile_intersects_bounds(
            near,
            administration.boundary_bounds[0]
        ));
        assert!(administration.update(&camera, &terrain, &[], 3, (800, 600), &[near]));
    }

    #[test]
    fn parses_polygon_and_multipolygon_rings() {
        let mut rings = Vec::new();
        append_rings(
            &serde_json::json!({"type":"MultiPolygon","coordinates":[
                [[[100.0,30.0],[101.0,30.0],[100.0,30.0]]]
            ]}),
            &mut rings,
        );
        assert_eq!(
            rings,
            vec![vec![[100.0, 30.0], [101.0, 30.0], [100.0, 30.0]]]
        );
    }

    #[test]
    fn parses_disconnected_south_china_sea_dashes() {
        let mut paths = Vec::new();
        append_rings(
            &serde_json::json!({"type":"MultiLineString","coordinates":[
                [[110.0,12.0],[110.2,11.8]],[[120.0,20.0],[120.3,19.8]]
            ]}),
            &mut paths,
        );
        assert_eq!(paths.len(), 2);
        assert_eq!(paths[1], vec![[120.0, 20.0], [120.3, 19.8]]);
    }

    #[test]
    fn tile_url_uses_selected_endpoint() {
        assert_eq!(
            tile_url(
                "http://127.0.0.1:14002/api/admin/tiles",
                TileKey {
                    z: 12,
                    x: 3372,
                    y: 1552
                }
            ),
            "http://127.0.0.1:14002/api/admin/tiles/12/3372/1552?lang=zh"
        );
    }

    #[test]
    fn label_budget_reaches_sparse_screen_regions() {
        let dense_left = (0..100).map(|id| (Vec2::new(40.0, 100.0), id));
        let sparse_right = [(Vec2::new(1100.0, 100.0), 100)];
        let ordered = balanced_screen_order(dense_left.chain(sparse_right), (1200, 800));
        assert_eq!(ordered.len(), 101);
        assert!(ordered[..MAX_LABELS].contains(&100));
    }

    #[test]
    fn administrative_zoom_holds_around_a_tier_boundary() {
        assert_eq!(Administration::select_zoom(8, 8.10, false), 8);
        assert_eq!(Administration::select_zoom(8, 8.26, false), 9);
        assert_eq!(Administration::select_zoom(9, 8.10, false), 9);
        assert_eq!(Administration::select_zoom(9, 7.74, false), 8);
        assert_eq!(Administration::select_zoom(9, 8.10, true), 3);
    }

    #[test]
    fn boundary_pairs_keep_parent_lines_and_add_one_finer_tier() {
        assert_eq!(boundary_zoom_pair(3), (3, 4));
        assert_eq!(boundary_zoom_pair(5), (3, 5));
        assert_eq!(boundary_zoom_pair(7), (6, 7));
        assert_eq!(boundary_zoom_pair(9), (8, 9));
        assert_eq!(boundary_zoom_pair(12), (11, 12));
        assert_eq!(boundary_zoom_pair(15), (14, 15));
    }

    #[test]
    fn emphasized_level_supplies_labels() {
        let mut loaded = HashMap::new();
        for (zoom, id) in [(6, 10), (7, 20)] {
            loaded.insert(
                TileKey {
                    z: zoom,
                    x: 0,
                    y: 0,
                },
                ResidentTile {
                    tile: AdminTile {
                        available: true,
                        features: vec![AdminFeature {
                            id,
                            name: format!("region-{id}"),
                            longitude: 110.0,
                            latitude: 34.0,
                            admin_level: 4,
                        }],
                        boundaries: vec![],
                        attribution: String::new(),
                    },
                    last_used: 1,
                },
            );
        }
        let mut major_rings = Vec::new();
        let mut minor_rings = Vec::new();
        let mut candidates = Vec::new();
        collect_recent_layer(&loaded, 1, 6, &mut major_rings, Some(&mut candidates));
        collect_recent_layer(&loaded, 1, 7, &mut minor_rings, None);
        assert_eq!(
            candidates.iter().map(|place| place.id).collect::<Vec<_>>(),
            vec![10]
        );
    }

    #[test]
    fn child_opacity_restarts_when_the_emphasized_tier_changes() {
        let alpha = Administration::child_boundary_opacity;
        assert!((alpha(6.25, 6) - 0.5).abs() < 1e-6);
        assert!((alpha(6.25, 7) - 0.01).abs() < 1e-6);
        assert!((alpha(7.25, 7) - 0.255).abs() < 1e-6);
        assert!((alpha(8.25, 8) - 0.5).abs() < 1e-6);
        assert!((alpha(8.25, 9) - 0.01).abs() < 1e-6);
        assert_eq!(alpha(11.25, 12), 0.2);
        assert_eq!(alpha(12.5, 12), 0.2);
        assert_eq!(alpha(14.0, 14), 0.2);
        assert!((alpha(14.25, 15) - 0.01).abs() < 1e-6);
        assert_eq!(alpha(-10.0, 7), 0.01);
        assert_eq!(alpha(f64::NAN, 7), 0.01);
        assert!((alpha(100.0, 15) - 0.5).abs() < 1e-6);
    }
}
