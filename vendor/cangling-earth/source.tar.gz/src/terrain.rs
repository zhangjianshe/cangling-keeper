//! Versioned Terrarium DEM tiles from the Cangling terrain service.
//! ETOPO 2022 covers the globe; Copernicus GLO-30 refines China. Both
//! published datasets report EGM2008 orthometric heights in metres.

use std::{
    collections::{HashMap, HashSet},
    io::Cursor,
    sync::{Arc, RwLock},
};

#[cfg(target_arch = "wasm32")]
use std::{cell::Cell, rc::Rc};
#[cfg(not(target_arch = "wasm32"))]
use std::{fs, path::PathBuf, thread, time::Duration};

use anyhow::{Context, Result, anyhow, ensure};
use crossbeam_channel::{Receiver, Sender, unbounded};
use image::ImageReader;
use serde::Deserialize;
#[cfg(target_arch = "wasm32")]
use wasm_bindgen_futures::spawn_local;

use crate::{geo, tile::TileKey};

const TERRAIN_ORIGIN: &str = "https://agri.cangling.cn:22002";
const GLOBAL_MAX_LEVEL: u8 = 8; // ETOPO 2022 is 60 arc-second source data.
const CHINA_MIN_LEVEL: u8 = 8;
const CHINA_MAX_LEVEL: u8 = 12; // About 40 m/texel; avoid oversampling GLO-30.
const MAX_NEEDED: usize = 160;
const MAX_RESIDENT: usize = 256;
const MAX_RESULTS_PER_FRAME: usize = 4;
#[cfg(target_arch = "wasm32")]
const WEB_MAX_IN_FLIGHT: usize = 4;

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
enum SourceId {
    Global,
    China,
}

impl SourceId {
    fn dataset(self) -> &'static str {
        match self {
            Self::Global => "global-etopo2022",
            Self::China => "china-cop30",
        }
    }

    fn min_level(self) -> u8 {
        match self {
            Self::Global => 0,
            Self::China => CHINA_MIN_LEVEL,
        }
    }

    fn max_level(self) -> u8 {
        match self {
            Self::Global => GLOBAL_MAX_LEVEL,
            Self::China => CHINA_MAX_LEVEL,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
struct TerrainKey {
    source: SourceId,
    tile: TileKey,
}

#[derive(Clone)]
struct TerrainSource {
    bounds: [f64; 4], // west, south, east, north in degrees
    tile_url: String,
    revision: String,
    max_level: u8,
}

impl TerrainSource {
    fn contains(&self, latitude: f64, longitude: f64) -> bool {
        let lat = latitude.to_degrees();
        let lon = longitude.to_degrees();
        lon >= self.bounds[0]
            && lon <= self.bounds[2]
            && lat >= self.bounds[1]
            && lat <= self.bounds[3]
    }

    fn url(&self, tile: TileKey) -> String {
        self.tile_url
            .replace("{z}", &tile.z.to_string())
            .replace("{x}", &tile.x.to_string())
            .replace("{y}", &tile.y.to_string())
    }
}

#[derive(Deserialize)]
#[serde(rename_all = "camelCase")]
struct TerrainMetadata {
    bounds_wgs84: [f64; 4],
    dataset: DatasetMetadata,
    encoding: String,
    nodata: [u8; 3],
    tile_matrix_set: String,
    tile_size: u32,
    tile_url: String,
    unit: String,
}

#[derive(Deserialize)]
#[serde(rename_all = "snake_case")]
struct DatasetMetadata {
    revision: String,
    max_zoom: u8,
    vertical_datum: String,
}

fn parse_source(id: SourceId, bytes: &[u8]) -> Result<TerrainSource> {
    let metadata: TerrainMetadata = serde_json::from_slice(bytes)?;
    ensure!(metadata.encoding == "terrarium", "unsupported DEM encoding");
    ensure!(
        metadata.tile_matrix_set == "WebMercatorQuad",
        "unsupported tile matrix"
    );
    ensure!(metadata.tile_size == 256, "unsupported DEM tile size");
    ensure!(metadata.unit == "metre", "unsupported elevation unit");
    ensure!(metadata.nodata == [0, 0, 0], "unsupported DEM NoData value");
    ensure!(
        metadata.dataset.vertical_datum == "EGM2008",
        "unexpected vertical datum"
    );
    ensure!(
        metadata.dataset.revision.len() == 64
            && metadata
                .dataset
                .revision
                .bytes()
                .all(|b| b.is_ascii_hexdigit()),
        "invalid DEM revision"
    );
    let expected_path = format!(
        "/api/terrain/{}/tiles/{}/{{z}}/{{x}}/{{y}}",
        id.dataset(),
        metadata.dataset.revision
    );
    ensure!(
        metadata.tile_url == expected_path,
        "unexpected DEM tile URL"
    );
    Ok(TerrainSource {
        bounds: metadata.bounds_wgs84,
        tile_url: format!("{TERRAIN_ORIGIN}{}", metadata.tile_url),
        revision: metadata.dataset.revision,
        max_level: metadata.dataset.max_zoom.min(id.max_level()),
    })
}

fn metadata_url(id: SourceId) -> String {
    format!("{TERRAIN_ORIGIN}/api/terrain/{}/metadata", id.dataset())
}

#[derive(Clone)]
struct HeightTile {
    metres: Vec<f32>,
}

#[derive(Clone)]
struct TerrainRequest {
    key: TerrainKey,
    url: String,
    #[cfg(not(target_arch = "wasm32"))]
    revision: String,
}

struct TerrainResult {
    key: TerrainKey,
    result: Result<HeightTile>,
    cache_hit: bool,
    cancelled: bool,
}

#[derive(Clone, Copy, Default)]
#[allow(dead_code)]
pub struct TerrainStats {
    pub base_ready: bool,
    pub loaded: usize,
    pub pending: usize,
    pub downloaded: usize,
    pub cache_hits: usize,
    pub failed: usize,
    pub target_level: u8,
}

pub struct TerrainLayer {
    sender: Sender<TerrainRequest>,
    receiver: Receiver<TerrainResult>,
    metadata_receiver: Receiver<(SourceId, Result<TerrainSource>)>,
    sources: HashMap<SourceId, TerrainSource>,
    wanted: Arc<RwLock<HashSet<TerrainKey>>>,
    #[cfg(target_arch = "wasm32")]
    web_loader: WebTerrainLoader,
    loaded: HashMap<TerrainKey, HeightTile>,
    pending: HashSet<TerrainKey>,
    retry_after: HashMap<TerrainKey, u64>,
    failure_count: usize,
    last_used: HashMap<TerrainKey, u64>,
    frame: u64,
    downloaded: usize,
    cache_hits: usize,
    target_level: u8,
    base_ready: bool,
}

impl TerrainLayer {
    pub fn new() -> Self {
        let (sender, requests) = unbounded();
        let (results, receiver) = unbounded();
        let (metadata_sender, metadata_receiver) = unbounded();
        let wanted = Arc::new(RwLock::new(HashSet::new()));
        #[cfg(not(target_arch = "wasm32"))]
        {
            for number in 0..2 {
                let requests = requests.clone();
                let results = results.clone();
                let wanted = wanted.clone();
                thread::Builder::new()
                    .name(format!("terrain-loader-{number}"))
                    .spawn(move || terrain_worker(requests, results, wanted))
                    .expect("spawn terrain loader");
            }
            thread::Builder::new()
                .name("terrain-metadata".into())
                .spawn(move || {
                    for id in [SourceId::Global, SourceId::China] {
                        let _ = metadata_sender.send((id, load_source_metadata(id)));
                    }
                })
                .expect("spawn terrain metadata loader");
        }
        #[cfg(target_arch = "wasm32")]
        {
            spawn_local(async move {
                for id in [SourceId::Global, SourceId::China] {
                    let result = crate::web_cache::fetch_bytes(&metadata_url(id), "")
                        .await
                        .and_then(|(bytes, _)| parse_source(id, &bytes));
                    let _ = metadata_sender.send((id, result));
                }
            });
        }
        #[cfg(target_arch = "wasm32")]
        let web_loader = WebTerrainLoader {
            requests,
            results,
            wanted: wanted.clone(),
            active_fetches: Rc::new(Cell::new(0)),
        };
        Self {
            sender,
            receiver,
            metadata_receiver,
            sources: HashMap::new(),
            wanted,
            #[cfg(target_arch = "wasm32")]
            web_loader,
            loaded: HashMap::new(),
            pending: HashSet::new(),
            retry_after: HashMap::new(),
            failure_count: 0,
            last_used: HashMap::new(),
            frame: 0,
            downloaded: 0,
            cache_hits: 0,
            target_level: 0,
            base_ready: false,
        }
    }

    /// Return DEM tile coordinates whose imagery meshes need rebuilding.
    pub fn update(&mut self, visible_samples: &[glam::Vec3], desired_level: u8) -> Vec<TileKey> {
        self.frame = self.frame.wrapping_add(1);
        for (id, result) in self.metadata_receiver.try_iter() {
            match result {
                Ok(source) => {
                    log::info!("{} DEM revision {} ready", id.dataset(), source.revision);
                    self.sources.insert(id, source);
                }
                Err(error) => log::warn!("{} DEM metadata failed: {error:#}", id.dataset()),
            }
        }
        let previous_level = self.target_level;
        self.target_level = desired_level.min(CHINA_MAX_LEVEL);
        let mut wanted = HashSet::new();
        let mut priority = Vec::new();
        if self.sources.contains_key(&SourceId::Global) {
            let base = TerrainKey {
                source: SourceId::Global,
                tile: TileKey { z: 0, x: 0, y: 0 },
            };
            wanted.insert(base);
            priority.push(base);
        }
        let positions: Vec<_> = visible_samples
            .iter()
            .map(|point| {
                let position = glam::DVec3::new(point.x as f64, point.y as f64, point.z as f64)
                    * geo::SEMI_MAJOR_M;
                geo::geodetic_lat_lon(position)
            })
            .collect();
        // Cover the whole view at coarse levels before spending the budget on
        // detail. Reserve space for China's refinement, then fill unused
        // capacity with more global ETOPO tiles.
        for (id, budget) in [
            (SourceId::Global, 64),
            (SourceId::China, MAX_NEEDED),
            (SourceId::Global, MAX_NEEDED),
        ] {
            let Some(source) = self.sources.get(&id) else {
                continue;
            };
            if self.target_level < id.min_level() {
                continue;
            }
            for z in id.min_level()..=self.target_level.min(source.max_level) {
                for &(lat, lon) in &positions {
                    if wanted.len() >= budget {
                        break;
                    }
                    if !source.contains(lat, lon) {
                        continue;
                    }
                    let key = TerrainKey {
                        source: id,
                        tile: lat_lon_tile(lat, lon, z),
                    };
                    if wanted.insert(key) {
                        priority.push(key);
                    }
                }
                if wanted.len() >= budget {
                    break;
                }
            }
        }
        *self.wanted.write().expect("terrain wanted lock poisoned") = wanted.clone();
        for key in priority {
            self.last_used.insert(key, self.frame);
            if !self.loaded.contains_key(&key)
                && self
                    .retry_after
                    .get(&key)
                    .is_none_or(|frame| self.frame >= *frame)
                && self.pending.insert(key)
            {
                let source = &self.sources[&key.source];
                let _ = self.sender.send(TerrainRequest {
                    key,
                    url: source.url(key.tile),
                    #[cfg(not(target_arch = "wasm32"))]
                    revision: source.revision.clone(),
                });
            }
        }
        #[cfg(target_arch = "wasm32")]
        self.web_loader.pump();
        let mut dirty = if previous_level != self.target_level {
            self.loaded.keys().map(|key| key.tile).collect()
        } else {
            Vec::new()
        };
        for _ in 0..MAX_RESULTS_PER_FRAME {
            let Ok(result) = self.receiver.try_recv() else {
                break;
            };
            self.pending.remove(&result.key);
            if result.cancelled || !wanted.contains(&result.key) {
                continue;
            }
            match result.result {
                Ok(tile) => {
                    self.retry_after.remove(&result.key);
                    if result.cache_hit {
                        self.cache_hits += 1;
                    } else {
                        self.downloaded += 1;
                    }
                    self.loaded.insert(result.key, tile);
                    self.last_used.insert(result.key, self.frame);
                    dirty.push(result.key.tile);
                }
                Err(error) => {
                    self.failure_count += 1;
                    self.retry_after.insert(result.key, self.frame + 600);
                    log::warn!("terrain tile {:?} failed: {error:#}", result.key);
                }
            }
        }
        let base = TerrainKey {
            source: SourceId::Global,
            tile: TileKey { z: 0, x: 0, y: 0 },
        };
        if !self.base_ready && self.loaded.contains_key(&base) {
            self.base_ready = true;
            dirty.extend(self.loaded.keys().map(|key| key.tile));
            log::info!("global DEM base ready");
        }
        if self.loaded.len() > MAX_RESIDENT {
            let mut old: Vec<_> = self
                .loaded
                .keys()
                .copied()
                .filter(|key| key.tile.z > 0)
                .collect();
            old.sort_by_key(|key| self.last_used.get(key).copied().unwrap_or(0));
            for key in old.into_iter().take(self.loaded.len() - MAX_RESIDENT) {
                self.loaded.remove(&key);
                self.last_used.remove(&key);
                dirty.push(key.tile);
            }
        }
        dirty
    }

    #[allow(dead_code)]
    pub fn stats(&self) -> TerrainStats {
        TerrainStats {
            base_ready: self.base_ready,
            loaded: self.loaded.len(),
            pending: self.pending.len(),
            downloaded: self.downloaded,
            cache_hits: self.cache_hits,
            failed: self.failure_count,
            target_level: self.target_level,
        }
    }

    /// Bilinear sample across tile boundaries; China overrides ETOPO where
    /// valid. An edge blend hides the abrupt difference between DEM sources.
    pub fn sample(&self, latitude: f64, longitude: f64) -> f64 {
        if !self.base_ready {
            return 0.0;
        }
        // ETOPO includes negative ocean-floor bathymetry. Imagery shows the
        // water surface, so keep that surface at sea level for now.
        let global = self
            .sample_source(SourceId::Global, latitude, longitude)
            .unwrap_or(0.0)
            .max(0.0);
        let Some(china) = self.sources.get(&SourceId::China) else {
            return global;
        };
        if !china.contains(latitude, longitude) {
            return global;
        }
        let Some(fine) = self.sample_source(SourceId::China, latitude, longitude) else {
            return global;
        };
        let lat = latitude.to_degrees();
        let lon = longitude.to_degrees();
        let weight = ((lon - china.bounds[0]) / 0.1)
            .min((china.bounds[2] - lon) / 0.1)
            .min((lat - china.bounds[1]) / 0.1)
            .min((china.bounds[3] - lat) / 0.1)
            .clamp(0.0, 1.0);
        global * (1.0 - weight) + fine * weight
    }

    fn sample_source(&self, id: SourceId, latitude: f64, longitude: f64) -> Option<f64> {
        let source = self.sources.get(&id)?;
        if !source.contains(latitude, longitude) || self.target_level < id.min_level() {
            return None;
        }
        for z in (id.min_level()..=self.target_level.min(source.max_level)).rev() {
            if let Some(height) = self.sample_level(id, latitude, longitude, z) {
                if z > id.min_level() {
                    let scale = (1_u32 << z) as f64 * 256.0;
                    let x = ((longitude / std::f64::consts::TAU + 0.5) * scale).rem_euclid(256.0);
                    let mercator = (latitude.tan() + 1.0 / latitude.cos()).ln();
                    let y =
                        ((1.0 - mercator / std::f64::consts::PI) * 0.5 * scale).rem_euclid(256.0);
                    let edge = x.min(256.0 - x).min(y.min(256.0 - y));
                    let weight = (edge / 2.0).clamp(0.0, 1.0);
                    if weight < 1.0
                        && let Some(parent) = self.sample_level(id, latitude, longitude, z - 1)
                    {
                        return Some(parent * (1.0 - weight) + height * weight);
                    }
                }
                return Some(height);
            }
        }
        None
    }

    fn sample_level(&self, id: SourceId, latitude: f64, longitude: f64, z: u8) -> Option<f64> {
        let pixels = (1_u32 << z) as f64 * 256.0;
        let px = (longitude / std::f64::consts::TAU + 0.5) * pixels - 0.5;
        let mercator = (latitude.tan() + 1.0 / latitude.cos()).ln();
        let py = (1.0 - mercator / std::f64::consts::PI) * 0.5 * pixels - 0.5;
        let ix = px.floor() as i64;
        let iy = py.floor() as i64;
        let fx = px - ix as f64;
        let fy = py - iy as f64;
        let a = self.pixel(id, z, ix, iy)?;
        let b = self.pixel(id, z, ix + 1, iy)?;
        let c = self.pixel(id, z, ix, iy + 1)?;
        let d = self.pixel(id, z, ix + 1, iy + 1)?;
        Some(
            ((a * (1.0 - fx) + b * fx) * (1.0 - fy) + (c * (1.0 - fx) + d * fx) * fy)
                .clamp(-11_000.0, 9_000.0),
        )
    }

    fn pixel(&self, id: SourceId, z: u8, px: i64, py: i64) -> Option<f64> {
        let world_pixels = (1_i64 << z) * 256;
        let px = px.rem_euclid(world_pixels);
        let py = py.clamp(0, world_pixels - 1);
        let key = TerrainKey {
            source: id,
            tile: TileKey {
                z,
                x: (px / 256) as u32,
                y: (py / 256) as u32,
            },
        };
        let tile = self.loaded.get(&key)?;
        let height = tile.metres[(py % 256) as usize * 256 + (px % 256) as usize] as f64;
        height.is_finite().then_some(height)
    }

    pub fn needs_skirt(&self, key: TileKey) -> bool {
        key.z >= 2
    }
}

fn lat_lon_tile(latitude: f64, longitude: f64, z: u8) -> TileKey {
    let width = (1_u32 << z) as f64;
    let x = ((longitude / std::f64::consts::TAU + 0.5) * width)
        .floor()
        .clamp(0.0, width - 1.0) as u32;
    let mercator = (latitude.tan() + 1.0 / latitude.cos()).ln();
    let y = ((1.0 - mercator / std::f64::consts::PI) * 0.5 * width)
        .floor()
        .clamp(0.0, width - 1.0) as u32;
    TileKey { z, x, y }
}

#[cfg(target_arch = "wasm32")]
struct WebTerrainLoader {
    requests: Receiver<TerrainRequest>,
    results: Sender<TerrainResult>,
    wanted: Arc<RwLock<HashSet<TerrainKey>>>,
    active_fetches: Rc<Cell<usize>>,
}

#[cfg(target_arch = "wasm32")]
impl WebTerrainLoader {
    fn pump(&self) {
        while self.active_fetches.get() < WEB_MAX_IN_FLIGHT {
            let Ok(request) = self.requests.try_recv() else {
                break;
            };
            let key = request.key;
            if !self
                .wanted
                .read()
                .expect("terrain wanted lock poisoned")
                .contains(&key)
            {
                let _ = self.results.send(TerrainResult {
                    key,
                    result: Err(anyhow!("terrain request cancelled")),
                    cache_hit: false,
                    cancelled: true,
                });
                continue;
            }
            self.active_fetches.set(self.active_fetches.get() + 1);
            let wanted = self.wanted.clone();
            let active = self.active_fetches.clone();
            let results = self.results.clone();
            spawn_local(async move {
                let loaded = crate::web_cache::fetch_bytes(&request.url, "cangling-terrain-v2")
                    .await
                    .and_then(|(bytes, hit)| {
                        decode_height_tile_bytes(bytes).map(|tile| (tile, hit))
                    });
                let still_needed = wanted
                    .read()
                    .expect("terrain wanted lock poisoned")
                    .contains(&key);
                let (result, cache_hit) = match loaded {
                    Ok((tile, hit)) => (Ok(tile), hit),
                    Err(error) => (Err(error), false),
                };
                let _ = results.send(TerrainResult {
                    key,
                    result,
                    cache_hit,
                    cancelled: !still_needed,
                });
                active.set(active.get().saturating_sub(1));
            });
        }
    }
}

#[cfg(not(target_arch = "wasm32"))]
fn load_source_metadata(id: SourceId) -> Result<TerrainSource> {
    let path = metadata_cache_path(id)?;
    let client = reqwest::blocking::Client::builder()
        .connect_timeout(Duration::from_secs(3))
        .timeout(Duration::from_secs(8))
        .user_agent("cangling-desktop/0.1 terrain")
        .build()?;
    let online = client
        .get(metadata_url(id))
        .send()
        .and_then(|response| response.error_for_status())
        .and_then(|response| response.bytes())
        .map_err(anyhow::Error::from)
        .and_then(|bytes| {
            let source = parse_source(id, &bytes)?;
            if let Some(parent) = path.parent() {
                fs::create_dir_all(parent)?;
            }
            if let Err(error) = fs::write(&path, &bytes) {
                log::warn!("{} metadata cache write failed: {error}", id.dataset());
            }
            Ok(source)
        });
    match online {
        Ok(source) => Ok(source),
        Err(error) => {
            log::warn!(
                "{} metadata unavailable: {error:#}; trying local copy",
                id.dataset()
            );
            parse_source(id, &fs::read(path)?)
        }
    }
}

#[cfg(not(target_arch = "wasm32"))]
fn metadata_cache_path(id: SourceId) -> Result<PathBuf> {
    let root = dirs::cache_dir().ok_or_else(|| anyhow!("no platform cache directory"))?;
    Ok(root
        .join("cangling-desktop/terrain")
        .join(id.dataset())
        .join("metadata.json"))
}

#[cfg(not(target_arch = "wasm32"))]
fn terrain_worker(
    requests: Receiver<TerrainRequest>,
    results: Sender<TerrainResult>,
    wanted: Arc<RwLock<HashSet<TerrainKey>>>,
) {
    let client = reqwest::blocking::Client::builder()
        .connect_timeout(Duration::from_secs(3))
        .timeout(Duration::from_secs(15))
        .user_agent("cangling-desktop/0.1 terrain")
        .build()
        .expect("create terrain HTTP client");
    for request in requests {
        let key = request.key;
        if !wanted
            .read()
            .expect("terrain wanted lock poisoned")
            .contains(&key)
        {
            let _ = results.send(TerrainResult {
                key,
                result: Err(anyhow!("terrain request cancelled")),
                cache_hit: false,
                cancelled: true,
            });
            continue;
        }
        let loaded = load_height_tile(&client, &request);
        let (result, cache_hit) = match loaded {
            Ok((tile, hit)) => (Ok(tile), hit),
            Err(error) => (Err(error), false),
        };
        if results
            .send(TerrainResult {
                key,
                result,
                cache_hit,
                cancelled: false,
            })
            .is_err()
        {
            break;
        }
    }
}

#[cfg(not(target_arch = "wasm32"))]
fn load_height_tile(
    client: &reqwest::blocking::Client,
    request: &TerrainRequest,
) -> Result<(HeightTile, bool)> {
    let path = cache_path(request)?;
    let (bytes, cache_hit) = match fs::read(&path) {
        Ok(bytes) => (bytes, true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            let bytes = client
                .get(&request.url)
                .send()?
                .error_for_status()?
                .bytes()?
                .to_vec();
            if let Some(parent) = path.parent() {
                fs::create_dir_all(parent)?;
            }
            let temporary = path.with_extension("part");
            fs::write(&temporary, &bytes)?;
            fs::rename(temporary, &path)?;
            (bytes, false)
        }
        Err(error) => return Err(error.into()),
    };
    match decode_height_tile_bytes(bytes) {
        Ok(tile) => Ok((tile, cache_hit)),
        Err(error) => {
            if cache_hit {
                let _ = fs::remove_file(path);
            }
            Err(error)
        }
    }
}

fn decode_height_tile_bytes(bytes: Vec<u8>) -> Result<HeightTile> {
    let image = ImageReader::new(Cursor::new(bytes))
        .with_guessed_format()?
        .decode()
        .context("decode Terrarium PNG")?
        .to_rgb8();
    let (width, height) = image.dimensions();
    ensure!(
        width == 256 && height == 256,
        "unexpected DEM dimensions {width}x{height}"
    );
    let metres = image
        .pixels()
        .map(|rgb| {
            if rgb.0 == [0, 0, 0] {
                f32::NAN
            } else {
                decode_terrarium(rgb.0)
            }
        })
        .collect();
    Ok(HeightTile { metres })
}

#[cfg(not(target_arch = "wasm32"))]
fn cache_path(request: &TerrainRequest) -> Result<PathBuf> {
    let root = dirs::cache_dir().ok_or_else(|| anyhow!("no platform cache directory"))?;
    let key = request.key.tile;
    Ok(root
        .join("cangling-desktop/terrain")
        .join(request.key.source.dataset())
        .join(&request.revision)
        .join(key.z.to_string())
        .join(key.x.to_string())
        .join(format!("{}.png", key.y)))
}

fn decode_terrarium(rgb: [u8; 3]) -> f32 {
    rgb[0] as f32 * 256.0 + rgb[1] as f32 + rgb[2] as f32 / 256.0 - 32768.0
}

#[cfg(test)]
mod tests {
    use super::*;

    fn source(id: SourceId) -> TerrainSource {
        TerrainSource {
            bounds: if id == SourceId::Global {
                [-180.0, -85.051, 180.0, 85.051]
            } else {
                [73.0, 8.0, 136.0, 54.0]
            },
            tile_url: String::new(),
            revision: "a".repeat(64),
            max_level: id.max_level(),
        }
    }

    #[test]
    fn terrarium_decodes_known_heights_and_void() {
        assert_eq!(decode_terrarium([128, 0, 0]), 0.0);
        assert_eq!(decode_terrarium([129, 0, 0]), 256.0);
        assert_eq!(decode_terrarium([127, 255, 0]), -1.0);
        let png = {
            let img = image::RgbImage::from_pixel(256, 256, image::Rgb([0, 0, 0]));
            let mut buf = Cursor::new(Vec::new());
            img.write_to(&mut buf, image::ImageFormat::Png).unwrap();
            buf.into_inner()
        };
        assert!(decode_height_tile_bytes(png).unwrap().metres[0].is_nan());
    }

    #[test]
    fn sichuan_location_maps_to_expected_xyz_tile() {
        assert_eq!(
            lat_lon_tile(30.6_f64.to_radians(), 102.8_f64.to_radians(), 10),
            TileKey {
                z: 10,
                x: 804,
                y: 420
            }
        );
    }

    #[test]
    fn china_takes_precedence_and_global_fills_missing_cells() {
        let mut terrain = TerrainLayer::new();
        terrain
            .sources
            .insert(SourceId::Global, source(SourceId::Global));
        terrain
            .sources
            .insert(SourceId::China, source(SourceId::China));
        terrain.base_ready = true;
        terrain.target_level = 8;
        let key = lat_lon_tile(30.6_f64.to_radians(), 102.8_f64.to_radians(), 8);
        for (id, height) in [(SourceId::Global, 100.0), (SourceId::China, 200.0)] {
            let tile = HeightTile {
                metres: vec![height; 256 * 256],
            };
            for x in key.x..=key.x + 1 {
                for y in key.y..=key.y + 1 {
                    terrain.loaded.insert(
                        TerrainKey {
                            source: id,
                            tile: TileKey { x, y, ..key },
                        },
                        tile.clone(),
                    );
                }
            }
        }
        let lat = 30.6_f64.to_radians();
        let lon = 102.8_f64.to_radians();
        assert!((terrain.sample(lat, lon) - 200.0).abs() < 1e-6);
        terrain
            .loaded
            .retain(|key, _| key.source == SourceId::Global);
        assert!((terrain.sample(lat, lon) - 100.0).abs() < 1e-6);
        for tile in terrain.loaded.values_mut() {
            tile.metres.fill(-4_000.0);
        }
        assert_eq!(terrain.sample(lat, lon), 0.0);
    }

    #[test]
    fn global_pixel_interpolation_is_continuous_at_dem_boundary() {
        let mut terrain = TerrainLayer::new();
        terrain
            .sources
            .insert(SourceId::Global, source(SourceId::Global));
        terrain.target_level = 8;
        terrain.base_ready = true;
        let key = lat_lon_tile(30.6_f64.to_radians(), 102.8_f64.to_radians(), 8);
        for (x, height) in [(key.x, 100.0), (key.x + 1, 200.0)] {
            terrain.loaded.insert(
                TerrainKey {
                    source: SourceId::Global,
                    tile: TileKey { x, ..key },
                },
                HeightTile {
                    metres: vec![height; 256 * 256],
                },
            );
        }
        let boundary_lon = ((key.x + 1) as f64 / 256.0 * 360.0 - 180.0).to_radians();
        assert!((terrain.sample(30.6_f64.to_radians(), boundary_lon) - 150.0).abs() < 1e-6);
    }
}
