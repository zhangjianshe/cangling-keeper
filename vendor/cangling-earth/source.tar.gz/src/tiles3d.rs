//! Native explicit 3D Tiles traversal and streaming state. JS transports bytes only.
use glam::{DMat4, DVec3, Mat4};
use serde_json::{json, Value};
use std::collections::{BTreeMap, BTreeSet};
const MAX_NODES: usize = 10000;
const MAX_READY: usize = 32;
#[derive(Clone)]
struct Node {
    world: DMat4,
    depth: usize,
    center: DVec3,
    radius: f64,
    error: f64,
    add: bool,
    children: Vec<usize>,
    resources: Vec<String>,
}
#[derive(Clone, PartialEq)]
enum Status {
    Idle,
    Loading,
    Ready,
    Failed,
}
#[derive(Clone)]
struct Resource {
    uri: String,
    node: usize,
    json: bool,
    state: Status,
    attempts: u8,
    retry_at: u64,
    used: u64,
    message: String,
}
struct Tileset {
    url: String,
    visible: bool,
    sse: f64,
    nodes: Vec<Node>,
    resources: BTreeMap<String, Resource>,
    root: Option<usize>,
}
#[derive(Default)]
pub struct Tiles3d {
    sets: BTreeMap<String, Tileset>,
    tick: u64,
    generation: u64,
}
pub struct View {
    pub eye: DVec3,
    pub matrix: Mat4,
    pub pixels: f64,
}
fn internal(p: DVec3) -> DVec3 {
    DVec3::new(p.y, p.z, p.x)
}
fn vector(v: &Value, n: usize) -> Result<Vec<f64>, String> {
    let a = v
        .as_array()
        .filter(|a| a.len() == n)
        .ok_or("invalid numeric array")?;
    a.iter()
        .map(|x| {
            x.as_f64()
                .filter(|n| n.is_finite())
                .ok_or("non-finite number".into())
        })
        .collect()
}
fn matrix(v: &Value) -> Result<DMat4, String> {
    if v.is_null() {
        return Ok(DMat4::IDENTITY);
    }
    let a = vector(v, 16)?;
    let m = DMat4::from_cols_slice(&a);
    if (m.x_axis.w.abs() + m.y_axis.w.abs() + m.z_axis.w.abs()) > 1e-10
        || (m.w_axis.w - 1.).abs() > 1e-10
        || m.determinant().abs() < 1e-15
    {
        return Err("non-affine/singular transform".into());
    }
    Ok(m)
}
fn scale(m: DMat4) -> f64 {
    {
        let a = [
            m.x_axis.truncate(),
            m.y_axis.truncate(),
            m.z_axis.truncate(),
        ];
        (0..3)
            .map(|i| (0..3).map(|j| a[i].dot(a[j]).abs()).sum::<f64>())
            .fold(0., f64::max)
            .sqrt()
    }
}
fn bound(v: &Value, m: DMat4) -> Result<(DVec3, f64), String> {
    if v.get("sphere").is_some() {
        let a = vector(&v["sphere"], 4)?;
        if a[3] < 0. {
            return Err("negative radius".into());
        }
        return Ok((
            internal(m.transform_point3(DVec3::new(a[0], a[1], a[2]))),
            a[3] * scale(m),
        ));
    }
    if v.get("box").is_some() {
        let a = vector(&v["box"], 12)?;
        let radius = (1..4)
            .map(|i| {
                m.transform_vector3(DVec3::new(a[i * 3], a[i * 3 + 1], a[i * 3 + 2]))
                    .length()
            })
            .sum();
        return Ok((
            internal(m.transform_point3(DVec3::new(a[0], a[1], a[2]))),
            radius,
        ));
    }
    let a = vector(&v["region"], 6)?;
    let (w, s, e, n, lo, hi) = (a[0], a[1], a[2], a[3], a[4], a[5]);
    if w.abs() > std::f64::consts::PI
        || e.abs() > std::f64::consts::PI
        || s.abs() > std::f64::consts::FRAC_PI_2
        || n.abs() > std::f64::consts::FRAC_PI_2
        || s > n
        || lo > hi
    {
        return Err("invalid region".into());
    }
    // Regions are WGS84 and are not transformed by tile.transform. A conservative
    // enclosing sphere avoids dropping curved/wrapping regions at high altitude.
    let east = if e < w { e + std::f64::consts::TAU } else { e };
    let lon = (w + east) / 2.;
    let lat = (s + n) / 2.;
    let center = crate::geo::geodetic_position(lat, lon, (lo + hi) / 2.);
    let angle = ((east - w) / 2. + (n - s) / 2.).min(std::f64::consts::PI);
    let radius = 2. * (crate::geo::SEMI_MAJOR_M + lo.abs().max(hi.abs())) * (angle / 2.).sin()
        + (hi - lo) / 2.;
    Ok((center, radius.max(1.)))
}
fn relative(base: &str, uri: &str) -> Result<String, String> {
    if uri.is_empty()
        || uri.len() > 1024
        || uri.chars().any(|c| c.is_control() || ":\\%?#".contains(c))
        || uri
            .split('/')
            .any(|s| s.is_empty() || s == ".." || s == ".")
    {
        return Err("only local relative content URIs are supported".into());
    }
    Ok(format!(
        "{}{uri}",
        base.rsplit_once('/')
            .map(|(p, _)| format!("{p}/"))
            .unwrap_or_default()
    ))
}
impl View {
    fn visible(&self, n: &Node) -> bool {
        let p = (n.center - self.eye) / crate::geo::SEMI_MAJOR_M;
        let r = n.radius / crate::geo::SEMI_MAJOR_M;
        let t = self.matrix.transpose();
        let rows = [
            t.x_axis.as_dvec4(),
            t.y_axis.as_dvec4(),
            t.z_axis.as_dvec4(),
            t.w_axis.as_dvec4(),
        ];
        [
            rows[3] + rows[0],
            rows[3] - rows[0],
            rows[3] + rows[1],
            rows[3] - rows[1],
            rows[2],
            rows[3] - rows[2],
        ]
        .iter()
        .all(|plane| plane.dot(p.extend(1.)) >= -r * plane.truncate().length())
    }
    fn sse(&self, n: &Node) -> f64 {
        n.error * self.pixels / (self.eye.distance(n.center) - n.radius).max(1.)
    }
}
impl Tileset {
    fn parse(
        &mut self,
        doc: &Value,
        base: &str,
        parent: DMat4,
        inherited: bool,
        depth: usize,
    ) -> Result<usize, String> {
        if depth > 32 || !matches!(doc["asset"]["version"].as_str(), Some("1.0" | "1.1")) {
            return Err("unsupported tileset version/depth".into());
        }
        if doc.get("extensions").is_some()
            || doc.get("schemaUri").is_some()
            || doc["extensionsRequired"]
                .as_array()
                .is_some_and(|a| !a.is_empty())
        {
            return Err("tileset extensions/metadata URI unsupported".into());
        }
        self.node(&doc["root"], base, parent, inherited, depth)
    }
    fn node(
        &mut self,
        v: &Value,
        base: &str,
        parent: DMat4,
        inherited: bool,
        depth: usize,
    ) -> Result<usize, String> {
        if depth > 32 || self.nodes.len() >= MAX_NODES {
            return Err("tile tree budget exceeded".into());
        }
        if v.get("implicitTiling").is_some() || v.get("extensions").is_some() {
            return Err("implicit/extended tiles unsupported".into());
        }
        let world = parent * matrix(&v["transform"])?;
        let (center, radius) = bound(&v["boundingVolume"], world)?;
        if !center.is_finite() || !radius.is_finite() || radius > 1e10 {
            return Err("invalid world bounds".into());
        }
        let error = v["geometricError"]
            .as_f64()
            .filter(|x| x.is_finite() && *x >= 0.)
            .ok_or("invalid geometricError")?;
        let add = match v["refine"].as_str() {
            Some("ADD") => true,
            Some("REPLACE") => false,
            None => inherited,
            _ => return Err("invalid refinement".into()),
        };
        let index = self.nodes.len();
        self.nodes.push(Node {
            world,
            depth,
            center,
            radius,
            error: error * scale(world),
            add,
            children: vec![],
            resources: vec![],
        });
        let mut contents = vec![];
        if let Some(c) = v.get("content") {
            contents.push(c);
        }
        if let Some(cs) = v.get("contents") {
            if !contents.is_empty() {
                return Err("content and contents conflict".into());
            }
            contents.extend(cs.as_array().ok_or("invalid contents")?);
        }
        if contents.len() > 8 {
            return Err("too many contents".into());
        }
        for (i, c) in contents.into_iter().enumerate() {
            let uri = c
                .get("uri")
                .or_else(|| c.get("url"))
                .and_then(Value::as_str)
                .ok_or("missing content URI")?;
            let uri = relative(base, uri)?;
            let is_json = uri.ends_with(".json");
            if !is_json && !uri.ends_with(".glb") && !uri.ends_with(".b3dm") {
                return Err("only GLB/b3dm content is supported".into());
            }
            let key = format!("{index}:{i}");
            self.resources.insert(
                key.clone(),
                Resource {
                    uri,
                    node: index,
                    json: is_json,
                    state: Status::Idle,
                    attempts: 0,
                    retry_at: 0,
                    used: 0,
                    message: String::new(),
                },
            );
            self.nodes[index].resources.push(key);
        }
        if let Some(children) = v.get("children") {
            for child in children.as_array().ok_or("invalid children")? {
                let c = self.node(child, base, world, add, depth + 1)?;
                self.nodes[index].children.push(c);
            }
        }
        Ok(index)
    }
    fn select(
        &self,
        index: usize,
        view: &View,
        needed: &mut BTreeSet<String>,
        budget_limited: &mut bool,
    ) -> (Vec<String>, bool) {
        let n = &self.nodes[index];
        if !view.visible(n) {
            return (vec![], true);
        }
        let own: Vec<_> = n
            .resources
            .iter()
            .filter(|k| !self.resources[*k].json)
            .cloned()
            .collect();
        for key in &n.resources {
            needed.insert(key.clone());
        }
        let own_ready = own.iter().all(|k| self.resources[k].state == Status::Ready);
        let external_pending = n
            .resources
            .iter()
            .any(|k| self.resources[k].json && self.resources[k].state != Status::Ready);
        let refine = !n.children.is_empty() && (own.is_empty() || view.sse(n) > self.sse);
        if refine {
            let mut draws = vec![];
            let mut complete = !external_pending;
            let mut children = n.children.clone();
            children.sort_by(|a, b| {
                self.nodes[*a]
                    .center
                    .distance_squared(view.eye)
                    .total_cmp(&self.nodes[*b].center.distance_squared(view.eye))
            });
            for child in children {
                let before = needed.clone();
                let (d, ok) = self.select(child, view, needed, budget_limited);
                if needed.iter().filter(|k| !self.resources[*k].json).count() > MAX_READY {
                    *needed = before;
                    complete = false;
                    *budget_limited = true;
                } else {
                    draws.extend(d);
                    complete &= ok;
                }
            }
            if n.add {
                if own_ready {
                    draws.extend(own);
                }
                return (draws, complete && own_ready);
            }
            if complete {
                return (draws, true);
            }
            return if own_ready && !own.is_empty() {
                (own, true)
            } else {
                (draws, false)
            };
        }
        (
            if own_ready { own.clone() } else { vec![] },
            own_ready && !external_pending,
        )
    }
}
impl Tiles3d {
    pub fn scene(&mut self, v: &Value) -> Result<(), String> {
        let values = v
            .as_array()
            .filter(|a| a.len() <= 4)
            .ok_or("at most 4 tilesets")?;
        let mut ids = BTreeSet::new();
        for l in values {
            let id = l["id"]
                .as_str()
                .filter(|s| !s.is_empty() && s.len() <= 100 && !s.contains('|'))
                .ok_or("invalid tileset ID")?;
            if !ids.insert(id.to_string())
                || !l["url"].is_string()
                || !l["visible"].is_boolean()
                || !l["maximumScreenSpaceError"]
                    .as_f64()
                    .is_some_and(|x| (2.0..=128.0).contains(&x))
            {
                return Err("invalid tileset scene".into());
            }
        }
        ids.clear();
        for l in values {
            let id = l["id"]
                .as_str()
                .filter(|x| x.len() <= 100 && !x.contains('|'))
                .ok_or("invalid tileset ID")?;
            let url = l["url"].as_str().ok_or("missing URL")?;
            let sse = l["maximumScreenSpaceError"]
                .as_f64()
                .filter(|x| (2.0..=128.0).contains(x))
                .ok_or("invalid SSE")?;
            if !ids.insert(id.to_string()) {
                return Err("duplicate tileset".into());
            }
            let replace = self.sets.get(id).is_none_or(|s| s.url != url);
            if replace {
                self.generation += 1;
                let mut resources = BTreeMap::new();
                resources.insert(
                    "root".into(),
                    Resource {
                        uri: String::new(),
                        node: 0,
                        json: true,
                        state: Status::Idle,
                        attempts: 0,
                        retry_at: 0,
                        used: 0,
                        message: String::new(),
                    },
                );
                self.sets.insert(
                    id.into(),
                    Tileset {
                        url: url.into(),
                        visible: true,
                        sse,
                        nodes: vec![],
                        resources,
                        root: None,
                    },
                );
            }
            let set = self.sets.get_mut(id).unwrap();
            set.visible = l["visible"] == true;
            set.sse = sse;
        }
        self.sets.retain(|id, _| ids.contains(id));
        Ok(())
    }
    pub fn tick(&mut self, view: &View) -> Value {
        self.tick += 1;
        let mut requests = vec![];
        let mut keep = vec![];
        let mut active = vec![];
        let mut status = vec![];
        for (id, set) in &mut self.sets {
            let mut needed = BTreeSet::new();
            let mut budget_limited = false;
            let draws = if set.visible {
                needed.insert("root".into());
                set.root
                    .map(|n| set.select(n, view, &mut needed, &mut budget_limited).0)
                    .unwrap_or_default()
            } else {
                vec![]
            };
            // Drop obsolete pending requests and old/off-screen GPU content. Roots and external
            // manifests stay parsed, but hidden layers release all model allocations immediately.
            let mut ready: Vec<_> = set
                .resources
                .iter()
                .filter(|(_, r)| !r.json && r.state == Status::Ready)
                .map(|(k, r)| (k.clone(), r.used))
                .collect();
            ready.sort_by_key(|(_, t)| *t);

            for (k, _) in &ready {
                if !set.visible || (!draws.contains(k) && !needed.contains(k)) {
                    set.resources.get_mut(k).unwrap().state = Status::Idle;
                }
            }
            for (k, r) in &mut set.resources {
                let full = format!("{id}|{k}");
                if needed.contains(k) {
                    r.used = self.tick;
                    if r.state == Status::Idle
                        || (r.state == Status::Failed && r.attempts < 3 && self.tick >= r.retry_at)
                    {
                        r.state = Status::Loading;
                        r.attempts += 1;
                        requests.push(json!({"key":full,"layerId":id,"uri":r.uri,"json":r.json}));
                    }
                    if r.state == Status::Loading {
                        active.push(full.clone());
                    }
                } else if r.state == Status::Loading {
                    r.state = Status::Idle;
                    r.attempts = r.attempts.saturating_sub(1);
                }
                if !r.json && r.state == Status::Ready {
                    keep.push(json!({"id":full,"visible":draws.contains(k),"ecefTransform":set.nodes[r.node].world.to_cols_array()}));
                }
            }
            status.push(json!({"id":id,"budgetLimited":budget_limited,"visible":set.visible,"nodes":set.nodes.len(),"loaded":set.resources.values().filter(|r|!r.json&&r.state==Status::Ready).count(),"drawing":draws.len(),"selectedContents":draws.iter().take(8).map(|k|set.resources[k].uri.clone()).collect::<Vec<_>>(),"pending":set.resources.values().filter(|r|r.state==Status::Loading).count(),"errors":set.resources.values().filter(|r|r.state==Status::Failed).take(4).map(|r|json!({"uri":r.uri.chars().take(200).collect::<String>(),"error":r.message,"attempts":r.attempts})).collect::<Vec<_>>()}));
        }
        json!({"requests":requests,"active":active,"keep":keep,"layers":status})
    }
    pub fn cancel(&mut self, key: &str) {
        if let Some((id, k)) = key.split_once('|') {
            if let Some(r) = self.sets.get_mut(id).and_then(|s| s.resources.get_mut(k)) {
                if r.state == Status::Loading {
                    r.state = Status::Idle;
                    r.attempts = r.attempts.saturating_sub(1);
                }
            }
        }
    }
    pub fn fail(&mut self, key: &str, error: &str) {
        if let Some((id, k)) = key.split_once('|') {
            if let Some(r) = self.sets.get_mut(id).and_then(|s| s.resources.get_mut(k)) {
                r.state = Status::Failed;
                r.retry_at = self.tick + 4u64.pow(r.attempts as u32);
                r.message = error.chars().take(240).collect();
            }
        }
    }
    pub fn manifest(&mut self, key: &str, doc: &Value) -> Result<(), String> {
        let (id, k) = key.split_once('|').ok_or("invalid resource key")?;
        let set = self.sets.get_mut(id).ok_or("removed tileset")?;
        let r = set
            .resources
            .get(k)
            .filter(|r| r.state == Status::Loading && r.json)
            .cloned()
            .ok_or("obsolete manifest")?;
        // Each external URI may occur once along the loaded tree; duplicate instances are
        // intentionally rejected in this bounded implementation to prevent recursive fetches.
        if k != "root"
            && set.resources.iter().any(|(other, v)| {
                other != k && v.json && v.uri == r.uri && v.state == Status::Ready
            })
        {
            return Err("cyclic/repeated external tileset".into());
        }
        let parent = if k == "root" {
            DMat4::IDENTITY
        } else {
            set.nodes[r.node].world
        };
        let before = set.nodes.len();
        let keys: BTreeSet<_> = set.resources.keys().cloned().collect();
        let depth = if k == "root" {
            0
        } else {
            set.nodes[r.node].depth + 1
        };
        let parsed = set.parse(doc, &r.uri, parent, false, depth);
        let node = match parsed {
            Ok(n) => n,
            Err(e) => {
                set.nodes.truncate(before);
                set.resources.retain(|k, _| keys.contains(k));
                return Err(e);
            }
        };
        if k == "root" {
            set.root = Some(node);
        } else {
            set.nodes[r.node].children.push(node);
        }
        set.resources.get_mut(k).unwrap().state = Status::Ready;
        Ok(())
    }
    pub fn placement(&self, key: &str) -> Result<Value, String> {
        let (id, k) = key.split_once('|').ok_or("invalid key")?;
        let set = self.sets.get(id).ok_or("removed tileset")?;
        let r = set
            .resources
            .get(k)
            .filter(|r| r.state == Status::Loading && !r.json)
            .ok_or("obsolete content")?;
        Ok(
            json!({"id":key,"visible":false,"ecefTransform":set.nodes[r.node].world.to_cols_array()}),
        )
    }
    pub fn ready(&mut self, key: &str) {
        if let Some((id, k)) = key.split_once('|') {
            if let Some(r) = self.sets.get_mut(id).and_then(|s| s.resources.get_mut(k)) {
                r.state = Status::Ready;
                r.attempts = 0;
                r.message.clear();
            }
        }
    }
}
/// glTF Y-up -> tile Z-up -> RTC_CENTER -> hierarchical tile ECEF transform.
pub fn content(bytes: &[u8]) -> Result<(&[u8], DVec3), String> {
    if bytes.len() > 16 * 1024 * 1024 {
        return Err("tile exceeds 16 MiB".into());
    }
    if bytes.get(..4) == Some(b"glTF") {
        return Ok((bytes, DVec3::ZERO));
    }
    let u = |i| {
        bytes
            .get(i..i + 4)
            .map(|v| u32::from_le_bytes(v.try_into().unwrap()) as usize)
            .ok_or("truncated b3dm")
    };
    if bytes.get(..4) != Some(b"b3dm") || u(4)? != 1 || u(8)? != bytes.len() {
        return Err("expected GLB or modern b3dm".into());
    }
    let fj = u(12)?;
    if fj > bytes.len().saturating_sub(28) {
        return Err("truncated feature JSON".into());
    }
    let offset = [fj, u(16)?, u(20)?, u(24)?]
        .into_iter()
        .try_fold(28usize, |n, size| n.checked_add(size))
        .ok_or("b3dm table size overflow")?;
    let feature: Value =
        serde_json::from_slice(bytes.get(28..28 + fj).ok_or("truncated feature JSON")?)
            .map_err(|e| e.to_string())?;
    let rtc = if feature.get("RTC_CENTER").is_some() {
        DVec3::from_slice(&vector(&feature["RTC_CENTER"], 3)?)
    } else {
        DVec3::ZERO
    };
    Ok((bytes.get(offset..).ok_or("truncated b3dm GLB")?, rtc))
}

#[cfg(test)]
mod tests {
    use super::*;
    fn setup(refine: &str) -> Tiles3d {
        let mut t = Tiles3d::default();
        t.scene(&json!([{"id":"a","url":"http://localhost/tileset.json","visible":true,"maximumScreenSpaceError":16}])).unwrap();
        t.tick(&view());
        t.manifest("a|root",&json!({"asset":{"version":"1.1"},"root":{"boundingVolume":{"sphere":[0,0,0,1]},"geometricError":100,"refine":refine,"content":{"uri":"parent.glb"},"children":[{"boundingVolume":{"sphere":[0,0,0,1]},"geometricError":0,"content":{"uri":"child.glb"}}]}})).unwrap();
        t
    }
    fn view() -> View {
        View {
            eye: DVec3::ZERO,
            matrix: Mat4::IDENTITY,
            pixels: 1000.,
        }
    }
    #[test]
    fn replace_keeps_parent_until_children_ready() {
        let mut t = setup("REPLACE");
        let p = t.tick(&view());
        assert_eq!(p["requests"].as_array().unwrap().len(), 2);
        t.ready("a|0:0");
        let p = t.tick(&view());
        assert_eq!(p["keep"][0]["visible"], true);
        t.ready("a|1:0");
        let p = t.tick(&view());
        assert_eq!(p["keep"][0]["visible"], false);
        assert_eq!(p["keep"][1]["visible"], true);
    }
    #[test]
    fn add_draws_both() {
        let mut t = setup("ADD");
        t.tick(&view());
        t.ready("a|0:0");
        t.ready("a|1:0");
        assert_eq!(t.tick(&view())["layers"][0]["drawing"], 2);
    }
    #[test]
    fn hide_cancels_and_releases() {
        let mut t = setup("REPLACE");
        t.tick(&view());
        t.ready("a|0:0");
        t.scene(&json!([{"id":"a","url":"http://localhost/tileset.json","visible":false,"maximumScreenSpaceError":16}])).unwrap();
        let p = t.tick(&view());
        assert_eq!(p["active"], json!([]));
        assert_eq!(p["keep"], json!([]));
        assert!(t.placement("a|1:0").is_err());
    }
    #[test]
    fn retry_is_bounded() {
        let mut t = setup("REPLACE");
        for _ in 0..300 {
            let p = t.tick(&view());
            for r in p["requests"].as_array().unwrap() {
                t.fail(r["key"].as_str().unwrap(), "test");
            }
        }
        let r = &t.sets["a"].resources["0:0"];
        assert_eq!(r.attempts, 3);
        assert!(r.state == Status::Failed);
    }
    #[test]
    fn external_transform_and_rollback() {
        let mut t = Tiles3d::default();
        t.scene(&json!([{"id":"a","url":"http://localhost/tileset.json","visible":true,"maximumScreenSpaceError":16}])).unwrap();
        t.tick(&view());
        let m = DMat4::from_translation(DVec3::new(1., 2., 3.));
        t.manifest("a|root",&json!({"asset":{"version":"1.0"},"root":{"transform":m.to_cols_array(),"boundingVolume":{"sphere":[0,0,0,100]},"geometricError":1,"content":{"uri":"nested/tileset.json"}}})).unwrap();
        t.tick(&view());
        assert!(t.manifest("a|0:0",&json!({"asset":{"version":"1.0"},"root":{"boundingVolume":{"sphere":[0,0,0,1]},"geometricError":0,"content":{"uri":"../escape.glb"}}})).is_err());
        assert_eq!(t.sets["a"].nodes.len(), 1);
        t.manifest("a|0:0",&json!({"asset":{"version":"1.0"},"root":{"transform":m.to_cols_array(),"boundingVolume":{"sphere":[0,0,0,1]},"geometricError":0,"content":{"uri":"model.glb"}}})).unwrap();
        assert_eq!(
            t.sets["a"].nodes[1].world.w_axis.truncate(),
            DVec3::new(2., 4., 6.)
        );
        assert_eq!(t.sets["a"].resources["1:0"].uri, "nested/model.glb");
    }
    #[test]
    fn budgets_keep_coarse_parent() {
        let mut t = setup("REPLACE");
        let set = t.sets.get_mut("a").unwrap();
        let child = set.nodes[1].clone();
        for i in 2..36 {
            let mut c = child.clone();
            c.resources = vec![format!("{i}:0")];
            let mut r = set.resources["1:0"].clone();
            r.node = i;
            set.resources.insert(format!("{i}:0"), r);
            set.nodes.push(c);
            set.nodes[0].children.push(i);
        }
        let p = t.tick(&view());
        assert_eq!(p["requests"].as_array().unwrap().len(), MAX_READY);
        assert_eq!(p["layers"][0]["budgetLimited"], true);
        assert_eq!(p["requests"][0]["uri"], "parent.glb");
    }
    #[test]
    fn b3dm_validation() {
        assert!(content(b"invalid").is_err());
        let feature = br#"{"RTC_CENTER":[1,2,3]}"#;
        let mut b = b"b3dm".to_vec();
        for n in [
            1,
            28 + feature.len() as u32 + 4,
            feature.len() as u32,
            0,
            0,
            0,
        ] {
            b.extend(n.to_le_bytes());
        }
        b.extend(feature);
        b.extend(b"glTF");
        let (glb, rtc) = content(&b).unwrap();
        assert_eq!(glb, b"glTF");
        assert_eq!(rtc, DVec3::new(1., 2., 3.));
        assert_eq!(scale(DMat4::IDENTITY), 1.);
    }
    #[test]
    fn coarse_and_culled_selection() {
        let mut t = setup("REPLACE");
        let mut far = view();
        far.pixels = 0.;
        let p = t.tick(&far);
        assert_eq!(p["requests"].as_array().unwrap().len(), 1);
        assert_eq!(p["requests"][0]["uri"], "parent.glb");
        let mut behind = view();
        behind.eye = DVec3::new(0., 0., crate::geo::SEMI_MAJOR_M * 10.);
        let p = t.tick(&behind);
        assert_eq!(p["active"], json!([]));
    }
    #[test]
    fn malformed_b3dm_sizes_are_rejected() {
        let mut b = b"b3dm".to_vec();
        for n in [1u32, 28, u32::MAX, u32::MAX, 0, 0] {
            b.extend(n.to_le_bytes());
        }
        assert!(content(&b).is_err());
    }
}
