struct NavUniform {
    viewport: vec4<f32>,
    panel: vec4<f32>,
    values: vec4<f32>,
};

@group(0) @binding(0) var<uniform> nav: NavUniform;

struct VertexOutput {
    @builtin(position) position: vec4<f32>,
    @location(0) local_px: vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) index: u32) -> VertexOutput {
    let corners = array<vec2<f32>, 6>(
        vec2<f32>(0.0, 0.0), vec2<f32>(1.0, 0.0), vec2<f32>(0.0, 1.0),
        vec2<f32>(0.0, 1.0), vec2<f32>(1.0, 0.0), vec2<f32>(1.0, 1.0),
    );
    let local_px = corners[index] * nav.panel.zw;
    let screen_px = nav.panel.xy + local_px;
    var output: VertexOutput;
    output.position = vec4<f32>(
        2.0 * screen_px.x / nav.viewport.x - 1.0,
        1.0 - 2.0 * screen_px.y / nav.viewport.y,
        0.0,
        1.0,
    );
    output.local_px = local_px;
    return output;
}

// One screen pixel of edge smoothing, regardless of window size or HUD scale.
fn coverage(distance: f32) -> f32 {
    let half_pixel = 0.5 / max(nav.viewport.z, 0.01);
    return 1.0 - smoothstep(-half_pixel, half_pixel, distance);
}

fn box_distance(p: vec2<f32>, half: vec2<f32>) -> f32 {
    let delta = abs(p) - half;
    return length(max(delta, vec2<f32>(0.0))) + min(max(delta.x, delta.y), 0.0);
}

fn triangle_distance(
    p: vec2<f32>, a: vec2<f32>, b: vec2<f32>, c: vec2<f32>
) -> f32 {
    let ab = b - a;
    let bc = c - b;
    let ca = a - c;
    let d0 = -(ab.x * (p.y - a.y) - ab.y * (p.x - a.x)) / length(ab);
    let d1 = -(bc.x * (p.y - b.y) - bc.y * (p.x - b.x)) / length(bc);
    let d2 = -(ca.x * (p.y - c.y) - ca.y * (p.x - c.x)) / length(ca);
    return max(max(d0, d1), d2);
}

fn over(under: vec4<f32>, top: vec4<f32>) -> vec4<f32> {
    let a = top.a + under.a * (1.0 - top.a);
    let rgb = (top.rgb * top.a + under.rgb * under.a * (1.0 - top.a)) / max(a, 0.0001);
    return vec4<f32>(rgb, a);
}

@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    let p = input.local_px / nav.viewport.z - vec2<f32>(160.0, 0.0);
    var color = vec4<f32>(0.0);

    // Ground scale: the CPU samples the centre terrain and chooses a 1-2-5
    // distance. The white rule and its end ticks are drawn in screen pixels.
    if nav.values.w > 0.0 {
        let start = -150.0;
        let end = start + nav.values.w;
        let middle = (start + end) * 0.5;
        let stroke = 0.55 / max(nav.viewport.z, 0.01);
        let rule = coverage(box_distance(
            p - vec2<f32>(middle, 36.0), vec2<f32>((end - start) * 0.5, stroke)));
        let left_tick = coverage(box_distance(
            p - vec2<f32>(start, 36.0), vec2<f32>(stroke, 4.0)));
        let right_tick = coverage(box_distance(
            p - vec2<f32>(end, 36.0), vec2<f32>(stroke, 4.0)));
        let rule_alpha = max(rule, max(left_tick, right_tick));
        color = over(color, vec4<f32>(0.0, 0.0, 0.0,
            0.7 * coverage(box_distance(p - vec2<f32>(middle, 37.0),
                vec2<f32>((end - start) * 0.5 + 1.0, 1.5)))));
        color = over(color, vec4<f32>(1.0, 1.0, 1.0, 0.9 * rule_alpha));
    }

    let center = vec2<f32>(23.0, 34.0);
    let radial = length(p - center);
    color = over(color, vec4<f32>(0.01, 0.03, 0.04, 0.40 * coverage(radial - 21.8)));
    color = over(color, vec4<f32>(0.04, 0.09, 0.12, 0.70 * coverage(radial - 20.5)));
    color = over(color, vec4<f32>(0.91, 0.94, 0.92,
        coverage(abs(radial - 20.5) - 0.55)));
    color = over(color, vec4<f32>(0.70, 0.79, 0.78,
        0.75 * coverage(abs(radial - 17.4) - 0.30)));

    let q = p - center;
    let north_tick = coverage(box_distance(q - vec2<f32>(0.0, -18.9),
        vec2<f32>(0.45, 1.35)));
    let south_tick = coverage(box_distance(q - vec2<f32>(0.0, 18.9),
        vec2<f32>(0.45, 1.35)));
    let east_tick = coverage(box_distance(q - vec2<f32>(18.9, 0.0),
        vec2<f32>(1.35, 0.45)));
    let west_tick = coverage(box_distance(q - vec2<f32>(-18.9, 0.0),
        vec2<f32>(1.35, 0.45)));
    color = over(color, vec4<f32>(0.98, 0.99, 0.95,
        max(max(north_tick, south_tick), max(east_tick, west_tick))));

    // Rotate a vector needle directly in screen space; no magnified texture.
    let angle = nav.values.x;
    let needle = vec2<f32>(
        cos(angle) * q.x + sin(angle) * q.y,
        -sin(angle) * q.x + cos(angle) * q.y,
    );
    let north_border = triangle_distance(needle,
        vec2<f32>(0.0, -16.4), vec2<f32>(3.7, 0.2), vec2<f32>(-3.7, 0.2));
    let south_border = triangle_distance(needle,
        vec2<f32>(0.0, 16.4), vec2<f32>(-3.7, -0.2), vec2<f32>(3.7, -0.2));
    color = over(color, vec4<f32>(0.05, 0.09, 0.11,
        coverage(min(north_border, south_border))));
    let north = triangle_distance(needle,
        vec2<f32>(0.0, -15.2), vec2<f32>(2.8, -0.6), vec2<f32>(-2.8, -0.6));
    let south = triangle_distance(needle,
        vec2<f32>(0.0, 15.2), vec2<f32>(-2.8, 0.6), vec2<f32>(2.8, 0.6));
    color = over(color, vec4<f32>(0.88, 0.15, 0.12, coverage(north)));
    color = over(color, vec4<f32>(0.93, 0.95, 0.91, coverage(south)));
    color = over(color, vec4<f32>(0.04, 0.10, 0.12,
        coverage(length(q) - 3.1)));
    color = over(color, vec4<f32>(0.93, 0.96, 0.92,
        coverage(abs(length(q) - 2.9) - 0.45)));
    color = over(color, vec4<f32>(0.76, 0.83, 0.82,
        coverage(length(q) - 0.95)));

    for (var row: i32 = 0; row < 2; row = row + 1) {
        let y = select(22.0, 46.0, row == 1);
        let bar = p - vec2<f32>(133.0, y);
        let border_width = 1.0 / max(nav.viewport.z, 0.01);
        let outer = coverage(box_distance(bar, vec2<f32>(73.0, 7.0)));
        let inner = coverage(box_distance(bar,
            vec2<f32>(73.0 - border_width, 7.0 - border_width)));
        color = over(color, vec4<f32>(0.0, 0.0, 0.0, 0.55 * outer));
        color = over(color, vec4<f32>(1.0, 1.0, 1.0,
            0.8 * clamp(outer - inner, 0.0, 1.0)));

        let value = select(nav.values.y, nav.values.z, row == 1);
        let grip = p - vec2<f32>(66.0 + 134.0 * value, y);
        let grip_outer = coverage(box_distance(grip, vec2<f32>(5.0, 5.0)));
        let grip_inner = coverage(box_distance(grip, vec2<f32>(4.1, 4.1)));
        color = over(color, vec4<f32>(0.37, 0.06, 0.06, grip_outer));
        let shade = clamp((grip.y + 4.0) / 8.0, 0.0, 1.0);
        let red = mix(vec3<f32>(0.98, 0.36, 0.30),
            vec3<f32>(0.73, 0.10, 0.10), shade);
        color = over(color, vec4<f32>(red, grip_inner));
        let top_glint = coverage(box_distance(
            grip - vec2<f32>(0.0, -3.3), vec2<f32>(3.0, 0.35)));
        color = over(color, vec4<f32>(1.0, 0.64, 0.53, top_glint * grip_inner));
        let groove = coverage(box_distance(
            grip - vec2<f32>(-0.7, 0.0), vec2<f32>(0.8, 2.4)));
        let groove_light = coverage(box_distance(
            grip - vec2<f32>(0.75, 0.0), vec2<f32>(0.45, 2.4)));
        color = over(color, vec4<f32>(0.42, 0.04, 0.04, groove * grip_inner));
        color = over(color, vec4<f32>(1.0, 0.71, 0.60, groove_light * grip_inner));
    }
    return color;
}
