//! Resolution-aware navigation controls shared by desktop and browser builds.

use bytemuck::{Pod, Zeroable};
use glam::Vec2;
use wgpu::util::DeviceExt;

const WIDTH: f32 = 218.0;
const HEIGHT: f32 = 68.0;
const READOUT_WIDTH: f32 = 160.0;
const BAR_LEFT: f32 = 66.0;
const BAR_RIGHT: f32 = 200.0;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum NavControl {
    Compass,
    Heading,
    Tilt,
}

/// A rounded ground distance whose drawn width fits the available HUD space.
#[derive(Clone, Copy, Debug)]
pub struct ScaleBar {
    pub distance_m: f64,
    pub pixel_width: f32,
}

impl ScaleBar {
    pub fn new(metres_per_pixel: f64, available_pixels: f32) -> Option<Self> {
        if !metres_per_pixel.is_finite() || metres_per_pixel <= 0.0 || available_pixels <= 0.0 {
            return None;
        }
        let target = metres_per_pixel * available_pixels as f64;
        let magnitude = 10.0_f64.powf(target.log10().floor());
        let distance_m = [5.0, 2.0, 1.0]
            .into_iter()
            .map(|step| step * magnitude)
            .find(|distance| *distance <= target)?;
        Some(Self {
            distance_m,
            pixel_width: (distance_m / metres_per_pixel) as f32,
        })
    }

    pub fn label(self) -> String {
        if self.distance_m >= 1_000.0 {
            format!("{} 公里", (self.distance_m / 1_000.0) as u64)
        } else if self.distance_m >= 1.0 {
            format!("{} 米", self.distance_m as u64)
        } else {
            format!("{} 厘米", (self.distance_m * 100.0).round() as u64)
        }
    }
}

#[derive(Clone, Copy)]
pub struct NavLayout {
    pub origin: Vec2,
    pub size: Vec2,
    pub scale: f32,
}

impl NavLayout {
    pub fn new(width: u32, height: u32) -> Self {
        let width = width.max(1) as f32;
        let height = height.max(1) as f32;
        let scale = (height / 750.0)
            .clamp(0.65, 1.6)
            .min(width / (WIDTH + READOUT_WIDTH + 28.0))
            .min(height / (HEIGHT + 28.0));
        let size = Vec2::new(WIDTH, HEIGHT) * scale;
        let margin = 18.0 * scale;
        Self {
            origin: Vec2::new(width - size.x - margin, height - size.y - margin),
            size,
            scale,
        }
    }

    pub fn hit_test(self, position: Vec2) -> Option<NavControl> {
        let p = (position - self.origin) / self.scale;
        if p.x < 0.0 || p.y < 0.0 || p.x > WIDTH || p.y > HEIGHT {
            return None;
        }
        if (p - Vec2::new(23.0, 34.0)).length() <= 23.0 {
            return Some(NavControl::Compass);
        }
        if (BAR_LEFT - 6.0..=BAR_RIGHT + 6.0).contains(&p.x) {
            if (p.y - 22.0).abs() <= 10.0 {
                return Some(NavControl::Heading);
            }
            if (p.y - 46.0).abs() <= 10.0 {
                return Some(NavControl::Tilt);
            }
        }
        None
    }

    pub fn bar_fraction(self, position: Vec2) -> f32 {
        let x = (position.x - self.origin.x) / self.scale;
        ((x - BAR_LEFT) / (BAR_RIGHT - BAR_LEFT)).clamp(0.0, 1.0)
    }
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct NavUniform {
    viewport: [f32; 4],
    panel: [f32; 4],
    values: [f32; 4],
}

pub struct NavigationHud {
    pipeline: wgpu::RenderPipeline,
    bind_group: wgpu::BindGroup,
    uniform_buffer: wgpu::Buffer,
}

impl NavigationHud {
    pub fn new(device: &wgpu::Device, format: wgpu::TextureFormat) -> Self {
        let uniform_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("navigation HUD uniform"),
            contents: bytemuck::bytes_of(&NavUniform {
                viewport: [1.0, 1.0, 1.0, 0.0],
                panel: [0.0, 0.0, WIDTH + READOUT_WIDTH, HEIGHT],
                values: [0.0; 4],
            }),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("navigation HUD layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("navigation HUD bind group"),
            layout: &bind_group_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: uniform_buffer.as_entire_binding(),
            }],
        });
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("navigation HUD shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("navigation.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("navigation HUD pipeline layout"),
            bind_group_layouts: &[Some(&bind_group_layout)],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("navigation HUD pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                cull_mode: None,
                ..Default::default()
            },
            depth_stencil: None,
            multisample: Default::default(),
            multiview_mask: None,
            cache: None,
        });
        Self {
            pipeline,
            bind_group,
            uniform_buffer,
        }
    }

    pub fn update(
        &self,
        queue: &wgpu::Queue,
        width: u32,
        height: u32,
        north_angle_rad: f32,
        bearing_deg: f32,
        tilt_deg: f32,
        max_tilt_deg: f32,
        scale_bar_pixels: f32,
    ) {
        let layout = NavLayout::new(width, height);
        let uniform = NavUniform {
            viewport: [width.max(1) as f32, height.max(1) as f32, layout.scale, 0.0],
            panel: [
                layout.origin.x - READOUT_WIDTH * layout.scale,
                layout.origin.y,
                layout.size.x + READOUT_WIDTH * layout.scale,
                layout.size.y,
            ],
            values: [
                north_angle_rad,
                (bearing_deg / 360.0).clamp(0.0, 1.0),
                (tilt_deg / max_tilt_deg.max(0.01)).clamp(0.0, 1.0),
                (scale_bar_pixels / layout.scale).clamp(0.0, 120.0),
            ],
        };
        queue.write_buffer(&self.uniform_buffer, 0, bytemuck::bytes_of(&uniform));
    }

    pub fn draw(&self, pass: &mut wgpu::RenderPass<'_>) {
        pass.set_pipeline(&self.pipeline);
        pass.set_bind_group(0, &self.bind_group, &[]);
        pass.draw(0..6, 0..1);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn navigation_shader_is_valid_wgsl() {
        let source = include_str!("navigation.wgsl");
        let module = naga::front::wgsl::parse_str(source).expect("navigation shader parses");
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&module)
        .expect("navigation shader validates");
    }

    #[test]
    fn controls_stay_inside_small_and_large_viewports() {
        for (width, height) in [(360, 260), (1440, 900), (3000, 1800)] {
            let layout = NavLayout::new(width, height);
            assert!(layout.origin.x >= 0.0 && layout.origin.y >= 0.0);
            assert!(layout.origin.x + layout.size.x <= width as f32);
            assert!(layout.origin.y + layout.size.y <= height as f32);
            assert_eq!(
                layout.hit_test(layout.origin + Vec2::new(23.0, 34.0) * layout.scale),
                Some(NavControl::Compass)
            );
        }
    }

    #[test]
    fn bar_hit_testing_clamps_to_both_ends() {
        let layout = NavLayout::new(1440, 900);
        let point = |x, y| layout.origin + Vec2::new(x, y) * layout.scale;
        assert_eq!(
            layout.hit_test(point(160.0, 22.0)),
            Some(NavControl::Heading)
        );
        assert_eq!(layout.hit_test(point(160.0, 46.0)), Some(NavControl::Tilt));
        assert_eq!(layout.hit_test(point(130.0, 34.0)), None);
        assert_eq!(layout.bar_fraction(point(0.0, 22.0)), 0.0);
        assert_eq!(layout.bar_fraction(point(WIDTH, 22.0)), 1.0);
    }

    #[test]
    fn scale_bar_uses_rounded_distance_within_available_width() {
        let bar = ScaleBar::new(13.0, 120.0).unwrap();
        assert_eq!(bar.distance_m, 1_000.0);
        assert_eq!(bar.label(), "1 公里");
        assert!(bar.pixel_width <= 120.0);
        assert!(ScaleBar::new(f64::NAN, 120.0).is_none());
    }
}
