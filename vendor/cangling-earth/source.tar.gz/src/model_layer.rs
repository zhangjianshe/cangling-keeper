//! Static, self-contained glTF 2.0 models in the globe depth buffer.
use crate::{camera::OrbitCamera, geo, terrain::TerrainLayer};
use glam::{DMat4, DVec3};
use wgpu::util::DeviceExt;
#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct ModelVertex {
    position: [f32; 3],
    normal: [f32; 3],
    uv: [f32; 2],
}
impl ModelVertex {
    fn layout() -> wgpu::VertexBufferLayout<'static> {
        const A: [wgpu::VertexAttribute; 3] =
            wgpu::vertex_attr_array![0=>Float32x3,1=>Float32x3,2=>Float32x2];
        wgpu::VertexBufferLayout {
            array_stride: 32,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &A,
        }
    }
}
struct Layer {
    id: String,
    visible: bool,
    placement: serde_json::Value,
    positions: Vec<DVec3>,
    uvs: Vec<[f32; 2]>,
    vertex: wgpu::Buffer,
    index: wgpu::Buffer,
    _offset: wgpu::Buffer,
    bind: wgpu::BindGroup,
    count: u32,
}
pub struct ModelLayerRenderer {
    pipeline: wgpu::RenderPipeline,
    texture_layout: wgpu::BindGroupLayout,
    layers: Vec<Layer>,
}
struct Part {
    positions: Vec<DVec3>,
    uvs: Vec<[f32; 2]>,
    indices: Vec<u32>,
    texture: image::RgbaImage,
}
fn decode(bytes: &[u8]) -> Result<Vec<Part>, String> {
    if bytes.len() > 16 * 1024 * 1024 {
        return Err("GLB exceeds 16 MiB".into());
    }
    let gltf = gltf::Gltf::from_slice(bytes).map_err(|e| e.to_string())?;
    if gltf.document.extensions_required().next().is_some()
        || gltf.document.skins().next().is_some()
        || gltf.document.animations().next().is_some()
    {
        return Err("Only static core GLB models are supported (no required extensions, skins or animation)".into());
    }
    let blob = gltf.blob.as_deref().ok_or("GLB binary chunk missing")?;
    if gltf
        .document
        .buffers()
        .any(|b| !matches!(b.source(), gltf::buffer::Source::Bin))
    {
        return Err("External buffers are unsupported".into());
    }
    let scene = gltf
        .document
        .default_scene()
        .or_else(|| gltf.document.scenes().next())
        .ok_or("No scene")?;
    let mut parts = Vec::new();
    let mut budget = 0usize;
    let mut visits = 0usize;
    fn visit(
        node: gltf::Node,
        parent: DMat4,
        blob: &[u8],
        parts: &mut Vec<Part>,
        budget: &mut usize,
        visits: &mut usize,
        depth: usize,
    ) -> Result<(), String> {
        *visits += 1;
        if depth > 64 || *visits > 1024 {
            return Err("Model node limit exceeded".into());
        }
        let t = parent
            * DMat4::from_cols_array_2d(&node.transform().matrix().map(|c| c.map(f64::from)));
        if let Some(mesh) = node.mesh() {
            for p in mesh.primitives() {
                if p.mode() != gltf::mesh::Mode::Triangles || p.morph_targets().next().is_some() {
                    return Err("Only static triangle primitives supported".into());
                }
                let reader = p.reader(|b| {
                    if matches!(b.source(), gltf::buffer::Source::Bin) {
                        Some(blob)
                    } else {
                        None
                    }
                });
                let position = reader.read_positions().ok_or("Missing positions")?;
                *budget += position.len();
                if *budget > 250000 || parts.len() >= 64 {
                    return Err("Model geometry limit exceeded".into());
                }
                let positions: Vec<_> = position
                    .map(|v| t.transform_point3(DVec3::from_array(v.map(f64::from))))
                    .collect();
                if positions.is_empty()
                    || positions
                        .iter()
                        .any(|p| !p.is_finite() || p.abs().max_element() > 1e7)
                {
                    return Err("Invalid model positions".into());
                }
                let indices = reader
                    .read_indices()
                    .map(|i| i.into_u32().collect::<Vec<_>>())
                    .unwrap_or_else(|| (0..positions.len() as u32).collect());
                if indices.is_empty()
                    || indices.len() > 750000
                    || indices.len() % 3 != 0
                    || indices.iter().any(|i| *i as usize >= positions.len())
                {
                    return Err("Invalid triangle indices".into());
                }
                let mat = p.material().pbr_metallic_roughness();
                let tex = mat.base_color_texture();
                let uvs = reader
                    .read_tex_coords(tex.as_ref().map(|v| v.tex_coord()).unwrap_or(0))
                    .map(|uv| uv.into_f32().collect::<Vec<_>>())
                    .unwrap_or_else(|| vec![[0.; 2]; positions.len()]);
                if uvs.len() != positions.len() || uvs.iter().flatten().any(|n| !n.is_finite()) {
                    return Err("Invalid texture coordinates".into());
                }
                let mut texture = if let Some(tex) = tex {
                    match tex.texture().source().source() {
                        gltf::image::Source::View { view, .. } => {
                            let data = blob
                                .get(view.offset()..view.offset() + view.length())
                                .ok_or("Invalid embedded texture")?;
                            let (w, h) = image::ImageReader::new(std::io::Cursor::new(data))
                                .with_guessed_format()
                                .map_err(|e| e.to_string())?
                                .into_dimensions()
                                .map_err(|e| e.to_string())?;
                            if w > 4096 || h > 4096 || u64::from(w) * u64::from(h) > 4_194_304 {
                                return Err("Texture exceeds 4 megapixels".into());
                            }
                            image::load_from_memory(data)
                                .map_err(|e| e.to_string())?
                                .thumbnail(2048, 2048)
                                .to_rgba8()
                        }
                        _ => {
                            return Err(
                                "External textures are unsupported; embed images in GLB".into()
                            );
                        }
                    }
                } else {
                    image::RgbaImage::from_pixel(1, 1, image::Rgba([255; 4]))
                };
                let factor = mat.base_color_factor();
                for px in texture.pixels_mut() {
                    for i in 0..4 {
                        px[i] = (px[i] as f32 * factor[i].clamp(0., 1.)) as u8;
                    }
                }
                if parts
                    .iter()
                    .map(|p| p.texture.as_raw().len())
                    .sum::<usize>()
                    + texture.as_raw().len()
                    > 32 * 1024 * 1024
                {
                    return Err("Model texture budget exceeds 32 MiB".into());
                }
                parts.push(Part {
                    positions,
                    uvs,
                    indices,
                    texture,
                });
            }
        }
        for child in node.children() {
            visit(child, t, blob, parts, budget, visits, depth + 1)?;
        }
        Ok(())
    }
    for node in scene.nodes() {
        visit(
            node,
            DMat4::IDENTITY,
            blob,
            &mut parts,
            &mut budget,
            &mut visits,
            0,
        )?;
    }
    if parts.is_empty() {
        return Err("Model has no mesh".into());
    }
    Ok(parts)
}
impl ModelLayerRenderer {
    pub fn new(
        device: &wgpu::Device,
        surface_format: wgpu::TextureFormat,
        camera_layout: &wgpu::BindGroupLayout,
    ) -> Self {
        let texture_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("GLB model texture layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
            ],
        });
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("GLB model shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("model_layer.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("GLB model pipeline layout"),
            bind_group_layouts: &[Some(camera_layout), Some(&texture_layout)],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("GLB model pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[Some(ModelVertex::layout())],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: surface_format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                cull_mode: None,
                front_face: wgpu::FrontFace::Ccw,
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: Some(true),
                depth_compare: Some(wgpu::CompareFunction::LessEqual),
                stencil: Default::default(),
                bias: wgpu::DepthBiasState {
                    constant: 0,
                    slope_scale: 0.0,
                    clamp: 0.0,
                },
            }),
            multisample: Default::default(),
            multiview_mask: None,
            cache: None,
        });

        Self {
            pipeline,
            texture_layout,
            layers: Vec::new(),
        }
    }
    pub fn scene(&mut self, values: &serde_json::Value) -> Result<(), String> {
        let list = values
            .as_array()
            .filter(|a| a.len() <= 8)
            .ok_or("Invalid model scene")?;
        self.layers
            .retain(|l| list.iter().any(|v| v["id"].as_str() == Some(&l.id)));
        for l in &mut self.layers {
            if let Some(v) = list.iter().find(|v| v["id"].as_str() == Some(&l.id)) {
                l.visible = v["visible"] == true;
                l.placement = v.clone();
            }
        }
        Ok(())
    }
    pub fn upload(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        id: &str,
        bytes: &[u8],
        placement: &serde_json::Value,
    ) -> Result<(), String> {
        let parts = decode(bytes)?;
        if self
            .layers
            .iter()
            .map(|v| &v.id)
            .collect::<std::collections::HashSet<_>>()
            .len()
            >= 8
            && !self.layers.iter().any(|l| l.id == id)
        {
            return Err("Model limit exceeded".into());
        }
        let mut added = Vec::new();
        for part in parts {
            let (w, h) = part.texture.dimensions();
            let texture = device.create_texture_with_data(
                queue,
                &wgpu::TextureDescriptor {
                    label: Some("Geographic image"),
                    size: wgpu::Extent3d {
                        width: w,
                        height: h,
                        depth_or_array_layers: 1,
                    },
                    mip_level_count: 1,
                    sample_count: 1,
                    dimension: wgpu::TextureDimension::D2,
                    format: wgpu::TextureFormat::Rgba8UnormSrgb,
                    usage: wgpu::TextureUsages::TEXTURE_BINDING,
                    view_formats: &[],
                },
                wgpu::util::TextureDataOrder::LayerMajor,
                part.texture.as_raw(),
            );
            let view = texture.create_view(&Default::default());
            let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
                mag_filter: wgpu::FilterMode::Linear,
                min_filter: wgpu::FilterMode::Linear,
                ..Default::default()
            });
            let offset = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::cast_slice(&[0f32; 4]),
                usage: wgpu::BufferUsages::UNIFORM,
            });
            let bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &self.texture_layout,
                entries: &[
                    wgpu::BindGroupEntry {
                        binding: 0,
                        resource: wgpu::BindingResource::TextureView(&view),
                    },
                    wgpu::BindGroupEntry {
                        binding: 1,
                        resource: wgpu::BindingResource::Sampler(&sampler),
                    },
                    wgpu::BindGroupEntry {
                        binding: 2,
                        resource: offset.as_entire_binding(),
                    },
                ],
            });

            let vertex = device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("GLB vertices"),
                size: (part.positions.len() * 32) as u64,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
            let index = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("GLB indices"),
                contents: bytemuck::cast_slice(&part.indices),
                usage: wgpu::BufferUsages::INDEX,
            });
            added.push(Layer {
                id: id.into(),
                visible: true,
                placement: placement.clone(),
                positions: part.positions,
                uvs: part.uvs,
                vertex,
                index,
                _offset: offset,
                bind,
                count: part.indices.len() as u32,
            });
        }
        self.layers.retain(|l| l.id != id);
        self.layers.extend(added);
        Ok(())
    }
    pub fn update(&self, queue: &wgpu::Queue, camera: &OrbitCamera, terrain: &TerrainLayer) {
        for l in self.layers.iter().filter(|l| l.visible) {
            let lon = l.placement["longitude"].as_f64().unwrap_or(0.).to_radians();
            let lat = l.placement["latitude"].as_f64().unwrap_or(0.).to_radians();
            let height = l.placement["height"].as_f64().unwrap_or(0.)
                + if l.placement["altitudeMode"] == "absolute" {
                    0.
                } else {
                    terrain.sample(lat, lon)
                };
            let anchor = geo::geodetic_position(lat, lon, height);
            let up = DVec3::new(lat.cos() * lon.sin(), lat.sin(), lat.cos() * lon.cos());
            let east = DVec3::new(lon.cos(), 0., -lon.sin());
            let north = up.cross(east);
            let angle = l.placement["heading"].as_f64().unwrap_or(0.).to_radians();
            let scale = l.placement["scale"].as_f64().unwrap_or(1.);
            let vertices: Vec<_> = l
                .positions
                .iter()
                .zip(&l.uvs)
                .map(|(p, uv)| {
                    let x = (p.x * angle.cos() - p.z * angle.sin()) * scale;
                    let z = (p.x * angle.sin() + p.z * angle.cos()) * scale;
                    let world = anchor + east * x + up * p.y * scale - north * z;
                    ModelVertex {
                        position: ((world - camera.eye_m()) / geo::SEMI_MAJOR_M)
                            .as_vec3()
                            .to_array(),
                        normal: [0.; 3],
                        uv: *uv,
                    }
                })
                .collect();
            queue.write_buffer(&l.vertex, 0, bytemuck::cast_slice(&vertices));
        }
    }
    pub fn draw<'a>(&'a self, pass: &mut wgpu::RenderPass<'a>, camera: &'a wgpu::BindGroup) {
        pass.set_pipeline(&self.pipeline);
        pass.set_bind_group(0, camera, &[]);
        for l in self.layers.iter().filter(|l| l.visible) {
            pass.set_bind_group(1, &l.bind, &[]);
            pass.set_vertex_buffer(0, l.vertex.slice(..));
            pass.set_index_buffer(l.index.slice(..), wgpu::IndexFormat::Uint32);
            pass.draw_indexed(0..l.count, 0, 0..1);
        }
    }
}
#[cfg(all(test, not(target_arch = "wasm32")))]
mod gpu_test {
    use wgpu::util::DeviceExt;
    #[test]
    #[ignore = "requires EARTH_TEST_GLB sample asset and GPU"]
    fn upload_native_model() {
        pollster::block_on(async {
            let instance = wgpu::Instance::default();
            let adapter = instance
                .request_adapter(&wgpu::RequestAdapterOptions::default())
                .await
                .expect("GPU adapter");
            let (device, queue) = adapter
                .request_device(&wgpu::DeviceDescriptor::default())
                .await
                .unwrap();
            let layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                }],
            });
            let mut renderer =
                super::ModelLayerRenderer::new(&device, wgpu::TextureFormat::Rgba8Unorm, &layout);
            let path = std::env::var("EARTH_TEST_GLB")
                .expect("Set EARTH_TEST_GLB to a self-contained static GLB fixture");
            let bytes = std::fs::read(path).unwrap();
            let placement = serde_json::json!({"id":"test","visible":true,"longitude":111.645,"latitude":32.749,"height":10,"scale":20,"heading":0,"altitudeMode":"relativeToGround"});
            renderer
                .upload(&device, &queue, "test", &bytes, &placement)
                .unwrap();
            let camera = crate::camera::OrbitCamera::new(winit::dpi::PhysicalSize::new(800, 600));
            renderer.update(&queue, &camera, &crate::terrain::TerrainLayer::new());
            let mut uniform = vec![0f32; 20];
            uniform[..16].copy_from_slice(&glam::Mat4::IDENTITY.to_cols_array());
            let buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::cast_slice(&uniform),
                usage: wgpu::BufferUsages::UNIFORM,
            });
            let camera_bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &layout,
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: buffer.as_entire_binding(),
                }],
            });
            let target = |format, usage| {
                device
                    .create_texture(&wgpu::TextureDescriptor {
                        label: None,
                        size: wgpu::Extent3d {
                            width: 800,
                            height: 600,
                            depth_or_array_layers: 1,
                        },
                        mip_level_count: 1,
                        sample_count: 1,
                        dimension: wgpu::TextureDimension::D2,
                        format,
                        usage,
                        view_formats: &[],
                    })
                    .create_view(&Default::default())
            };
            let color = target(
                wgpu::TextureFormat::Rgba8Unorm,
                wgpu::TextureUsages::RENDER_ATTACHMENT,
            );
            let depth = target(
                wgpu::TextureFormat::Depth32Float,
                wgpu::TextureUsages::RENDER_ATTACHMENT,
            );
            let mut encoder = device.create_command_encoder(&Default::default());
            {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: None,
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &color,
                        resolve_target: None,
                        depth_slice: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                        view: &depth,
                        depth_ops: Some(wgpu::Operations {
                            load: wgpu::LoadOp::Clear(1.),
                            store: wgpu::StoreOp::Store,
                        }),
                        stencil_ops: None,
                    }),
                    timestamp_writes: None,
                    occlusion_query_set: None,
                    multiview_mask: None,
                });
                renderer.draw(&mut pass, &camera_bind);
            }
            queue.submit(Some(encoder.finish()));
            assert_eq!(renderer.layers.len(), 1);
            renderer
                .scene(&serde_json::json!([{"id":"test","visible":false}]))
                .unwrap();
            assert!(!renderer.layers[0].visible);
            renderer.scene(&serde_json::json!([])).unwrap();
            assert!(renderer.layers.is_empty());
        });
    }
}
