//! Static, self-contained glTF 2.0 models in the globe depth buffer.
use crate::{camera::OrbitCamera, geo, terrain::TerrainLayer};
use glam::{DMat3, DMat4, DVec3};
use wgpu::util::DeviceExt;
#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct ModelVertex {
    position: [f32; 3],
    normal: [f32; 3],
    uv: [f32; 2],
}
impl ModelVertex {
    fn layout() -> wgpu::VertexBufferLayout<'static> {
        const A: [wgpu::VertexAttribute; 3] =
            wgpu::vertex_attr_array![0=>Float32x3,1=>Float32x3,2=>Float32x2];
        wgpu::VertexBufferLayout {
            array_stride: 32,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &A,
        }
    }
}
struct Layer {
    joint: String,
    id: String,
    visible: bool,
    placement: serde_json::Value,
    positions: Vec<DVec3>,
    normals: Vec<DVec3>,
    uvs: Vec<[f32; 2]>,
    vertex: wgpu::Buffer,
    index: wgpu::Buffer,
    _offset: wgpu::Buffer,
    bind: wgpu::BindGroup,
    count: u32,
    cost: usize,
}
pub struct ModelLayerRenderer {
    walker_pose: Option<crate::walker_animation::WalkerPose>,
    pipeline: wgpu::RenderPipeline,
    texture_layout: wgpu::BindGroupLayout,
    layers: Vec<Layer>,
    limit: usize,
    memory_limit: usize,
    vertex_limit: usize,
}
struct Part {
    joint: String,
    positions: Vec<DVec3>,
    normals: Vec<DVec3>,
    uvs: Vec<[f32; 2]>,
    indices: Vec<u32>,
    texture: image::RgbaImage,
}
fn normal_matrix(transform: DMat3) -> Result<DMat3, String> {
    let determinant = transform.determinant();
    if !determinant.is_finite() || determinant.abs() < 1e-20 {
        return Err("Singular model normal transform".into());
    }
    Ok(transform.inverse().transpose())
}
fn generated_normals(positions: &[DVec3], indices: &[u32]) -> Vec<DVec3> {
    let mut normals = vec![DVec3::ZERO; positions.len()];
    for face in indices.chunks_exact(3) {
        let [a, b, c] = [face[0] as usize, face[1] as usize, face[2] as usize];
        let n = (positions[b] - positions[a]).cross(positions[c] - positions[a]);
        for i in [a, b, c] {
            normals[i] += n;
        }
    }
    normals
        .into_iter()
        .map(|n| n.try_normalize().unwrap_or(DVec3::Y))
        .collect()
}
fn decode(bytes: &[u8], vertex_limit: usize) -> Result<Vec<Part>, String> {
    if bytes.len() > 16 * 1024 * 1024 {
        return Err("GLB exceeds 16 MiB".into());
    }
    let gltf = gltf::Gltf::from_slice(bytes).map_err(|e| e.to_string())?;
    if gltf.document.extensions_required().next().is_some()
        || gltf.document.skins().next().is_some()
        || gltf.document.animations().next().is_some()
    {
        return Err("Only static core GLB models are supported (no required extensions, skins or animation)".into());
    }
    let blob = gltf.blob.as_deref().ok_or("GLB binary chunk missing")?;
    if gltf
        .document
        .buffers()
        .any(|b| !matches!(b.source(), gltf::buffer::Source::Bin))
    {
        return Err("External buffers are unsupported".into());
    }
    let scene = gltf
        .document
        .default_scene()
        .or_else(|| gltf.document.scenes().next())
        .ok_or("No scene")?;
    let mut parts = Vec::new();
    let mut budget = 0usize;
    let mut visits = 0usize;
    fn visit(
        node: gltf::Node,
        parent: DMat4,
        blob: &[u8],
        parts: &mut Vec<Part>,
        budget: &mut usize,
        visits: &mut usize,
        depth: usize,
        vertex_limit: usize,
    ) -> Result<(), String> {
        *visits += 1;
        if depth > 64 || *visits > 1024 {
            return Err("Model node limit exceeded".into());
        }
        let t = parent
            * DMat4::from_cols_array_2d(&node.transform().matrix().map(|c| c.map(f64::from)));
        if let Some(mesh) = node.mesh() {
            for p in mesh.primitives() {
                if p.mode() != gltf::mesh::Mode::Triangles || p.morph_targets().next().is_some() {
                    return Err("Only static triangle primitives supported".into());
                }
                let reader = p.reader(|b| {
                    if matches!(b.source(), gltf::buffer::Source::Bin) {
                        Some(blob)
                    } else {
                        None
                    }
                });
                let position = reader.read_positions().ok_or("Missing positions")?;
                *budget += position.len();
                if *budget > vertex_limit || parts.len() >= 64 {
                    return Err("Model geometry limit exceeded".into());
                }
                let positions: Vec<_> = position
                    .map(|v| t.transform_point3(DVec3::from_array(v.map(f64::from))))
                    .collect();
                if positions.is_empty()
                    || positions
                        .iter()
                        .any(|p| !p.is_finite() || p.abs().max_element() > 1e7)
                {
                    return Err("Invalid model positions".into());
                }
                let indices = reader
                    .read_indices()
                    .map(|i| i.into_u32().collect::<Vec<_>>())
                    .unwrap_or_else(|| (0..positions.len() as u32).collect());
                if indices.is_empty()
                    || indices.len() > 750000
                    || indices.len() % 3 != 0
                    || indices.iter().any(|i| *i as usize >= positions.len())
                {
                    return Err("Invalid triangle indices".into());
                }
                let normals = if let Some(normals) = reader.read_normals() {
                    let matrix = normal_matrix(DMat3::from_mat4(t))?;
                    let values: Vec<DVec3> = normals
                        .map(|n| matrix * DVec3::from_array(n.map(f64::from)))
                        .collect();
                    if values.len() != positions.len()
                        || values
                            .iter()
                            .any(|n| !n.is_finite() || n.length_squared() < 1e-20)
                    {
                        return Err("Invalid model normals".into());
                    }
                    values.into_iter().map(|n| n.normalize()).collect()
                } else {
                    generated_normals(&positions, &indices)
                };
                let mat = p.material().pbr_metallic_roughness();
                let tex = mat.base_color_texture();
                let uvs = reader
                    .read_tex_coords(tex.as_ref().map(|v| v.tex_coord()).unwrap_or(0))
                    .map(|uv| uv.into_f32().collect::<Vec<_>>())
                    .unwrap_or_else(|| vec![[0.; 2]; positions.len()]);
                if uvs.len() != positions.len() || uvs.iter().flatten().any(|n| !n.is_finite()) {
                    return Err("Invalid texture coordinates".into());
                }
                let mut texture = if let Some(tex) = tex {
                    match tex.texture().source().source() {
                        gltf::image::Source::View { view, .. } => {
                            let data = blob
                                .get(view.offset()..view.offset() + view.length())
                                .ok_or("Invalid embedded texture")?;
                            let (w, h) = image::ImageReader::new(std::io::Cursor::new(data))
                                .with_guessed_format()
                                .map_err(|e| e.to_string())?
                                .into_dimensions()
                                .map_err(|e| e.to_string())?;
                            if w > 4096 || h > 4096 || u64::from(w) * u64::from(h) > 4_194_304 {
                                return Err("Texture exceeds 4 megapixels".into());
                            }
                            image::load_from_memory(data)
                                .map_err(|e| e.to_string())?
                                .thumbnail(2048, 2048)
                                .to_rgba8()
                        }
                        _ => {
                            return Err(
                                "External textures are unsupported; embed images in GLB".into()
                            );
                        }
                    }
                } else {
                    image::RgbaImage::from_pixel(1, 1, image::Rgba([255; 4]))
                };
                let factor = mat.base_color_factor();
                for px in texture.pixels_mut() {
                    for i in 0..4 {
                        px[i] = (px[i] as f32 * factor[i].clamp(0., 1.)) as u8;
                    }
                }
                if parts
                    .iter()
                    .map(|p| p.texture.as_raw().len())
                    .sum::<usize>()
                    + texture.as_raw().len()
                    > 32 * 1024 * 1024
                {
                    return Err("Model texture budget exceeds 32 MiB".into());
                }
                parts.push(Part {
                    joint: node.name().unwrap_or("").into(),
                    positions,
                    normals,
                    uvs,
                    indices,
                    texture,
                });
            }
        }
        for child in node.children() {
            visit(
                child,
                t,
                blob,
                parts,
                budget,
                visits,
                depth + 1,
                vertex_limit,
            )?;
        }
        Ok(())
    }
    for node in scene.nodes() {
        visit(
            node,
            DMat4::IDENTITY,
            blob,
            &mut parts,
            &mut budget,
            &mut visits,
            0,
            vertex_limit,
        )?;
    }
    if parts.is_empty() {
        return Err("Model has no mesh".into());
    }
    Ok(parts)
}
impl ModelLayerRenderer {
    pub fn new(
        device: &wgpu::Device,
        surface_format: wgpu::TextureFormat,
        camera_layout: &wgpu::BindGroupLayout,
    ) -> Self {
        let texture_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("GLB model texture layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
            ],
        });
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("GLB model shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("model_layer.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("GLB model pipeline layout"),
            bind_group_layouts: &[Some(camera_layout), Some(&texture_layout)],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("GLB model pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[Some(ModelVertex::layout())],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: surface_format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                cull_mode: None,
                front_face: wgpu::FrontFace::Ccw,
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: Some(true),
                depth_compare: Some(wgpu::CompareFunction::LessEqual),
                stencil: Default::default(),
                bias: wgpu::DepthBiasState {
                    constant: 0,
                    slope_scale: 0.0,
                    clamp: 0.0,
                },
            }),
            multisample: Default::default(),
            multiview_mask: None,
            cache: None,
        });

        Self {
            walker_pose:None,
            pipeline,
            texture_layout,
            layers: Vec::new(),
            limit: 8,
            memory_limit: 256 * 1024 * 1024,
            vertex_limit: 250000,
        }
    }
    pub fn set_walker_pose(&mut self,pose:Option<crate::walker_animation::WalkerPose>){self.walker_pose=pose;}
    pub fn for_tiles(mut self) -> Self {
        self.limit = 128;
        self.vertex_limit = 500000;
        self.memory_limit = 128 * 1024 * 1024;
        self
    }
    pub fn scene(&mut self, values: &serde_json::Value) -> Result<(), String> {
        let list = values
            .as_array()
            .filter(|a| a.len() <= self.limit)
            .ok_or("Invalid model scene")?;
        self.layers
            .retain(|l| list.iter().any(|v| v["id"].as_str() == Some(&l.id)));
        for l in &mut self.layers {
            if let Some(v) = list.iter().find(|v| v["id"].as_str() == Some(&l.id)) {
                l.visible = v["visible"] == true;
                let rtc = l.placement.get("rtcCenter").cloned();
                l.placement = v.clone();
                if let Some(rtc) = rtc {
                    l.placement["rtcCenter"] = rtc;
                }
            }
        }
        Ok(())
    }
    pub fn upload(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        id: &str,
        bytes: &[u8],
        placement: &serde_json::Value,
    ) -> Result<(), String> {
        let parts = decode(bytes, self.vertex_limit)?;
        let cost: usize = parts
            .iter()
            .map(|p| p.positions.len() * 88 + p.indices.len() * 4 + p.texture.as_raw().len() * 2)
            .sum();
        let retained: usize = self
            .layers
            .iter()
            .filter(|p| p.id != id)
            .map(|p| p.cost)
            .sum();
        if retained + cost > self.memory_limit {
            return Err("Tile GPU/CPU cache budget exceeded".into());
        }
        if self
            .layers
            .iter()
            .map(|v| &v.id)
            .collect::<std::collections::HashSet<_>>()
            .len()
            >= self.limit
            && !self.layers.iter().any(|l| l.id == id)
        {
            return Err("Model limit exceeded".into());
        }
        let mut added = Vec::new();
        for part in parts {
            let (w, h) = part.texture.dimensions();
            let texture = device.create_texture_with_data(
                queue,
                &wgpu::TextureDescriptor {
                    label: Some("Geographic image"),
                    size: wgpu::Extent3d {
                        width: w,
                        height: h,
                        depth_or_array_layers: 1,
                    },
                    mip_level_count: 1,
                    sample_count: 1,
                    dimension: wgpu::TextureDimension::D2,
                    format: wgpu::TextureFormat::Rgba8UnormSrgb,
                    usage: wgpu::TextureUsages::TEXTURE_BINDING,
                    view_formats: &[],
                },
                wgpu::util::TextureDataOrder::LayerMajor,
                part.texture.as_raw(),
            );
            let view = texture.create_view(&Default::default());
            let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
                mag_filter: wgpu::FilterMode::Linear,
                min_filter: wgpu::FilterMode::Linear,
                ..Default::default()
            });
            let offset = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::cast_slice(&[0f32; 4]),
                usage: wgpu::BufferUsages::UNIFORM,
            });
            let bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &self.texture_layout,
                entries: &[
                    wgpu::BindGroupEntry {
                        binding: 0,
                        resource: wgpu::BindingResource::TextureView(&view),
                    },
                    wgpu::BindGroupEntry {
                        binding: 1,
                        resource: wgpu::BindingResource::Sampler(&sampler),
                    },
                    wgpu::BindGroupEntry {
                        binding: 2,
                        resource: offset.as_entire_binding(),
                    },
                ],
            });

            let vertex = device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("GLB vertices"),
                size: (part.positions.len() * 32) as u64,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
            let index = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("GLB indices"),
                contents: bytemuck::cast_slice(&part.indices),
                usage: wgpu::BufferUsages::INDEX,
            });
            let part_cost = part.positions.len() * 88
                + part.indices.len() * 4
                + part.texture.as_raw().len() * 2;
            added.push(Layer {
                joint:part.joint,
                id: id.into(),
                visible: placement["visible"].as_bool().unwrap_or(true),
                placement: placement.clone(),
                positions: part.positions,
                normals: part.normals,
                uvs: part.uvs,
                vertex,
                index,
                _offset: offset,
                bind,
                cost: part_cost,
                count: part.indices.len() as u32,
            });
        }
        self.layers.retain(|l| l.id != id);
        self.layers.extend(added);
        Ok(())
    }
    pub fn update(&self, queue: &wgpu::Queue, camera: &OrbitCamera, terrain: &TerrainLayer) {
        for l in self.layers.iter().filter(|l| l.visible) {
            let lon = l.placement["longitude"].as_f64().unwrap_or(0.).to_radians();
            let lat = l.placement["latitude"].as_f64().unwrap_or(0.).to_radians();
            let height = l.placement["height"].as_f64().unwrap_or(0.)
                + if l.placement["altitudeMode"] == "absolute" {
                    0.
                } else {
                    terrain.sample(lat, lon)
                };
            let anchor = geo::geodetic_position(lat, lon, height);
            let up = DVec3::new(lat.cos() * lon.sin(), lat.sin(), lat.cos() * lon.cos());
            let east = DVec3::new(lon.cos(), 0., -lon.sin());
            let north = up.cross(east);
            let angle = l.placement["heading"].as_f64().unwrap_or(0.).to_radians();
            let scale = l.placement["scale"].as_f64().unwrap_or(1.);
            let transform = l.placement["ecefTransform"]
                .as_array()
                .filter(|a| a.len() == 16)
                .map(|a| {
                    DMat4::from_cols_slice(
                        &a.iter()
                            .map(|v| v.as_f64().unwrap_or(0.))
                            .collect::<Vec<_>>(),
                    )
                });
            let rtc = l.placement["rtcCenter"]
                .as_array()
                .filter(|a| a.len() == 3)
                .map(|v| {
                    DVec3::new(
                        v[0].as_f64().unwrap_or(0.),
                        v[1].as_f64().unwrap_or(0.),
                        v[2].as_f64().unwrap_or(0.),
                    )
                })
                .unwrap_or(DVec3::ZERO);
            let orientation = if let Some(transform) = transform {
                let y_up_to_z_up = DMat3::from_cols(DVec3::X, DVec3::Z, -DVec3::Y);
                let ecef_to_internal = DMat3::from_cols(DVec3::Z, DVec3::X, DVec3::Y);
                ecef_to_internal * DMat3::from_mat4(transform) * y_up_to_z_up
            } else {
                DMat3::from_cols(
                    east * angle.cos() - north * angle.sin(),
                    up,
                    -east * angle.sin() - north * angle.cos(),
                ) * scale
            };
            let Ok(normal_transform) = normal_matrix(orientation) else {
                continue;
            };
            let vertices: Vec<_> = l
                .positions
                .iter()
                .zip(&l.uvs)
                .zip(&l.normals)
                .map(|((p, uv), normal)| {
                    let (p,normal)=self.walker_pose.map_or((*p,*normal),|pose|pose.transform(&l.joint,*p,*normal));
                    let x = (p.x * angle.cos() - p.z * angle.sin()) * scale;
                    let z = (p.x * angle.sin() + p.z * angle.cos()) * scale;
                    let world = if let Some(transform) = transform {
                        let ecef = transform.transform_point3(DVec3::new(p.x, -p.z, p.y) + rtc);
                        DVec3::new(ecef.y, ecef.z, ecef.x)
                    } else {
                        anchor + east * x + up * p.y * scale - north * z
                    };
                    ModelVertex {
                        position: ((world - camera.eye_m()) / geo::SEMI_MAJOR_M)
                            .as_vec3()
                            .to_array(),
                        normal: (normal_transform * normal)
                            .normalize()
                            .as_vec3()
                            .to_array(),
                        uv: *uv,
                    }
                })
                .collect();
            queue.write_buffer(&l.vertex, 0, bytemuck::cast_slice(&vertices));
        }
    }
    pub fn draw<'a>(&'a self, pass: &mut wgpu::RenderPass<'a>, camera: &'a wgpu::BindGroup) {
        pass.set_pipeline(&self.pipeline);
        pass.set_bind_group(0, camera, &[]);
        for l in self.layers.iter().filter(|l| l.visible) {
            pass.set_bind_group(1, &l.bind, &[]);
            pass.set_vertex_buffer(0, l.vertex.slice(..));
            pass.set_index_buffer(l.index.slice(..), wgpu::IndexFormat::Uint32);
            pass.draw_indexed(0..l.count, 0, 0..1);
        }
    }
}
#[cfg(all(test, not(target_arch = "wasm32")))]
mod gpu_test {
    use wgpu::util::DeviceExt;
    #[test]
    #[ignore = "requires EARTH_TEST_B3DM real fixture"]
    fn decode_real_tiles_budget() {
        let bytes = std::fs::read(std::env::var("EARTH_TEST_B3DM").unwrap()).unwrap();
        let (glb, _) = crate::tiles3d::content(&bytes).unwrap();
        assert!(super::decode(glb, 250000).is_err());
        let parts = super::decode(glb, 500000).unwrap();
        assert_eq!(
            parts.iter().map(|p| p.positions.len()).sum::<usize>(),
            269776
        );
    }
    #[test]
    #[ignore = "requires EARTH_TEST_GLB sample asset and GPU"]
    fn upload_native_model() {
        pollster::block_on(async {
            let instance = wgpu::Instance::default();
            let adapter = instance
                .request_adapter(&wgpu::RequestAdapterOptions::default())
                .await
                .expect("GPU adapter");
            let (device, queue) = adapter
                .request_device(&wgpu::DeviceDescriptor::default())
                .await
                .unwrap();
            let layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                }],
            });
            let mut renderer =
                super::ModelLayerRenderer::new(&device, wgpu::TextureFormat::Rgba8Unorm, &layout);
            let path = std::env::var("EARTH_TEST_GLB")
                .expect("Set EARTH_TEST_GLB to a self-contained static GLB fixture");
            let bytes = std::fs::read(path).unwrap();
            let placement = serde_json::json!({"id":"test","visible":true,"longitude":111.645,"latitude":32.749,"height":10,"scale":20,"heading":0,"altitudeMode":"relativeToGround"});
            renderer
                .upload(&device, &queue, "test", &bytes, &placement)
                .unwrap();
            let camera = crate::camera::OrbitCamera::new(winit::dpi::PhysicalSize::new(800, 600));
            renderer.update(&queue, &camera, &crate::terrain::TerrainLayer::new());
            let mut uniform = vec![0f32; 20];
            uniform[..16].copy_from_slice(&glam::Mat4::IDENTITY.to_cols_array());
            let buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::cast_slice(&uniform),
                usage: wgpu::BufferUsages::UNIFORM,
            });
            let camera_bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &layout,
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: buffer.as_entire_binding(),
                }],
            });
            let target = |format, usage| {
                device
                    .create_texture(&wgpu::TextureDescriptor {
                        label: None,
                        size: wgpu::Extent3d {
                            width: 800,
                            height: 600,
                            depth_or_array_layers: 1,
                        },
                        mip_level_count: 1,
                        sample_count: 1,
                        dimension: wgpu::TextureDimension::D2,
                        format,
                        usage,
                        view_formats: &[],
                    })
                    .create_view(&Default::default())
            };
            let color = target(
                wgpu::TextureFormat::Rgba8Unorm,
                wgpu::TextureUsages::RENDER_ATTACHMENT,
            );
            let depth = target(
                wgpu::TextureFormat::Depth32Float,
                wgpu::TextureUsages::RENDER_ATTACHMENT,
            );
            let mut encoder = device.create_command_encoder(&Default::default());
            {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: None,
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &color,
                        resolve_target: None,
                        depth_slice: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                        view: &depth,
                        depth_ops: Some(wgpu::Operations {
                            load: wgpu::LoadOp::Clear(1.),
                            store: wgpu::StoreOp::Store,
                        }),
                        stencil_ops: None,
                    }),
                    timestamp_writes: None,
                    occlusion_query_set: None,
                    multiview_mask: None,
                });
                renderer.draw(&mut pass, &camera_bind);
            }
            queue.submit(Some(encoder.finish()));
            assert_eq!(renderer.layers.len(), 1);
            renderer
                .scene(&serde_json::json!([{"id":"test","visible":false}]))
                .unwrap();
            assert!(!renderer.layers[0].visible);
            renderer.scene(&serde_json::json!([])).unwrap();
            assert!(renderer.layers.is_empty());
        });
    }
}

#[cfg(test)]
mod normal_tests {
    use super::*;
    #[test]
    fn generates_area_weighted_normals_and_handles_unused_vertices() {
        let vertices = [DVec3::ZERO, DVec3::X, DVec3::Y, DVec3::Z, DVec3::splat(5.)];
        let normals = generated_normals(&vertices, &[0, 1, 2, 0, 3, 1]);
        assert!(normals[0].distance((DVec3::Y + DVec3::Z).normalize()) < 1e-12);
        assert_eq!(normals[2], DVec3::Z);
        assert_eq!(normals[4], DVec3::Y);
        assert!(normals
            .iter()
            .all(|n| n.is_finite() && (n.length() - 1.).abs() < 1e-12));
    }
    #[test]
    fn inverse_transpose_preserves_perpendicularity_under_nonuniform_scale() {
        let transform = DMat3::from_diagonal(DVec3::new(2., 3., 4.));
        let tangent = DVec3::new(1., 1., 0.);
        let normal = DVec3::new(1., -1., 0.).normalize();
        let result = normal_matrix(transform).unwrap() * normal;
        assert!(result.dot(transform * tangent).abs() < 1e-12);
        assert!(normal_matrix(DMat3::ZERO).is_err());
        let mirrored = DMat3::from_diagonal(DVec3::new(-1., 2., 3.));
        assert_eq!(
            (normal_matrix(mirrored).unwrap() * DVec3::X).normalize(),
            -DVec3::X
        );
    }
}

#[cfg(test)]
mod walker_asset_tests {
    #[test]
    fn embedded_walker_has_named_rigid_joints_and_a_front_visor() {
        let parts=super::decode(include_bytes!("../assets/walker.glb"),10000).unwrap();
        assert_eq!(parts.len(),7);assert!(parts.iter().map(|p|p.positions.len()).sum::<usize>()<1000);
        for name in ["torso","head","left_arm","right_arm","left_leg","right_leg"] {assert!(parts.iter().any(|p|p.joint==name));}
        assert!(parts.last().unwrap().positions.iter().all(|p|p.z<0.),"visor identifies -Z as forward");
    }
}
