//! Local-space triangle BVH. Queries return a segment fraction, preserving
//! nonuniform scale and geospatial transforms without rebuilding the tree.
use glam::DVec3;
struct Node { min:DVec3,max:DVec3,start:usize,end:usize,children:Option<(usize,usize)> }
pub struct Collider {triangles:Vec<[u32;3]>,nodes:Vec<Node>}
impl Collider {
    pub fn new(positions:&[DVec3],indices:&[u32])->Self {
        let mut value=Self{triangles:indices.chunks_exact(3).map(|t|[t[0],t[1],t[2]]).collect(),nodes:Vec::new()};
        if !value.triangles.is_empty(){value.build(positions,0,value.triangles.len());}value
    }
    fn build(&mut self,p:&[DVec3],start:usize,end:usize)->usize {
        let mut min=DVec3::splat(f64::INFINITY);let mut max=DVec3::splat(f64::NEG_INFINITY);
        for t in &self.triangles[start..end]{for &i in t{min=min.min(p[i as usize]);max=max.max(p[i as usize]);}}
        let id=self.nodes.len();self.nodes.push(Node{min,max,start,end,children:None});
        if end-start>8 {
            let extent=max-min;let axis=if extent.x>=extent.y&&extent.x>=extent.z{0}else if extent.y>=extent.z{1}else{2};
            let middle=start+(end-start)/2;
            self.triangles[start..end].select_nth_unstable_by(middle-start,|a,b|{
                let center=|t:&[u32;3]|(p[t[0] as usize][axis]+p[t[1] as usize][axis]+p[t[2] as usize][axis])/3.;
                center(a).total_cmp(&center(b))
            });
            let left=self.build(p,start,middle);let right=self.build(p,middle,end);self.nodes[id].children=Some((left,right));
        }id
    }
    pub fn hit(&self,p:&[DVec3],start:DVec3,end:DVec3)->Option<f64> {
        self.hit_filtered(p,start,end,|_|true)
    }
    pub fn hit_filtered(&self,p:&[DVec3],start:DVec3,end:DVec3,accept:impl Fn(DVec3)->bool)->Option<f64> {
        if self.nodes.is_empty()||!start.is_finite()||!end.is_finite(){return None;}
        let direction=end-start;if direction.length_squared()<1e-16{return None;}
        let mut nearest=1.;let mut found=false;let mut stack=vec![0];
        while let Some(id)=stack.pop(){let node=&self.nodes[id];
            if !bounds_hit(node.min,node.max,start,direction,nearest){continue;}
            if let Some((a,b))=node.children{stack.push(a);stack.push(b);}else{
                for triangle in &self.triangles[node.start..node.end]{
                    let a=p[triangle[0] as usize];let b=p[triangle[1] as usize];let c=p[triangle[2] as usize];
                    let edge1=b-a;let edge2=c-a;if !accept(edge1.cross(edge2)){continue;}let h=direction.cross(edge2);let determinant=edge1.dot(h);
                    if determinant.abs()<1e-12{continue;}
                    let s=start-a;let u=s.dot(h)/determinant;if !(0.0..=1.0).contains(&u){continue;}
                    let q=s.cross(edge1);let v=direction.dot(q)/determinant;if v<0.||u+v>1.{continue;}
                    let t=edge2.dot(q)/determinant;if t>1e-8&&t<=nearest{nearest=t;found=true;}
                }
            }
        }found.then_some(nearest)
    }
}
fn bounds_hit(min:DVec3,max:DVec3,start:DVec3,d:DVec3,limit:f64)->bool {
    let mut lo:f64=0.;let mut hi=limit;
    for axis in 0..3 {
        if d[axis].abs()<1e-15 {if start[axis]<min[axis]-1e-8||start[axis]>max[axis]+1e-8{return false;}}
        else {let a=(min[axis]-start[axis])/d[axis];let b=(max[axis]-start[axis])/d[axis];lo=lo.max(a.min(b));hi=hi.min(a.max(b));if lo>hi{return false;}}
    }true
}
/// Approximate a standing body with three heights and three lateral rays.
/// Extending rays by the body radius prevents high-speed wall tunnelling.
pub fn body_fraction(start:DVec3,end:DVec3,up:DVec3,mut hit:impl FnMut(DVec3,DVec3)->Option<f64>)->f64 {
    let delta=end-start;let distance=delta.length();if distance<1e-6{return 1.;}
    let direction=delta/distance;let side=direction.cross(up).normalize_or_zero();let radius=0.25;
    let mut fraction:f64=1.;
    for height in [0.3,0.9,1.6]{for lateral in [-radius,0.,radius]{
        let offset=up*height+side*lateral;
        if let Some(t)=hit(start+offset,end+offset+direction*radius){fraction=fraction.min(((t*(distance+radius)-radius-0.02)/distance).clamp(0.,1.));}
    }}fraction
}
#[cfg(test)]mod tests{
 use super::*;
 fn wall()->(Vec<DVec3>,Vec<u32>){(vec![DVec3::new(0.,-10.,-10.),DVec3::new(0.,10.,-10.),DVec3::new(0.,10.,10.),DVec3::new(0.,-10.,10.)],vec![0,1,2,0,2,3])}
 #[test]fn walls_are_two_sided_and_fast_motion_stops(){let(p,i)=wall();let c=Collider::new(&p,&i);assert_eq!(c.hit(&p,DVec3::new(-2.,0.,0.),DVec3::new(2.,0.,0.)),Some(0.5));assert_eq!(c.hit(&p,DVec3::new(2.,0.,0.),DVec3::new(-2.,0.,0.)),Some(0.5));let f=body_fraction(DVec3::new(-2.,0.,0.),DVec3::new(38.,0.,0.),DVec3::Y,|a,b|c.hit(&p,a,b));assert!((-2.+40.*f+0.27).abs()<1e-8);}
 #[test]fn no_false_hit_outside_triangles_or_parallel(){let(p,i)=wall();let c=Collider::new(&p,&i);assert!(c.hit(&p,DVec3::new(-2.,20.,0.),DVec3::new(2.,20.,0.)).is_none());assert!(c.hit(&p,DVec3::new(-2.,0.,0.),DVec3::new(-2.,1.,0.)).is_none());assert!(c.hit(&p,DVec3::ZERO,DVec3::ZERO).is_none());}
 #[test]fn bvh_finds_nearest_of_many_walls(){let(mut p,mut i)=wall();for x in 1..40{let(base,idx)=wall();let offset=p.len() as u32;p.extend(base.into_iter().map(|v|v+DVec3::X*x as f64));i.extend(idx.into_iter().map(|v|v+offset));}let c=Collider::new(&p,&i);assert!((c.hit(&p,DVec3::new(-1.,0.,0.),DVec3::new(50.,0.,0.)).unwrap()-1./51.).abs()<1e-9);}
}
