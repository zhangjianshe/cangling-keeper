use std::{
    collections::{HashMap, HashSet},
    sync::{Arc, RwLock},
};

#[cfg(target_arch = "wasm32")]
use std::{cell::Cell, rc::Rc};
#[cfg(not(target_arch = "wasm32"))]
use std::{
    fs,
    path::{Path, PathBuf},
    thread,
    time::Duration,
};

#[cfg(not(target_arch = "wasm32"))]
use anyhow::anyhow;
use anyhow::{Context, Result};
use crossbeam_channel::{Receiver, Sender, unbounded};
use image::ImageReader;
#[cfg(target_arch = "wasm32")]
use wasm_bindgen_futures::spawn_local;
use wgpu::util::DeviceExt;

use crate::{geo, mesh::Vertex, terrain::TerrainLayer};

#[derive(Clone, Copy, Debug)]
struct TileSource {
    name: &'static str,
    label: &'static str,
    url: &'static str,
    max_level: u8,
    attribution: &'static str,
}

const TILE_SOURCES: [TileSource; 2] = [
    TileSource {
        name: "agri",
        label: "Cangling imagery",
        url: "https://agri.cangling.cn:22002/api/v1/map3/ce0a07f5ef1062b8c90047d2051efb0c742bb8795bc9be5e24b1bbf7016f781a",
        max_level: 18,
        attribution: "Imagery: Cangling",
    },
    TileSource {
        name: "osm",
        label: "OpenStreetMap",
        url: "https://tile.openstreetmap.org",
        max_level: 19,
        attribution: "© OpenStreetMap contributors",
    },
];
const BOOTSTRAP_LEVEL: u8 = 2;
#[cfg(not(target_arch = "wasm32"))]
const WORKER_COUNT: usize = 4;
#[cfg(target_arch = "wasm32")]
const WEB_MAX_IN_FLIGHT: usize = 8;
const MAX_UPLOADS_PER_FRAME: usize = 2;
const MAX_RESULTS_PER_FRAME: usize = 512;
const ACTIVE_TILE_LIMIT: usize = 320;
const GPU_TILE_LIMIT: usize = 384;
const RETRY_DELAY_FRAMES: u64 = 600;

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(crate) struct TileKey {
    pub z: u8,
    pub x: u32,
    pub y: u32,
}

#[derive(Clone, Copy, Debug)]
struct TileRequest {
    source: usize,
    key: TileKey,
}

#[derive(Debug)]
struct ActiveRequests {
    source: usize,
    keys: HashSet<TileKey>,
}

impl TileKey {
    pub(crate) fn parent(self) -> Option<Self> {
        (self.z > 0).then_some(Self {
            z: self.z.saturating_sub(1),
            x: self.x / 2,
            y: self.y / 2,
        })
    }

    fn children(self) -> [Self; 4] {
        let z = self.z + 1;
        let x = self.x * 2;
        let y = self.y * 2;
        [
            Self { z, x, y },
            Self { z, x: x + 1, y },
            Self { z, x, y: y + 1 },
            Self {
                z,
                x: x + 1,
                y: y + 1,
            },
        ]
    }

    fn is_descendant_of(self, ancestor: Self) -> bool {
        if self.z < ancestor.z {
            return false;
        }
        let shift = self.z - ancestor.z;
        self.x >> shift == ancestor.x && self.y >> shift == ancestor.y
    }
}

struct DecodedTile {
    key: TileKey,
    width: u32,
    height: u32,
    rgba: Vec<u8>,
    cache_hit: bool,
}

struct TileResult {
    source: usize,
    key: TileKey,
    outcome: TileOutcome,
}

enum TileOutcome {
    Ready(DecodedTile),
    Failed(anyhow::Error),
    NoData,
    Cancelled,
}

struct GpuTile {
    bind_group: wgpu::BindGroup,
    origin_m: glam::DVec3,
    origin_offset: wgpu::Buffer,
    vertex_buffer: wgpu::Buffer,
    index_buffer: wgpu::Buffer,
    index_count: u32,
    quadrant_ranges: [(u32, u32); 4],
}

struct RenderTile<'a> {
    key: TileKey,
    gpu: &'a GpuTile,
    index_start: u32,
    index_end: u32,
}

/// Background XYZ loader plus the GPU resources for ready tiles.
pub struct TileLayer {
    sender: Sender<TileRequest>,
    receiver: Receiver<TileResult>,
    active_requests: Arc<RwLock<ActiveRequests>>,
    #[cfg(target_arch = "wasm32")]
    web_loader: WebTileLoader,
    source: usize,
    texture_layout: wgpu::BindGroupLayout,
    pipeline: wgpu::RenderPipeline,
    tiles: HashMap<TileKey, GpuTile>,
    in_flight: HashSet<TileKey>,
    desired: HashSet<TileKey>,
    needed: HashSet<TileKey>,
    last_used: HashMap<TileKey, u64>,
    retry_after: HashMap<TileKey, u64>,
    failure_attempts: HashMap<TileKey, u8>,
    no_data: HashSet<TileKey>,
    last_eye_m: Option<glam::DVec3>,
    dirty_meshes: Vec<TileKey>,
    dirty_set: HashSet<TileKey>,
    frame: u64,
    failed: usize,
    cache_hits: usize,
    downloaded: usize,
    cancelled: usize,
    evicted: usize,
}

#[derive(Clone, Copy, Debug)]
#[allow(dead_code)] // Retained for optional telemetry; the HUD only uses attribution.
pub struct TileStats {
    pub source_label: &'static str,
    pub attribution: &'static str,
    pub source_max_level: u8,
    pub gpu_tiles: usize,
    pub active_requests: usize,
    pub needed_tiles: usize,
    pub cache_hits: usize,
    pub downloaded: usize,
    pub failed: usize,
    pub no_data: usize,
    pub cancelled: usize,
    pub evicted: usize,
    pub rendered_min_level: Option<u8>,
    pub rendered_max_level: Option<u8>,
    pub target_coverage: usize,
    pub desired_samples: usize,
}

impl TileLayer {
    pub fn new(
        device: &wgpu::Device,
        surface_format: wgpu::TextureFormat,
        camera_layout: &wgpu::BindGroupLayout,
    ) -> Self {
        let texture_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("XYZ tile texture layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
            ],
        });
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("XYZ tile shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("tile.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("XYZ tile pipeline layout"),
            bind_group_layouts: &[Some(camera_layout), Some(&texture_layout)],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("XYZ tile pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[Some(Vertex::layout())],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: surface_format,
                    blend: Some(wgpu::BlendState::REPLACE),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                cull_mode: Some(wgpu::Face::Back),
                front_face: wgpu::FrontFace::Ccw,
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: Some(true),
                depth_compare: Some(wgpu::CompareFunction::LessEqual),
                stencil: Default::default(),
                bias: Default::default(),
            }),
            multisample: Default::default(),
            multiview_mask: None,
            cache: None,
        });

        let keys = level_keys(BOOTSTRAP_LEVEL);
        let needed = keys.iter().copied().collect::<HashSet<_>>();
        let source = 0;
        #[cfg(not(target_arch = "wasm32"))]
        let (sender, receiver, active_requests) = spawn_workers(source, needed.clone());
        #[cfg(target_arch = "wasm32")]
        let (sender, receiver, active_requests, web_loader) =
            spawn_web_loader(source, needed.clone());
        let mut in_flight = HashSet::new();
        for key in keys {
            sender
                .send(TileRequest { source, key })
                .expect("queue bootstrap XYZ tile");
            in_flight.insert(key);
        }
        Self {
            sender,
            receiver,
            active_requests,
            #[cfg(target_arch = "wasm32")]
            web_loader,
            source,
            texture_layout,
            pipeline,
            tiles: HashMap::new(),
            in_flight,
            desired: HashSet::new(),
            needed,
            last_used: HashMap::new(),
            retry_after: HashMap::new(),
            failure_attempts: HashMap::new(),
            no_data: HashSet::new(),
            last_eye_m: None,
            dirty_meshes: Vec::new(),
            dirty_set: HashSet::new(),
            frame: 0,
            failed: 0,
            cache_hits: 0,
            downloaded: 0,
            cancelled: 0,
            evicted: 0,
        }
    }

    pub fn update(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        target_level: u8,
        visible_samples: &[glam::Vec3],
        eye_m: glam::DVec3,
        near_visible_distance_m: f64,
        terrain: &TerrainLayer,
        terrain_changed: &[TileKey],
        refine_terrain: bool,
    ) {
        self.frame = self.frame.wrapping_add(1);
        let target_level = target_level.min(TILE_SOURCES[self.source].max_level);
        let mut desired_order = Vec::new();
        self.desired.clear();
        for point in visible_samples {
            let point_m = glam::DVec3::new(point.x as f64, point.y as f64, point.z as f64)
                * geo::SEMI_MAJOR_M;
            let distance_m = (point_m - eye_m).length();
            let level = target_level
                .saturating_sub(distance_lod_drop(distance_m, near_visible_distance_m))
                .max(BOOTSTRAP_LEVEL);
            let key = surface_to_tile(*point, level);
            if self.desired.insert(key) {
                desired_order.push(key);
            }
        }
        self.request_visible_branches(&desired_order);
        #[cfg(target_arch = "wasm32")]
        self.web_loader.pump();

        let mut uploads = 0;
        for _ in 0..MAX_RESULTS_PER_FRAME {
            if uploads >= MAX_UPLOADS_PER_FRAME {
                break;
            }
            let Ok(message) = self.receiver.try_recv() else {
                break;
            };
            if message.source != self.source {
                continue;
            }
            self.in_flight.remove(&message.key);
            match message.outcome {
                TileOutcome::Ready(decoded) => {
                    if !self.needed.contains(&decoded.key) {
                        self.cancelled += 1;
                        continue;
                    }
                    if decoded.cache_hit {
                        self.cache_hits += 1;
                    } else {
                        self.downloaded += 1;
                    }
                    let key = decoded.key;
                    let gpu_tile =
                        upload_tile(device, queue, &self.texture_layout, decoded, eye_m, terrain);
                    self.tiles.insert(key, gpu_tile);
                    self.last_used.insert(key, self.frame);
                    self.retry_after.remove(&key);
                    self.failure_attempts.remove(&key);
                    uploads += 1;
                }
                TileOutcome::Failed(error) => {
                    self.failed += 1;
                    let attempt = self.failure_attempts.entry(message.key).or_default();
                    *attempt = attempt.saturating_add(1);
                    let multiplier = 1_u64 << (*attempt - 1).min(5);
                    self.retry_after
                        .insert(message.key, self.frame + RETRY_DELAY_FRAMES * multiplier);
                    log::warn!("XYZ tile {:?} failed: {error:#}", message.key);
                }
                TileOutcome::NoData => {
                    self.no_data.insert(message.key);
                    log::debug!("XYZ tile {:?} contains no imagery", message.key);
                }
                TileOutcome::Cancelled => self.cancelled += 1,
            }
        }
        for dem_key in terrain_changed {
            for key in self.tiles.keys().copied() {
                if (key.is_descendant_of(*dem_key) || dem_key.is_descendant_of(key))
                    && self.dirty_set.insert(key)
                {
                    self.dirty_meshes.push(key);
                }
            }
        }
        for _ in 0..if refine_terrain { 2 } else { 0 } {
            let Some(key) = self.dirty_meshes.pop() else {
                break;
            };
            self.dirty_set.remove(&key);
            if let Some(tile) = self.tiles.get_mut(&key) {
                let (_, vertices, indices, ranges) = tile_mesh(key, 32, Some(terrain));
                tile.vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                    label: Some("terrain tile vertices"),
                    contents: bytemuck::cast_slice(&vertices),
                    usage: wgpu::BufferUsages::VERTEX,
                });
                tile.index_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                    label: Some("terrain tile indices"),
                    contents: bytemuck::cast_slice(&indices),
                    usage: wgpu::BufferUsages::INDEX,
                });
                tile.index_count = indices.len() as u32;
                tile.quadrant_ranges = ranges;
            }
        }
        if self.last_eye_m != Some(eye_m) {
            for tile in self.tiles.values() {
                write_tile_offset(queue, tile, eye_m);
            }
            self.last_eye_m = Some(eye_m);
        }
        self.evict_gpu_tiles();
    }

    pub fn draw<'a>(&'a self, pass: &mut wgpu::RenderPass<'a>) {
        pass.set_pipeline(&self.pipeline);
        let mut selected = Vec::new();
        for root in level_keys(BOOTSTRAP_LEVEL) {
            self.select_render_tiles(root, &mut selected);
        }
        for tile in selected {
            pass.set_bind_group(1, &tile.gpu.bind_group, &[]);
            pass.set_vertex_buffer(0, tile.gpu.vertex_buffer.slice(..));
            pass.set_index_buffer(tile.gpu.index_buffer.slice(..), wgpu::IndexFormat::Uint32);
            pass.draw_indexed(tile.index_start..tile.index_end, 0, 0..1);
        }
    }

    pub fn stats(&self) -> TileStats {
        let source = TILE_SOURCES[self.source];
        let mut selected = Vec::new();
        for root in level_keys(BOOTSTRAP_LEVEL) {
            self.select_render_tiles(root, &mut selected);
        }
        let selected: HashSet<_> = selected.iter().map(|tile| tile.key).collect();
        let levels: Vec<_> = self
            .desired
            .iter()
            .filter_map(|leaf| rendered_ancestor_level(*leaf, &selected))
            .collect();
        TileStats {
            source_label: source.label,
            attribution: source.attribution,
            source_max_level: source.max_level,
            gpu_tiles: self.tiles.len(),
            active_requests: self.in_flight.len(),
            needed_tiles: self.needed.len(),
            cache_hits: self.cache_hits,
            downloaded: self.downloaded,
            failed: self.failed,
            no_data: self.no_data.len(),
            cancelled: self.cancelled,
            evicted: self.evicted,
            rendered_min_level: levels.iter().copied().min(),
            rendered_max_level: levels.iter().copied().max(),
            target_coverage: self
                .desired
                .iter()
                .filter(|leaf| selected.contains(leaf))
                .count(),
            desired_samples: self.desired.len(),
        }
    }

    pub fn cycle_source(&mut self) {
        self.source = (self.source + 1) % TILE_SOURCES.len();
        self.tiles.clear();
        self.in_flight.clear();
        self.desired.clear();
        self.last_used.clear();
        self.retry_after.clear();
        self.failure_attempts.clear();
        self.no_data.clear();
        self.dirty_meshes.clear();
        self.dirty_set.clear();
        self.failed = 0;
        self.cache_hits = 0;
        self.downloaded = 0;
        self.cancelled = 0;
        self.evicted = 0;

        let keys = level_keys(BOOTSTRAP_LEVEL);
        self.needed = keys.iter().copied().collect();
        *self
            .active_requests
            .write()
            .expect("active tile lock poisoned") = ActiveRequests {
            source: self.source,
            keys: self.needed.clone(),
        };
        for key in keys {
            if self
                .sender
                .send(TileRequest {
                    source: self.source,
                    key,
                })
                .is_ok()
            {
                self.in_flight.insert(key);
            }
        }
        log::info!("switched XYZ source to {}", TILE_SOURCES[self.source].label);
    }

    fn request_visible_branches(&mut self, desired_order: &[TileKey]) {
        let (needed, priority_order) = plan_visible_branches(desired_order);
        self.needed = needed;
        *self
            .active_requests
            .write()
            .expect("active tile lock poisoned") = ActiveRequests {
            source: self.source,
            keys: self.needed.clone(),
        };

        for key in priority_order {
            let retry_ready = self
                .retry_after
                .get(&key)
                .is_none_or(|retry_frame| self.frame >= *retry_frame);
            if retry_ready
                && !self.tiles.contains_key(&key)
                && !self.no_data.contains(&key)
                && self.in_flight.insert(key)
                && self
                    .sender
                    .send(TileRequest {
                        source: self.source,
                        key,
                    })
                    .is_err()
            {
                self.in_flight.remove(&key);
                return;
            }
        }
        for key in &self.needed {
            self.last_used.insert(*key, self.frame);
        }
    }

    fn evict_gpu_tiles(&mut self) {
        if self.tiles.len() <= GPU_TILE_LIMIT {
            return;
        }
        let mut candidates: Vec<_> = self
            .tiles
            .keys()
            .filter(|key| key.z > BOOTSTRAP_LEVEL && !self.needed.contains(key))
            .map(|key| (*key, self.last_used.get(key).copied().unwrap_or(0)))
            .collect();
        candidates.sort_by_key(|(_, last_used)| *last_used);
        let remove_count = self.tiles.len().saturating_sub(GPU_TILE_LIMIT);
        for (key, _) in candidates.into_iter().take(remove_count) {
            self.tiles.remove(&key);
            self.last_used.remove(&key);
            self.evicted += 1;
        }
    }

    fn select_render_tiles<'a>(&'a self, node: TileKey, output: &mut Vec<RenderTile<'a>>) {
        let branch_needed = self
            .desired
            .iter()
            .any(|leaf| leaf.z > node.z && leaf.is_descendant_of(node));
        let children = node.children();
        if branch_needed {
            for (quadrant, child) in children.into_iter().enumerate() {
                if self.tiles.contains_key(&child) {
                    self.select_render_tiles(child, output);
                } else if let Some(gpu) = self.tiles.get(&node) {
                    let (index_start, index_end) = gpu.quadrant_ranges[quadrant];
                    output.push(RenderTile {
                        key: node,
                        gpu,
                        index_start,
                        index_end,
                    });
                }
            }
        } else if let Some(gpu) = self.tiles.get(&node) {
            output.push(RenderTile {
                key: node,
                gpu,
                index_start: 0,
                index_end: gpu.index_count,
            });
        }
    }
}

/// Request the paths actually seen on screen. Work from coarse to fine so a
/// limited queue covers the whole view before refining its centre. Requesting
/// every sibling along each path exhausted the queue after just a few samples
/// and left broad areas showing a blurry ancestor after a small camera move.
fn distance_lod_drop(distance_m: f64, near_distance_m: f64) -> u8 {
    if !distance_m.is_finite() || !near_distance_m.is_finite() || near_distance_m <= 0.0 {
        return 0;
    }
    ((distance_m / near_distance_m).max(1.0).log2() - 0.25)
        .floor()
        .clamp(0.0, 5.0) as u8
}

fn plan_visible_branches(desired_order: &[TileKey]) -> (HashSet<TileKey>, Vec<TileKey>) {
    let mut needed = level_keys(BOOTSTRAP_LEVEL)
        .into_iter()
        .collect::<HashSet<_>>();
    let mut priority_order = Vec::new();
    let max_level = desired_order
        .iter()
        .map(|key| key.z)
        .max()
        .unwrap_or(BOOTSTRAP_LEVEL);
    for level in BOOTSTRAP_LEVEL + 1..=max_level {
        for &leaf in desired_order {
            if leaf.z < level {
                continue;
            }
            let shift = leaf.z - level;
            let ancestor = TileKey {
                z: level,
                x: leaf.x >> shift,
                y: leaf.y >> shift,
            };
            if needed.contains(&ancestor) {
                continue;
            }
            if needed.len() >= ACTIVE_TILE_LIMIT {
                return (needed, priority_order);
            }
            needed.insert(ancestor);
            priority_order.push(ancestor);
        }
    }
    (needed, priority_order)
}

fn rendered_ancestor_level(leaf: TileKey, selected: &HashSet<TileKey>) -> Option<u8> {
    let mut current = Some(leaf);
    while let Some(key) = current {
        if selected.contains(&key) {
            return Some(key.z);
        }
        current = key.parent();
    }
    None
}

fn level_keys(z: u8) -> Vec<TileKey> {
    let width = 1_u32 << z;
    (0..width)
        .flat_map(|y| (0..width).map(move |x| TileKey { z, x, y }))
        .collect()
}

pub(crate) fn surface_to_tile(point: glam::Vec3, z: u8) -> TileKey {
    let position =
        glam::DVec3::new(point.x as f64, point.y as f64, point.z as f64) * geo::SEMI_MAJOR_M;
    let (latitude, longitude) = geo::geodetic_lat_lon(position);
    let latitude = latitude.clamp(
        -85.051_128_78_f64.to_radians(),
        85.051_128_78_f64.to_radians(),
    );
    let count = 1_u32 << z;
    let x = ((longitude / std::f64::consts::TAU + 0.5) * count as f64)
        .floor()
        .clamp(0.0, (count - 1) as f64) as u32;
    let mercator = (latitude.tan() + 1.0 / latitude.cos()).ln();
    let y = ((1.0 - mercator / std::f64::consts::PI) * 0.5 * count as f64)
        .floor()
        .clamp(0.0, (count - 1) as f64) as u32;
    TileKey { z, x, y }
}

#[cfg(target_arch = "wasm32")]
struct WebTileLoader {
    requests: Receiver<TileRequest>,
    results: Sender<TileResult>,
    active_requests: Arc<RwLock<ActiveRequests>>,
    active_fetches: Rc<Cell<usize>>,
}

#[cfg(target_arch = "wasm32")]
fn spawn_web_loader(
    source: usize,
    initial_active: HashSet<TileKey>,
) -> (
    Sender<TileRequest>,
    Receiver<TileResult>,
    Arc<RwLock<ActiveRequests>>,
    WebTileLoader,
) {
    let (sender, requests) = unbounded();
    let (results, receiver) = unbounded();
    let active_requests = Arc::new(RwLock::new(ActiveRequests {
        source,
        keys: initial_active,
    }));
    let loader = WebTileLoader {
        requests,
        results,
        active_requests: active_requests.clone(),
        active_fetches: Rc::new(Cell::new(0)),
    };
    (sender, receiver, active_requests, loader)
}

#[cfg(target_arch = "wasm32")]
impl WebTileLoader {
    fn pump(&self) {
        while self.active_fetches.get() < WEB_MAX_IN_FLIGHT {
            let Ok(request) = self.requests.try_recv() else {
                break;
            };
            let TileRequest { source, key } = request;
            let active = self
                .active_requests
                .read()
                .expect("active tile lock poisoned");
            if active.source != source || !active.keys.contains(&key) {
                let _ = self.results.send(TileResult {
                    source,
                    key,
                    outcome: TileOutcome::Cancelled,
                });
                continue;
            }
            drop(active);
            self.active_fetches.set(self.active_fetches.get() + 1);
            let active_requests = self.active_requests.clone();
            let active_fetches = self.active_fetches.clone();
            let results = self.results.clone();
            spawn_local(async move {
                let tile_source = TILE_SOURCES[source];
                let url = tile_url(tile_source, key);
                let cache_name = format!("cangling-imagery-{}-v1", tile_source.name);
                let loaded = crate::web_cache::fetch_bytes(&url, &cache_name)
                    .await
                    .and_then(|(bytes, hit)| decode_tile_bytes(key, bytes, hit));
                let current = active_requests.read().expect("active tile lock poisoned");
                let still_needed = current.source == source && current.keys.contains(&key);
                drop(current);
                let outcome = if !still_needed {
                    TileOutcome::Cancelled
                } else {
                    match loaded {
                        Ok(Some(tile)) => TileOutcome::Ready(tile),
                        Ok(None) => TileOutcome::NoData,
                        Err(error) => TileOutcome::Failed(error),
                    }
                };
                let _ = results.send(TileResult {
                    source,
                    key,
                    outcome,
                });
                active_fetches.set(active_fetches.get().saturating_sub(1));
            });
        }
    }
}

#[cfg(not(target_arch = "wasm32"))]
fn spawn_workers(
    source: usize,
    initial_active: HashSet<TileKey>,
) -> (
    Sender<TileRequest>,
    Receiver<TileResult>,
    Arc<RwLock<ActiveRequests>>,
) {
    let (request_tx, request_rx) = unbounded();
    let (result_tx, result_rx) = unbounded();
    let active_requests = Arc::new(RwLock::new(ActiveRequests {
        source,
        keys: initial_active,
    }));
    for worker in 0..WORKER_COUNT {
        let requests = request_rx.clone();
        let results = result_tx.clone();
        let active = active_requests.clone();
        thread::Builder::new()
            .name(format!("xyz-loader-{worker}"))
            .spawn(move || worker_loop(requests, results, active))
            .expect("spawn XYZ worker");
    }
    drop(result_tx);
    (request_tx, result_rx, active_requests)
}

#[cfg(not(target_arch = "wasm32"))]
fn worker_loop(
    requests: Receiver<TileRequest>,
    results: Sender<TileResult>,
    active_requests: Arc<RwLock<ActiveRequests>>,
) {
    let client = reqwest::blocking::Client::builder()
        .connect_timeout(Duration::from_secs(3))
        .timeout(Duration::from_secs(10))
        .user_agent("cangling-desktop/0.1 (desktop GIS; https://agri.cangling.cn)")
        .build()
        .expect("build XYZ HTTP client");
    for request in requests {
        let TileRequest { source, key } = request;
        let is_active =
            |active: &ActiveRequests| active.source == source && active.keys.contains(&key);
        let active = is_active(&active_requests.read().expect("active tile lock poisoned"));
        let outcome = if active {
            match load_tile(&client, key, TILE_SOURCES[source]) {
                Ok(Some(tile))
                    if is_active(&active_requests.read().expect("active tile lock poisoned")) =>
                {
                    TileOutcome::Ready(tile)
                }
                Ok(Some(_)) => TileOutcome::Cancelled,
                Ok(None) => TileOutcome::NoData,
                Err(error) => TileOutcome::Failed(error),
            }
        } else {
            TileOutcome::Cancelled
        };
        if results
            .send(TileResult {
                source,
                key,
                outcome,
            })
            .is_err()
        {
            break;
        }
    }
}

#[cfg(not(target_arch = "wasm32"))]
fn load_tile(
    client: &reqwest::blocking::Client,
    key: TileKey,
    source: TileSource,
) -> Result<Option<DecodedTile>> {
    let cache_path = cache_path(source.name, key)?;
    let (bytes, cache_hit) = match fs::read(&cache_path) {
        Ok(bytes) => (bytes, true),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
            let url = tile_url(source, key);
            let response = client.get(url).send()?.error_for_status()?;
            let bytes = response.bytes()?.to_vec();
            persist_atomically(&cache_path, &bytes)?;
            (bytes, false)
        }
        Err(error) => return Err(error.into()),
    };
    decode_tile_bytes(key, bytes, cache_hit)
}

fn decode_tile_bytes(key: TileKey, bytes: Vec<u8>, cache_hit: bool) -> Result<Option<DecodedTile>> {
    let image = ImageReader::new(std::io::Cursor::new(bytes))
        .with_guessed_format()?
        .decode()
        .context("decode XYZ JPEG/PNG")?
        .to_rgba8();
    let (width, height) = image.dimensions();
    let rgba = image.into_raw();
    if blank_rgba_tile(&rgba) {
        return Ok(None);
    }
    Ok(Some(DecodedTile {
        key,
        width,
        height,
        rgba,
        cache_hit,
    }))
}

fn blank_rgba_tile(rgba: &[u8]) -> bool {
    !rgba.is_empty()
        && rgba
            .chunks_exact(4)
            .all(|pixel| pixel[0] == 0 && pixel[1] == 0 && pixel[2] == 0)
}

fn tile_url(source: TileSource, key: TileKey) -> String {
    format!("{}/{}/{}/{}.png", source.url, key.z, key.x, key.y)
}

#[cfg(not(target_arch = "wasm32"))]
fn cache_path(source_name: &str, key: TileKey) -> Result<PathBuf> {
    let root = dirs::cache_dir().ok_or_else(|| anyhow!("no platform cache directory"))?;
    Ok(root
        .join("cangling-desktop")
        .join("tiles")
        .join(source_name)
        .join(key.z.to_string())
        .join(key.x.to_string())
        .join(format!("{}.tile", key.y)))
}

#[cfg(not(target_arch = "wasm32"))]
fn persist_atomically(path: &Path, bytes: &[u8]) -> Result<()> {
    let parent = path.parent().context("tile cache path has no parent")?;
    fs::create_dir_all(parent)?;
    let temporary = path.with_extension("part");
    fs::write(&temporary, bytes)?;
    fs::rename(temporary, path)?;
    Ok(())
}

fn upload_tile(
    device: &wgpu::Device,
    queue: &wgpu::Queue,
    texture_layout: &wgpu::BindGroupLayout,
    decoded: DecodedTile,
    eye_m: glam::DVec3,
    terrain: &TerrainLayer,
) -> GpuTile {
    let label = format!("XYZ z{}/{}/{}", decoded.key.z, decoded.key.x, decoded.key.y);
    let texture = device.create_texture_with_data(
        queue,
        &wgpu::TextureDescriptor {
            label: Some(&label),
            size: wgpu::Extent3d {
                width: decoded.width,
                height: decoded.height,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8UnormSrgb,
            usage: wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        },
        wgpu::util::TextureDataOrder::LayerMajor,
        &decoded.rgba,
    );
    let view = texture.create_view(&Default::default());
    let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
        label: Some("XYZ linear sampler"),
        mag_filter: wgpu::FilterMode::Linear,
        min_filter: wgpu::FilterMode::Linear,
        mipmap_filter: wgpu::MipmapFilterMode::Linear,
        address_mode_u: wgpu::AddressMode::ClampToEdge,
        address_mode_v: wgpu::AddressMode::ClampToEdge,
        ..Default::default()
    });
    let (origin_m, vertices, indices, quadrant_ranges) = tile_mesh(decoded.key, 32, Some(terrain));
    let offset = tile_offset(origin_m, eye_m);
    let origin_offset = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label: Some("tile origin relative to eye"),
        contents: bytemuck::cast_slice(&offset),
        usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
    });
    let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some(&label),
        layout: texture_layout,
        entries: &[
            wgpu::BindGroupEntry {
                binding: 0,
                resource: wgpu::BindingResource::TextureView(&view),
            },
            wgpu::BindGroupEntry {
                binding: 1,
                resource: wgpu::BindingResource::Sampler(&sampler),
            },
            wgpu::BindGroupEntry {
                binding: 2,
                resource: origin_offset.as_entire_binding(),
            },
        ],
    });
    let vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label: Some(&label),
        contents: bytemuck::cast_slice(&vertices),
        usage: wgpu::BufferUsages::VERTEX,
    });
    let index_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label: Some(&label),
        contents: bytemuck::cast_slice(&indices),
        usage: wgpu::BufferUsages::INDEX,
    });
    GpuTile {
        bind_group,
        origin_m,
        origin_offset,
        vertex_buffer,
        index_buffer,
        index_count: indices.len() as u32,
        quadrant_ranges,
    }
}

fn tile_offset(origin_m: glam::DVec3, eye_m: glam::DVec3) -> [f32; 4] {
    let relative = (origin_m - eye_m) / geo::SEMI_MAJOR_M;
    [relative.x as f32, relative.y as f32, relative.z as f32, 0.0]
}

fn write_tile_offset(queue: &wgpu::Queue, tile: &GpuTile, eye_m: glam::DVec3) {
    let offset = tile_offset(tile.origin_m, eye_m);
    queue.write_buffer(&tile.origin_offset, 0, bytemuck::cast_slice(&offset));
}

fn tile_mesh(
    key: TileKey,
    subdivisions: u32,
    terrain: Option<&TerrainLayer>,
) -> (glam::DVec3, Vec<Vertex>, Vec<u32>, [(u32, u32); 4]) {
    assert!(subdivisions > 0 && subdivisions.is_multiple_of(2));
    let count = 1_u32 << key.z;
    let center_lat =
        ((std::f64::consts::PI * (1.0 - 2.0 * (key.y as f64 + 0.5) / count as f64)).sinh()).atan();
    let center_lon =
        (key.x as f64 + 0.5) / count as f64 * std::f64::consts::TAU - std::f64::consts::PI;
    // Keep the origin fixed on the ellipsoid while DEM tiles arrive. Only
    // vertex positions change, so existing per-tile camera offsets stay valid.
    let origin_m = geo::geodetic_position(center_lat, center_lon, 0.0);
    let mut vertices = Vec::with_capacity(((subdivisions + 1) * (subdivisions + 1)) as usize);
    for row in 0..=subdivisions {
        let v = row as f64 / subdivisions as f64;
        let global_y = (key.y as f64 + v) / count as f64;
        let latitude = ((std::f64::consts::PI * (1.0 - 2.0 * global_y)).sinh()).atan();
        for column in 0..=subdivisions {
            let u = column as f64 / subdivisions as f64;
            let global_x = (key.x as f64 + u) / count as f64;
            let longitude = global_x * std::f64::consts::TAU - std::f64::consts::PI;
            let normal = [
                (latitude.cos() * longitude.sin()) as f32,
                latitude.sin() as f32,
                (latitude.cos() * longitude.cos()) as f32,
            ];
            let height = terrain.map_or(0.0, |dem| dem.sample(latitude, longitude));
            let ecef = geo::geodetic_position(latitude, longitude, height);
            let local = (ecef - origin_m) / geo::SEMI_MAJOR_M;
            let position = [local.x as f32, local.y as f32, local.z as f32];
            vertices.push(Vertex {
                position,
                normal,
                uv: [u as f32, v as f32],
            });
        }
    }
    let stride = subdivisions + 1;
    let pole_vertex = |north: bool, u: f32| {
        let latitude = if north {
            std::f64::consts::FRAC_PI_2
        } else {
            -std::f64::consts::FRAC_PI_2
        };
        let ecef = geo::geodetic_position(latitude, 0.0, 0.0);
        let local = (ecef - origin_m) / geo::SEMI_MAJOR_M;
        Vertex {
            position: [local.x as f32, local.y as f32, local.z as f32],
            normal: [0.0, if north { 1.0 } else { -1.0 }, 0.0],
            uv: [u, if north { 0.0 } else { 1.0 }],
        }
    };
    let north_base = (key.y == 0).then(|| {
        let base = vertices.len() as u32;
        for column in 0..=subdivisions {
            vertices.push(pole_vertex(true, column as f32 / subdivisions as f32));
        }
        base
    });
    let south_base = (key.y == count - 1).then(|| {
        let base = vertices.len() as u32;
        for column in 0..=subdivisions {
            vertices.push(pole_vertex(false, column as f32 / subdivisions as f32));
        }
        base
    });
    let mut indices =
        Vec::with_capacity((subdivisions * subdivisions * 6 + subdivisions * 3) as usize);
    let mut quadrant_ranges = [(0, 0); 4];
    let half = subdivisions / 2;
    let skirt_depth_m = terrain.filter(|dem| dem.needs_skirt(key)).map(|_| {
        let tile_width_m =
            std::f64::consts::TAU * geo::SEMI_MAJOR_M * center_lat.cos().max(0.1) / count as f64;
        // A shallow skirt hides the chord mismatch at a coarser neighbour.
        // Deep skirts become visible as stretched image wedges in oblique
        // views, especially when a parent tile remains at the viewport edge.
        (tile_width_m / subdivisions as f64 * 0.15).clamp(3.0, 400.0)
    });
    for quadrant_y in 0..2 {
        for quadrant_x in 0..2 {
            let quadrant = (quadrant_y * 2 + quadrant_x) as usize;
            let start = indices.len() as u32;
            for row in quadrant_y * half..(quadrant_y + 1) * half {
                for column in quadrant_x * half..(quadrant_x + 1) * half {
                    let a = row * stride + column;
                    let b = a + stride;
                    indices.extend_from_slice(&[a, b, a + 1, a + 1, b, b + 1]);
                }
            }
            if quadrant_y == 0
                && let Some(base) = north_base
            {
                for column in quadrant_x * half..(quadrant_x + 1) * half {
                    indices.extend_from_slice(&[base + column + 1, column, column + 1]);
                }
            }
            if quadrant_y == 1
                && let Some(base) = south_base
            {
                let edge_row = subdivisions * stride;
                for column in quadrant_x * half..(quadrant_x + 1) * half {
                    indices.extend_from_slice(&[
                        edge_row + column,
                        base + column,
                        edge_row + column + 1,
                    ]);
                }
            }
            if let Some(depth_m) = skirt_depth_m {
                let row0 = quadrant_y * half;
                let row1 = (quadrant_y + 1) * half;
                let col0 = quadrant_x * half;
                let col1 = (quadrant_x + 1) * half;
                // Each quadrant may be drawn while a finer neighbour is
                // already ready. Its lowered rim hides those temporary gaps.
                for column in col0..col1 {
                    append_skirt_segment(
                        &mut vertices,
                        &mut indices,
                        row0 * stride + column,
                        row0 * stride + column + 1,
                        depth_m,
                    );
                    append_skirt_segment(
                        &mut vertices,
                        &mut indices,
                        row1 * stride + column + 1,
                        row1 * stride + column,
                        depth_m,
                    );
                }
                for row in row0..row1 {
                    append_skirt_segment(
                        &mut vertices,
                        &mut indices,
                        row * stride + col1,
                        (row + 1) * stride + col1,
                        depth_m,
                    );
                    append_skirt_segment(
                        &mut vertices,
                        &mut indices,
                        (row + 1) * stride + col0,
                        row * stride + col0,
                        depth_m,
                    );
                }
            }
            quadrant_ranges[quadrant] = (start, indices.len() as u32);
        }
    }
    (origin_m, vertices, indices, quadrant_ranges)
}

fn append_skirt_segment(
    vertices: &mut Vec<Vertex>,
    indices: &mut Vec<u32>,
    a: u32,
    b: u32,
    depth_m: f64,
) {
    let base = vertices.len() as u32;
    for top in [a, b] {
        let mut vertex = vertices[top as usize];
        let down = depth_m as f32 / geo::SEMI_MAJOR_M as f32;
        for axis in 0..3 {
            vertex.position[axis] -= vertex.normal[axis] * down;
        }
        vertices.push(vertex);
    }
    // Both windings preserve visibility from either side of a steep LOD
    // transition while the globe's back-face culling remains enabled.
    let front = [a, base, b, b, base, base + 1];
    indices.extend_from_slice(&front);
    indices.extend_from_slice(&[front[2], front[1], front[0], front[5], front[4], front[3]]);
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn distant_surface_samples_request_coarser_imagery() {
        assert_eq!(distance_lod_drop(1_000.0, 1_000.0), 0);
        assert_eq!(distance_lod_drop(2_000.0, 1_000.0), 0);
        assert_eq!(distance_lod_drop(3_000.0, 1_000.0), 1);
        assert_eq!(distance_lod_drop(8_000.0, 1_000.0), 2);
        assert_eq!(distance_lod_drop(100_000.0, 1_000.0), 5);
    }

    #[test]
    fn level_two_has_sixteen_tiles() {
        assert_eq!(level_keys(2).len(), 16);
    }

    #[test]
    fn tile_mesh_has_expected_topology() {
        let (origin_m, vertices, indices, ranges) =
            tile_mesh(TileKey { z: 2, x: 2, y: 1 }, 8, None);
        assert_eq!(vertices.len(), 81);
        assert_eq!(indices.len(), 384);
        assert!(vertices.iter().all(|vertex| {
            let p = glam::DVec3::new(
                vertex.position[0] as f64,
                vertex.position[1] as f64,
                vertex.position[2] as f64,
            ) * geo::SEMI_MAJOR_M
                + origin_m;
            p.length() <= geo::SEMI_MAJOR_M + 1.0 && p.length() >= geo::SEMI_MINOR_M - 1.0
        }));
        for quadrant in 0..4 {
            let row_start = (quadrant / 2) * 4;
            let col_start = (quadrant % 2) * 4;
            let (start, end) = ranges[quadrant];
            for index in &indices[start as usize..end as usize] {
                let row = *index as usize / 9;
                let col = *index as usize % 9;
                assert!((row_start..=row_start + 4).contains(&row));
                assert!((col_start..=col_start + 4).contains(&col));
            }
        }
    }

    #[test]
    fn polar_tiles_close_the_mercator_caps() {
        let (_, north_vertices, north_indices, north_ranges) =
            tile_mesh(TileKey { z: 2, x: 2, y: 0 }, 8, None);
        assert_eq!(north_vertices.len(), 81 + 9);
        assert_eq!(north_indices.len(), 384 + 8 * 3);
        assert_eq!(north_ranges[0].1 - north_ranges[0].0, 96 + 12);
        assert_eq!(north_ranges[2].1 - north_ranges[2].0, 96);

        let (_, south_vertices, south_indices, south_ranges) =
            tile_mesh(TileKey { z: 2, x: 2, y: 3 }, 8, None);
        assert_eq!(south_vertices.len(), 81 + 9);
        assert_eq!(south_indices.len(), 384 + 8 * 3);
        assert_eq!(south_ranges[2].1 - south_ranges[2].0, 96 + 12);
    }

    #[test]
    fn sichuan_quadrants_have_valid_skirt_geometry() {
        let terrain = TerrainLayer::new();
        let key = TileKey {
            z: 8,
            x: 201,
            y: 105,
        };
        let (_, vertices, indices, ranges) = tile_mesh(key, 8, Some(&terrain));
        assert!(vertices.len() > 81);
        assert!(indices.len() > 384);
        assert!(
            indices
                .iter()
                .all(|index| (*index as usize) < vertices.len())
        );
        assert_eq!(ranges[0].0, 0);
        assert_eq!(ranges[3].1, indices.len() as u32);
        assert!(ranges.windows(2).all(|pair| pair[0].1 == pair[1].0));
    }

    #[test]
    fn surface_point_maps_to_expected_xyz_tile() {
        assert_eq!(
            surface_to_tile(glam::Vec3::Z, 2),
            TileKey { z: 2, x: 2, y: 2 }
        );
        assert_eq!(
            surface_to_tile(glam::Vec3::X, 2),
            TileKey { z: 2, x: 3, y: 2 }
        );
    }

    #[test]
    fn tile_hierarchy_recognizes_descendants() {
        let parent = TileKey { z: 2, x: 1, y: 2 };
        let descendant = TileKey { z: 5, x: 11, y: 17 };
        assert!(descendant.is_descendant_of(parent));
        assert!(!TileKey { z: 5, x: 3, y: 17 }.is_descendant_of(parent));
    }

    #[test]
    fn visible_paths_cover_the_view_without_requesting_hidden_siblings() {
        let leaves: Vec<_> = (0..10)
            .flat_map(|y| {
                (0..16).map(move |x| TileKey {
                    z: 18,
                    x: 40_000 + x,
                    y: 30_000 + y,
                })
            })
            .collect();
        let (needed, priority) = plan_visible_branches(&leaves);
        assert!(leaves.iter().all(|key| needed.contains(key)));
        assert!(needed.len() <= ACTIVE_TILE_LIMIT);
        assert!(priority.windows(2).all(|pair| pair[0].z <= pair[1].z));
        assert!(
            priority
                .iter()
                .all(|key| { leaves.iter().any(|leaf| leaf.is_descendant_of(*key)) })
        );
    }

    #[test]
    fn openstreetmap_url_uses_standard_xyz_order() {
        assert_eq!(
            tile_url(TILE_SOURCES[1], TileKey { z: 6, x: 51, y: 26 }),
            "https://tile.openstreetmap.org/6/51/26.png"
        );
    }

    #[test]
    fn all_black_placeholder_is_not_renderable_imagery() {
        assert!(blank_rgba_tile(&[0, 0, 0, 255, 0, 0, 0, 255]));
        assert!(!blank_rgba_tile(&[0, 0, 0, 255, 1, 0, 0, 255]));
    }
}

impl TileLayer {pub fn keeper_source(&mut self,source:usize){if self.source!=source {self.cycle_source();}}}
