use std::{collections::HashSet, sync::Arc, time::Duration};

#[cfg(not(target_arch = "wasm32"))]
use std::time::Instant;
#[cfg(target_arch = "wasm32")]
use web_time::Instant;

use anyhow::{Context, Result};
use glam::Vec2;
use wgpu::util::DeviceExt;
use winit::{
    dpi::PhysicalSize,
    event::{ElementState, MouseButton, WindowEvent},
    keyboard::{KeyCode, PhysicalKey},
    window::Window,
};

const PROFILE_STAGES: [&str; 8] = [
    "frame CPU",
    "terrain",
    "imagery",
    "grid",
    "place labels",
    "admin labels",
    "boundary rebuild",
    "boundary draw encode",
];

struct FrameProfile {
    samples: [Vec<f64>; 8],
    rebuilds: u32,
    skipped_boundary_rebuilds: u32,
    patched_boundary_updates: u32,
    upload_bytes: u64,
    resampled_rings: u64,
    reused_rings: u64,
    drawn_batches: u64,
    drawn_indices: u64,
    frames: u32,
    frame_start: Instant,
}

impl FrameProfile {
    fn enabled() -> Option<Self> {
        #[cfg(target_arch = "wasm32")]
        let enabled = web_sys::window()
            .and_then(|window| window.location().search().ok())
            .is_some_and(|search| {
                search
                    .split('&')
                    .any(|part| part == "profile=1" || part == "?profile=1")
            });
        #[cfg(not(target_arch = "wasm32"))]
        let enabled = std::env::var("CANGLING_PROFILE").is_ok_and(|value| value == "1");
        enabled.then(|| Self {
            samples: std::array::from_fn(|_| Vec::with_capacity(120)),
            rebuilds: 0,
            skipped_boundary_rebuilds: 0,
            patched_boundary_updates: 0,
            upload_bytes: 0,
            resampled_rings: 0,
            reused_rings: 0,
            drawn_batches: 0,
            drawn_indices: 0,
            frames: 0,
            frame_start: Instant::now(),
        })
    }

    fn record(&mut self, stage: usize, started: Instant) {
        self.samples[stage].push(started.elapsed().as_secs_f64() * 1000.0);
    }

    fn finish(&mut self, batches: usize, indices: u64) {
        self.record(0, self.frame_start);
        self.drawn_batches += batches as u64;
        self.drawn_indices += indices;
        self.frames += 1;
        if self.frames < 120 {
            return;
        }
        let mut lines = vec![format!(
            "Cangling frame profile ({} frames): boundary updates={}, skipped={}, patched={}, rings resampled={}, reused={}, uploaded={:.1} MiB, visible batches/frame={:.1}, indices/frame={:.0}",
            self.frames,
            self.rebuilds,
            self.skipped_boundary_rebuilds,
            self.patched_boundary_updates,
            self.resampled_rings,
            self.reused_rings,
            self.upload_bytes as f64 / 1_048_576.0,
            self.drawn_batches as f64 / self.frames as f64,
            self.drawn_indices as f64 / self.frames as f64,
        )];
        for (name, samples) in PROFILE_STAGES.iter().zip(&mut self.samples) {
            if samples.is_empty() {
                continue;
            }
            samples.sort_by(f64::total_cmp);
            let average = samples.iter().sum::<f64>() / samples.len() as f64;
            let p95 = samples[((samples.len() - 1) as f64 * 0.95).ceil() as usize];
            lines.push(format!("  {name}: avg={average:.2} ms, p95={p95:.2} ms"));
            samples.clear();
        }
        let message = lines.join("\n");
        #[cfg(target_arch = "wasm32")]
        web_sys::console::log_1(&message.into());
        #[cfg(not(target_arch = "wasm32"))]
        eprintln!("{message}");
        self.rebuilds = 0;
        self.skipped_boundary_rebuilds = 0;
        self.patched_boundary_updates = 0;
        self.upload_bytes = 0;
        self.resampled_rings = 0;
        self.reused_rings = 0;
        self.drawn_batches = 0;
        self.drawn_indices = 0;
        self.frames = 0;
    }
}

use crate::{
    administration::Administration,
    boundary::BoundaryLayer,
    camera::OrbitCamera,
    graticule::Graticule,
    hud::Hud,
    marker::RotationMarker,
    navigation::{NavControl, NavLayout, NavigationHud, ScaleBar},
    placenames::PlaceNames,
    terrain::TerrainLayer,
    tile::{TileKey, TileLayer},
};

pub struct Renderer {
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    size: PhysicalSize<u32>,
    camera: OrbitCamera,
    camera_buffer: wgpu::Buffer,
    camera_bind_group: wgpu::BindGroup,
    depth: wgpu::TextureView,
    tiles: TileLayer,
    sky: crate::sky::Sky,
    graticule: Graticule,
    images: crate::image_layer::ImageLayerRenderer,
    models: crate::model_layer::ModelLayerRenderer,
    walker: crate::model_layer::ModelLayerRenderer,
    tiles3d: crate::tiles3d::Tiles3d,
    tile_models: crate::model_layer::ModelLayerRenderer,
    vectors: crate::vector_layer::VectorLayerRenderer,
    boundaries: BoundaryLayer,
    boundaries_visible: bool,
    boundaries_need_refresh: bool,
    deferred_boundary_dem: HashSet<TileKey>,
    last_navigation_motion: Option<Instant>,
    placenames: PlaceNames,
    administration: Administration,
    admin_zoom: u8,
    terrain: TerrainLayer,
    marker: RotationMarker,
    navigation: NavigationHud,
    nav_cursor: Option<Vec2>,
    nav_drag: Option<NavControl>,
    hud: Hud,
    last_camera_update: Instant,
    fps_window_start: Instant,
    fps_presented_frames: u32,
    profile: Option<FrameProfile>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RenderStatus {
    Presented,
    Skipped,
    Reconfigure,
}

impl Renderer {
    #[cfg(not(target_arch = "wasm32"))]
    pub async fn new(window: Arc<Window>) -> Result<Self> {
        Self::new_with_instance(window, wgpu::Instance::default()).await
    }

    #[cfg(target_arch = "wasm32")]
    pub async fn new_web(window: Arc<Window>, backend: wgpu::Backends) -> Result<Self> {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor {
            backends: backend,
            ..wgpu::InstanceDescriptor::new_without_display_handle()
        });
        Self::new_with_instance(window, instance).await
    }

    async fn new_with_instance(window: Arc<Window>, instance: wgpu::Instance) -> Result<Self> {
        let size = window.inner_size();
        let surface = instance
            .create_surface(window)
            .context("create GPU surface")?;
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
                apply_limit_buckets: false,
            })
            .await
            .context("no compatible graphics adapter")?;
        let limits = if adapter.get_info().backend == wgpu::Backend::Gl {
            wgpu::Limits {
                max_texture_dimension_2d: adapter.limits().max_texture_dimension_2d,
                ..wgpu::Limits::downlevel_webgl2_defaults()
            }
        } else {
            wgpu::Limits::default()
        };
        let (device, queue) = adapter
            .request_device(&wgpu::DeviceDescriptor {
                label: Some("cangling device"),
                required_features: wgpu::Features::empty(),
                required_limits: limits,
                memory_hints: wgpu::MemoryHints::Performance,
                trace: wgpu::Trace::Off,
                experimental_features: wgpu::ExperimentalFeatures::disabled(),
            })
            .await
            .context("create GPU device")?;

        #[cfg(target_arch = "wasm32")]
        device.on_uncaptured_error(Arc::new(|error| {
            crate::web::report_gpu_error(&error.to_string());
        }));

        let capabilities = surface.get_capabilities(&adapter);
        let format = capabilities
            .formats
            .iter()
            .copied()
            .find(|f| f.is_srgb())
            .unwrap_or(capabilities.formats[0]);
        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format,
            color_space: wgpu::SurfaceColorSpace::Auto,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode: wgpu::PresentMode::AutoVsync,
            desired_maximum_frame_latency: 2,
            alpha_mode: capabilities.alpha_modes[0],
            view_formats: vec![],
        };
        surface.configure(&device, &config);

        let mut camera = OrbitCamera::new(size);
        if std::env::args().any(|arg| arg == "--terrain-demo") {
            camera.focus_terrain_pilot();
        }
        let camera_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("camera uniform"),
            contents: bytemuck::bytes_of(&camera.uniform()),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let camera_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("camera layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let camera_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("camera bind group"),
            layout: &camera_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: camera_buffer.as_entire_binding(),
            }],
        });

        let depth = create_depth(&device, &config);
        let sky = crate::sky::Sky::new(&device, format);
        let tiles = TileLayer::new(&device, format, &camera_layout);
        let images = crate::image_layer::ImageLayerRenderer::new(&device, format, &camera_layout);
        let models = crate::model_layer::ModelLayerRenderer::new(&device, format, &camera_layout);
        let mut walker = crate::model_layer::ModelLayerRenderer::new(&device, format, &camera_layout);
        walker.upload(&device,&queue,"walker",include_bytes!("../assets/walker.glb"),&serde_json::json!({"visible":false})).map_err(|e|anyhow::anyhow!(e))?;
        let tile_models = crate::model_layer::ModelLayerRenderer::new(&device, format, &camera_layout).for_tiles();
        let vectors = crate::vector_layer::VectorLayerRenderer::new(&device, format);
        let graticule = Graticule::new(&device, format);
        let boundaries = BoundaryLayer::new(&device, format, &camera_layout);
        let placenames = PlaceNames::new();
        let administration = Administration::new();
        let terrain = TerrainLayer::new();
        let marker = RotationMarker::new(&device, format);
        let navigation = NavigationHud::new(&device, format);
        let mut hud = Hud::new(&device, &queue, format);
        hud.set_attribution(tiles.stats().attribution);

        Ok(Self {
            surface,
            device,
            queue,
            config,
            size,
            camera,
            camera_buffer,
            camera_bind_group,
            depth,
            tiles,
            sky,
            graticule,
            images,
            models,
            walker,
            tiles3d: Default::default(),
            tile_models,
            vectors,
            boundaries,
            boundaries_visible: true,
            boundaries_need_refresh: false,
            deferred_boundary_dem: HashSet::new(),
            last_navigation_motion: None,
            placenames,
            administration,
            admin_zoom: 3,
            terrain,
            marker,
            navigation,
            nav_cursor: None,
            nav_drag: None,
            hud,
            last_camera_update: Instant::now(),
            fps_window_start: Instant::now(),
            fps_presented_frames: 0,
            profile: FrameProfile::enabled(),
        })
    }

    pub fn input(&mut self, event: &WindowEvent) {
        if let WindowEvent::KeyboardInput { event, .. } = event {
            if event.state == ElementState::Pressed && !event.repeat
                && event.physical_key == PhysicalKey::Code(KeyCode::F1) {
                self.hud.toggle_help();
                return;
            }
        }
        if self.camera.is_walking(){self.camera.input(event,&self.terrain);return;}
        let layout = NavLayout::new(self.size.width, self.size.height);
        match event {
            WindowEvent::Focused(false) | WindowEvent::CursorLeft { .. } => {
                self.nav_drag = None;
                self.nav_cursor = None;
            }
            WindowEvent::CursorMoved { position, .. } => {
                let cursor = Vec2::new(position.x as f32, position.y as f32);
                self.nav_cursor = Some(cursor);
                if let Some(control) = self.nav_drag {
                    self.set_navigation_control(control, layout.bar_fraction(cursor));
                    return;
                }
            }
            WindowEvent::MouseInput {
                state: ElementState::Pressed,
                button: MouseButton::Left,
                ..
            } => {
                if let Some(control) = self.nav_cursor.and_then(|p| layout.hit_test(p)) {
                    self.nav_drag = Some(control);
                    if let Some(cursor) = self.nav_cursor {
                        self.set_navigation_control(control, layout.bar_fraction(cursor));
                    }
                    return;
                }
            }
            WindowEvent::MouseInput {
                state: ElementState::Released,
                button: MouseButton::Left,
                ..
            } if self.nav_drag.take().is_some() => return,
            WindowEvent::MouseWheel { .. }
                if self.nav_cursor.and_then(|p| layout.hit_test(p)).is_some() =>
            {
                return;
            }
            _ => {}
        }
        if let WindowEvent::KeyboardInput { event, .. } = event
            && event.state == ElementState::Pressed
            && !event.repeat
        {
            match event.physical_key {
                PhysicalKey::Code(KeyCode::KeyI) => {
                    self.tiles.cycle_source();
                    self.hud.set_attribution(self.tiles.stats().attribution);
                    return;
                }
                PhysicalKey::Code(KeyCode::KeyT) => {
                    self.camera.toggle_view_tilt(&self.terrain);
                    return;
                }
                PhysicalKey::Code(KeyCode::KeyR) => {
                    self.camera.toggle_patrol(&self.terrain);
                    return;
                }
                PhysicalKey::Code(KeyCode::KeyH) => {
                    self.nav_drag = None;
                    self.camera.fly_home();
                    return;
                }
                PhysicalKey::Code(KeyCode::KeyG) => {
                    self.graticule.toggle();
                    return;
                }
                PhysicalKey::Code(KeyCode::KeyB) => {
                    self.boundaries_visible = !self.boundaries_visible;
                    if self.boundaries_visible {
                        self.boundaries.invalidate();
                        self.boundaries_need_refresh = true;
                    }
                    return;
                }
                PhysicalKey::Code(KeyCode::F1) => {
                    self.hud.toggle_help();
                    return;
                }
                PhysicalKey::Code(KeyCode::KeyN) => {
                    self.camera.set_compass_bearing_degrees(0.0, &self.terrain);
                    return;
                }
                _ => {}
            }
        }
        self.camera.input(event, &self.terrain);
    }

    pub fn is_grabbing_globe(&self) -> bool {
        self.camera.is_grabbing_globe()
    }

    fn set_navigation_control(&mut self, control: NavControl, fraction: f32) {
        match control {
            NavControl::Compass => {
                self.camera.set_compass_bearing_degrees(0.0, &self.terrain);
            }
            NavControl::Heading => {
                self.camera
                    .set_compass_bearing_degrees(fraction as f64 * 360.0, &self.terrain);
            }
            NavControl::Tilt => {
                let max_tilt = self.camera.maximum_tilt_degrees(&self.terrain);
                self.camera
                    .set_tilt_degrees(fraction as f64 * max_tilt, &self.terrain);
            }
        }
    }

    pub fn resize(&mut self, size: PhysicalSize<u32>) {
        if size.width == 0 || size.height == 0 {
            return;
        }
        self.size = size;
        self.config.width = size.width;
        self.config.height = size.height;
        self.camera.resize(size);
        self.nav_drag = None;
        self.surface.configure(&self.device, &self.config);
        self.depth = create_depth(&self.device, &self.config);
    }

    fn building_hit(&self,start:glam::DVec3,end:glam::DVec3,wall_up:Option<glam::DVec3>)->Option<f64> {
        [self.models.segment_hit(start,end,&self.terrain,wall_up),self.tile_models.segment_hit(start,end,&self.terrain,wall_up)].into_iter().flatten().min_by(f64::total_cmp)
    }
    pub fn update(&mut self) {
        if let Some(profile) = &mut self.profile {
            profile.frame_start = Instant::now();
        }
        let now = Instant::now();
        let delta_seconds = now.duration_since(self.last_camera_update).as_secs_f32();
        self.last_camera_update = now;
        if self.camera.is_orbit_dragging() {
            self.camera.enforce_drag_terrain_clearance(&self.terrain);
        } else {
            self.camera.enforce_terrain_clearance(&self.terrain);
        }
        let previous_foot=self.camera.walk_foot();
        self.camera.update_ground_navigation(delta_seconds, &self.terrain);
        if let (Some(start),Some(end))=(previous_foot,self.camera.walk_foot()) {
            let (lat,lon)=crate::geo::geodetic_lat_lon(start);
            let up=glam::DVec3::new(lat.cos()*lon.sin(),lat.sin(),lat.cos()*lon.cos());
            let fraction=crate::model_collision::body_fraction(start,end,up,|a,b|self.building_hit(a,b,Some(up)));
            self.camera.clip_walk_motion(start,fraction,&self.terrain);
        }
        self.camera
            .update_keyboard_tilt(delta_seconds, &self.terrain);
        self.camera
            .update_keyboard_rotation(delta_seconds, &self.terrain);
        let navigating = self.camera.is_navigation_active() || self.nav_drag.is_some();
        if navigating {
            self.last_navigation_motion = Some(now);
        }
        let defer_boundary_refinement = navigating
            || self
                .last_navigation_motion
                .is_some_and(|last| now.duration_since(last) < Duration::from_millis(180));
        let target_level = self.camera.target_tile_level();
        let visible_samples = self.camera.visible_terrain_samples(16, 10, &self.terrain);
        let eye_m = self.camera.eye_m();
        let near_visible_distance_m = visible_samples
            .iter()
            .map(|point| {
                (glam::DVec3::new(point.x as f64, point.y as f64, point.z as f64)
                    * crate::geo::SEMI_MAJOR_M
                    - eye_m)
                    .length()
            })
            .reduce(f64::min)
            .unwrap_or_else(|| self.camera.eye_clearance_m().max(1.0));
        let terrain_started = Instant::now();
        let terrain_changed = self
            .terrain
            .update(&visible_samples, self.camera.target_terrain_level());
        let boundary_dem_changed = if defer_boundary_refinement {
            self.deferred_boundary_dem
                .extend(terrain_changed.iter().copied());
            Vec::new()
        } else {
            let mut changed: Vec<_> = self.deferred_boundary_dem.drain().collect();
            changed.extend(terrain_changed.iter().copied());
            changed
        };
        if let Some(profile) = &mut self.profile {
            profile.record(1, terrain_started);
        }
        if self.camera.is_orbit_dragging() {
            self.camera.enforce_drag_terrain_clearance(&self.terrain);
        } else {
            self.camera.enforce_terrain_clearance(&self.terrain);
        }
        let layout = NavLayout::new(self.size.width, self.size.height);
        let scale_bar = self
            .camera
            .ground_metres_per_pixel(&self.terrain)
            .and_then(|metres_per_pixel| ScaleBar::new(metres_per_pixel, 120.0 * layout.scale));
        self.hud.set_navigation_readout(
            scale_bar,
            self.camera.eye_height_m(),
            self.camera.eye_clearance_m(),
        );
        let (tilt, _) = self.camera.view_angles_degrees();
        self.navigation.update(
            &self.queue,
            self.size.width,
            self.size.height,
            self.camera.compass_north_angle_radians() as f32,
            self.camera.compass_bearing_degrees() as f32,
            tilt as f32,
            self.camera.maximum_tilt_degrees(&self.terrain) as f32,
            scale_bar.map(|bar| bar.pixel_width).unwrap_or(0.0),
        );
        let imagery_started = Instant::now();
        self.tiles.update(
            &self.device,
            &self.queue,
            target_level,
            &visible_samples,
            eye_m,
            if self.camera.is_walking() { near_visible_distance_m.max(128.0) } else { near_visible_distance_m },
            &self.terrain,
            &terrain_changed,
            self.camera.is_walking() || !defer_boundary_refinement,
        );
        if let Some((lat,lon))=self.camera.walk_position() {
            self.camera.protect_rendered_ground(self.tiles.rendered_ground(lat,lon),&self.terrain);
            let (eye_lat,eye_lon)=crate::geo::geodetic_lat_lon(self.camera.eye_m());
            self.camera.protect_follow_camera(self.tiles.rendered_ground(eye_lat,eye_lon));
            if let Some((target,end))=self.camera.follow_segment() {
                let distance=target.distance(end);
                if distance>0.01 {
                    let (lat,lon)=crate::geo::geodetic_lat_lon(target);
                    let up=glam::DVec3::new(lat.cos()*lon.sin(),lat.sin(),lat.cos()*lon.cos());
                    let side=(end-target).cross(up).normalize_or_zero()*0.12;
                    let mut fraction:f64=1.;
                    for offset in [glam::DVec3::ZERO,side,-side,up*0.12,-up*0.12] {
                        if let Some(t)=self.building_hit(target+offset,end+offset,None){fraction=fraction.min((t-0.25/distance).max(0.));}
                    }
                    self.camera.shorten_follow_camera(fraction);
                }
            }
            self.tiles.sync_eye(&self.queue,self.camera.eye_m());
        }
        self.queue.write_buffer(
            &self.camera_buffer,
            0,
            bytemuck::bytes_of(&self.camera.uniform()),
        );
        if self.camera.is_walking() { self.sky.update(&self.queue, &self.camera); }
        if let Some(profile) = &mut self.profile {
            profile.record(2, imagery_started);
        }
        let grid_started = Instant::now();
        self.graticule.update(
            &self.queue,
            &self.camera,
            self.size.width,
            self.size.height,
            &visible_samples,
            &self.terrain,
            delta_seconds,
        );
        if let Some(profile) = &mut self.profile {
            profile.record(3, grid_started);
        }
        self.hud.set_grid_labels(if self.camera.is_walking() { &[] } else { self.graticule.labels() });
        let places_started = Instant::now();
        self.placenames.update(
            &self.camera,
            &self.terrain,
            &visible_samples,
            target_level,
            (self.size.width, self.size.height),
            !terrain_changed.is_empty(),
        );
        if let Some(profile) = &mut self.profile {
            profile.record(4, places_started);
        }
        let admin_scale = self.camera.administration_zoom_scale();
        let admin_zoom = Administration::select_zoom(
            self.admin_zoom,
            admin_scale,
            self.placenames.is_country_mode(),
        );
        self.admin_zoom = admin_zoom;
        let admin_started = Instant::now();
        let administration_changed = self.administration.update(
            &self.camera,
            &self.terrain,
            &visible_samples,
            admin_zoom,
            (self.size.width, self.size.height),
            &boundary_dem_changed,
        );
        if let Some(profile) = &mut self.profile {
            profile.record(5, admin_started);
        }
        #[cfg(target_arch = "wasm32")]
        self.hud
            .set_cache_usage(self.administration.cache_usage_bytes());
        if defer_boundary_refinement && administration_changed {
            self.boundaries_need_refresh = true;
        }
        if self.boundaries_visible && !self.camera.is_walking()
            && !defer_boundary_refinement
            && (administration_changed || self.boundaries_need_refresh)
        {
            self.boundaries_need_refresh = false;
            let rebuild_started = Instant::now();
            let stats = self.boundaries.update_geometry(
                &self.device,
                &self.queue,
                self.administration.major_rings(),
                self.administration.minor_rings(),
                admin_zoom,
                &self.terrain,
                &boundary_dem_changed,
            );
            if let Some(profile) = &mut self.profile {
                profile.record(6, rebuild_started);
                profile.rebuilds += 1;
                profile.skipped_boundary_rebuilds += u32::from(stats.skipped);
                profile.patched_boundary_updates += u32::from(stats.patched);
                profile.upload_bytes += stats.bytes as u64;
                profile.resampled_rings += stats.resampled as u64;
                profile.reused_rings += stats.reused as u64;
            }
        }
        self.boundaries.update_view(
            &self.queue,
            &self.camera,
            self.size.width,
            self.size.height,
            Administration::child_boundary_opacity(admin_scale, admin_zoom),
            near_visible_distance_m,
        );
        let labels =
            if !self.placenames.is_country_mode() && !self.administration.labels().is_empty() {
                self.administration.labels()
            } else {
                self.placenames.labels()
            };
        self.hud.set_place_labels(if self.camera.is_walking() { &[] } else { labels });
        let source = self.tiles.stats().attribution;
        if self.administration.has_data() {
            self.hud
                .set_attribution(&format!("{source} | {}", self.administration.attribution()));
        } else {
            self.hud.set_attribution(source);
        }
    }

    pub fn render(&mut self) -> RenderStatus {
        let boundary_stats;
        let frame = match self.surface.get_current_texture() {
            wgpu::CurrentSurfaceTexture::Success(frame) => frame,
            wgpu::CurrentSurfaceTexture::Suboptimal(frame) => frame,
            wgpu::CurrentSurfaceTexture::Timeout | wgpu::CurrentSurfaceTexture::Occluded => {
                return RenderStatus::Skipped;
            }
            wgpu::CurrentSurfaceTexture::Outdated
            | wgpu::CurrentSurfaceTexture::Lost
            | wgpu::CurrentSurfaceTexture::Validation => return RenderStatus::Reconfigure,
        };
        let view = frame.texture.create_view(&Default::default());
        if let Err(error) = self.hud.prepare(
            &self.device,
            &self.queue,
            self.config.width,
            self.config.height,
        ) {
            log::warn!("HUD preparation failed: {error:#}");
        }
        self.marker.update(
            &self.queue,
            self.camera.rotation_marker_position(),
            self.config.width,
            self.config.height,
        );
        self.vectors.update(&self.queue, &self.camera, &self.terrain, self.config.width, self.config.height);
        self.tile_models.update(&self.queue, &self.camera, &self.terrain);
        self.models.update(&self.queue, &self.camera, &self.terrain);
        self.walker.set_walker_pose(self.camera.walk_animation());
        let _ = self.walker.scene(&self.camera.walk_avatar());
        self.walker.update(&self.queue,&self.camera,&self.terrain);
        self.images.update(&self.queue, &self.camera, &self.terrain);
        let mut encoder = self
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor {
                label: Some("frame encoder"),
            });
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("WGS84 imagery pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    depth_slice: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color {
                            r: 0.003,
                            g: 0.008,
                            b: 0.022,
                            a: 1.0,
                        }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &self.depth,
                    depth_ops: Some(wgpu::Operations {
                        load: wgpu::LoadOp::Clear(1.0),
                        store: wgpu::StoreOp::Store,
                    }),
                    stencil_ops: None,
                }),
                timestamp_writes: None,
                occlusion_query_set: None,
                multiview_mask: None,
            });
            if self.camera.is_walking() { self.sky.draw(&mut pass); }
            pass.set_bind_group(0, &self.camera_bind_group, &[]);
            self.tiles.draw(&mut pass);
            self.images.draw(&mut pass, &self.camera_bind_group);
            self.tile_models.draw(&mut pass, &self.camera_bind_group);
            self.models.draw(&mut pass, &self.camera_bind_group);
            self.walker.draw(&mut pass, &self.camera_bind_group);
            let boundary_started = Instant::now();
            boundary_stats = if self.boundaries_visible && !self.camera.is_walking() {
                self.boundaries
                    .draw(&mut pass, &self.camera_bind_group, &self.camera)
            } else {
                (0, 0)
            };
            if let Some(profile) = &mut self.profile {
                profile.record(7, boundary_started);
            }
            if !self.camera.is_walking() { self.graticule.draw(&mut pass); }
            self.vectors.draw(&mut pass);
        }
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("HUD pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    depth_slice: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Load,
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
                multiview_mask: None,
            });
            self.marker.draw(&mut pass);
            self.navigation.draw(&mut pass);
            self.hud.render_background(&mut pass);
            if let Err(error) = self.hud.render(&mut pass) {
                log::warn!("HUD rendering failed: {error:#}");
            }
        }
        self.queue.submit(Some(encoder.finish()));
        self.queue.present(frame);
        self.fps_presented_frames += 1;
        let elapsed = self.fps_window_start.elapsed().as_secs_f32();
        if elapsed >= 0.5 {
            self.hud.set_fps(self.fps_presented_frames as f32 / elapsed);
            self.fps_presented_frames = 0;
            self.fps_window_start = Instant::now();
        }
        self.hud.trim();
        if let Some(profile) = &mut self.profile {
            profile.finish(boundary_stats.0, boundary_stats.1);
        }
        RenderStatus::Presented
    }
}

fn create_depth(device: &wgpu::Device, config: &wgpu::SurfaceConfiguration) -> wgpu::TextureView {
    device
        .create_texture(&wgpu::TextureDescriptor {
            label: Some("depth texture"),
            size: wgpu::Extent3d {
                width: config.width,
                height: config.height,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Depth32Float,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            view_formats: &[],
        })
        .create_view(&Default::default())
}

include!("keeper_renderer.rs");
