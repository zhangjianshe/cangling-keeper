struct Camera {
    view_projection: mat4x4<f32>,
    eye: vec4<f32>,
};

struct BoundaryView {
    eye_high: vec4<f32>,
    eye_low: vec4<f32>,
    viewport: vec4<f32>, // width, height, minor opacity, near surface distance / Earth radius
};

@group(0) @binding(0) var<uniform> camera: Camera;
@group(1) @binding(0) var<uniform> view: BoundaryView;

struct VertexInput {
    @location(0) start_high: vec3<f32>,
    @location(1) start_low: vec3<f32>,
    @location(2) end_high: vec3<f32>,
    @location(3) end_low: vec3<f32>,
    @location(4) corner: vec2<f32>, // endpoint (0/1), side (-1/+1)
    @location(5) style: f32,
};

struct VertexOutput {
    @builtin(position) position: vec4<f32>,
    @location(0) side_px: f32,
    @location(1) opacity: f32,
    @location(2) style: f32,
};

@vertex
fn vs_main(input: VertexInput) -> VertexOutput {
    var out: VertexOutput;
    let start = (input.start_high - view.eye_high.xyz) + (input.start_low - view.eye_low.xyz);
    let end = (input.end_high - view.eye_high.xyz) + (input.end_low - view.eye_low.xyz);
    var a = camera.view_projection * vec4<f32>(start, 1.0);
    var b = camera.view_projection * vec4<f32>(end, 1.0);
    if (a.z < 0.0 && b.z < 0.0) {
        out.position = vec4<f32>(2.0, 2.0, 0.0, 1.0);
        out.side_px = 0.0;
        out.opacity = 0.0;
        out.style = input.style;
        return out;
    }
    if (a.z < 0.0) {
        a = mix(a, b, clamp(-a.z / (b.z - a.z), 0.0, 1.0));
    } else if (b.z < 0.0) {
        b = mix(b, a, clamp(-b.z / (a.z - b.z), 0.0, 1.0));
    }
    let screen_delta = (b.xy / b.w - a.xy / a.w) * vec2<f32>(view.viewport.x, -view.viewport.y);
    let length_px = length(screen_delta);
    if (length_px < 0.05) {
        out.position = vec4<f32>(2.0, 2.0, 0.0, 1.0);
        out.side_px = 0.0;
        out.opacity = 0.0;
        out.style = input.style;
        return out;
    }
    let direction = screen_delta / length_px;
    let normal = vec2<f32>(-direction.y, direction.x);
    let half_width = 1.5;
    let side_px = input.corner.y * half_width;
    let endpoint = select(a, b, input.corner.x > 0.5);
    let extension = direction * select(-0.8, 0.8, input.corner.x > 0.5);
    let pixel_offset = normal * side_px + extension;
    let ndc_offset = pixel_offset * vec2<f32>(2.0 / view.viewport.x, -2.0 / view.viewport.y);
    out.position = endpoint + vec4<f32>(ndc_offset * endpoint.w, 0.0, 0.0);
    out.side_px = side_px;
    let distance_ratio = length(mix(start, end, input.corner.x)) / max(view.viewport.w, 1e-7);
    let minor_fade = 1.0 - smoothstep(1.8, 3.2, distance_ratio);
    let major_fade = 1.0 - smoothstep(3.2, 5.5, distance_ratio);
    out.opacity = select(view.viewport.z * minor_fade, major_fade, input.style > 1.5);
    out.style = input.style;
    return out;
}

@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    let distance = abs(input.side_px);
    if (input.style > 1.5) {
        let halo = 1.0 - smoothstep(1.0, 1.5, distance);
        let core = 1.0 - smoothstep(0.35, 1.15, distance);
        let color = mix(vec3<f32>(0.06, 0.08, 0.10), vec3<f32>(1.0, 1.0, 1.0), core);
        return vec4<f32>(color, (0.28 * halo + 0.70 * core) * input.opacity);
    }
    let outline = 1.0 - smoothstep(0.9, 1.5, distance);
    let core = 1.0 - smoothstep(0.35, 0.9, distance);
    let color = mix(vec3<f32>(0.015, 0.025, 0.045), vec3<f32>(0.91, 0.95, 1.0), core);
    return vec4<f32>(color, (0.2 * outline + 0.8 * core) * input.opacity);
}
