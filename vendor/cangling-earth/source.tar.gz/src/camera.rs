use bytemuck::{Pod, Zeroable};
use glam::{
    DMat3, DQuat, DVec2, DVec3, Mat4, Quat, Vec2, Vec3, Vec4,
    camera::{rh::proj::directx, rh::view},
};
use winit::{
    dpi::{PhysicalPosition, PhysicalSize},
    event::{ElementState, MouseButton, MouseScrollDelta, WindowEvent},
    keyboard::{KeyCode, PhysicalKey},
};

use crate::{
    geo::{self, SEMI_MAJOR_M},
    terrain::TerrainLayer,
};

const MIN_ALTITUDE_M: f64 = 20.0;
pub(crate) const FIELD_OF_VIEW: f32 = 45.0_f32.to_radians();
const PATROL_RADIANS_PER_SECOND: f64 = 15.0_f64.to_radians();
const PAN_SPEED_PER_CLEARANCE: f64 = 0.25;
const HOME_DISTANCE_M: f64 = 3.1 * SEMI_MAJOR_M;
const HOME_FLIGHT_SECONDS: f64 = 1.2;
const KEYBOARD_TILT_RESPONSE_PER_SECOND: f64 = 16.0;
const KEYBOARD_TILT_DEGREES_PER_SECOND: f64 = 36.0;
const KEYBOARD_ROTATION_DEGREES_PER_SECOND: f64 = 45.0;

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
pub struct CameraUniform {
    view_projection: [[f32; 4]; 4],
    eye: [f32; 4],
}

#[derive(Clone, Copy)]
struct OrbitDrag {
    cursor: DVec2,
    tilt: f64,
    heading: f64,
    orientation: DQuat,
    distance_m: f64,
    pivot: Option<DVec3>,
}

#[derive(Clone, Copy)]
struct HomeFlight {
    orientation: DQuat,
    distance_m: f64,
    tilt: f64,
    heading: f64,
    elapsed: f64,
}

/// Orbital globe camera with surface-anchored dragging.
pub struct OrbitCamera {
    walk: Option<WalkState>,
    orientation: DQuat,
    distance_m: f64,
    target_distance_m: f64,
    min_distance_m: f64,
    ground_elevation_m: f64,
    tilt_radians: f64,
    heading_radians: f64,
    middle_drag_start: Option<OrbitDrag>,
    right_drag_start: Option<OrbitDrag>,
    patrol_start: Option<OrbitDrag>,
    zoom_anchor: Option<OrbitDrag>,
    viewport: PhysicalSize<u32>,
    cursor: Option<DVec2>,
    grab_point: Option<DVec3>,
    grab_orientation: Option<DQuat>,
    grab_distance_m: Option<f64>,
    pan_keys: [bool; 4],      // Up, Left, Down, Right
    pan_sources: [u8; 4],     // Arrow keys (bit 0), W/S aliases (bit 1)
    tilt_keys: [bool; 2],     // Q, E
    rotation_keys: [bool; 2], // A, D
    keyboard_tilt_target: Option<f64>,
    home_flight: Option<HomeFlight>,
}

impl OrbitCamera {
    pub fn new(viewport: PhysicalSize<u32>) -> Self {
        // Centre the startup globe on Xi'an with geographic north at the top.
        let orientation = home_orientation();
        Self {
            walk: None,
            orientation,
            distance_m: HOME_DISTANCE_M,
            target_distance_m: HOME_DISTANCE_M,
            min_distance_m: surface_radius(orientation) + MIN_ALTITUDE_M,
            ground_elevation_m: 0.0,
            tilt_radians: 0.0,
            heading_radians: 0.0,
            middle_drag_start: None,
            right_drag_start: None,
            patrol_start: None,
            zoom_anchor: None,
            viewport,
            cursor: None,
            grab_point: None,
            grab_orientation: None,
            grab_distance_m: None,
            pan_keys: [false; 4],
            pan_sources: [0; 4],
            tilt_keys: [false; 2],
            rotation_keys: [false; 2],
            keyboard_tilt_target: None,
            home_flight: None,
        }
    }

    pub fn resize(&mut self, viewport: PhysicalSize<u32>) {
        self.viewport = viewport;
        self.grab_point = None;
        self.grab_orientation = None;
        self.grab_distance_m = None;
        self.middle_drag_start = None;
        self.right_drag_start = None;
        self.patrol_start = None;
        self.zoom_anchor = None;
        self.pan_keys = [false; 4];
        self.pan_sources = [0; 4];
        self.tilt_keys = [false; 2];
        self.rotation_keys = [false; 2];
        self.keyboard_tilt_target = None;
    }

    /// Move to Sichuan's fine DEM without changing the normal orbit
    /// controls. The camera's local +Z axis points away from the Earth.
    pub fn focus_terrain_pilot(&mut self) {
        self.home_flight = None;
        self.keyboard_tilt_target = None;
        let latitude = 30.45_f64.to_radians();
        let longitude = 102.8_f64.to_radians();
        self.orientation = north_up_orientation(latitude, longitude);
        self.distance_m = surface_radius(self.orientation) + 25_000.0;
        self.target_distance_m = self.distance_m;
        self.tilt_radians = 35.0_f64.to_radians();
        self.heading_radians = 0.0;
        self.min_distance_m = surface_radius(self.orientation) + MIN_ALTITUDE_M;
        self.ground_elevation_m = 0.0;
        self.grab_point = None;
        self.grab_orientation = None;
        self.grab_distance_m = None;
        self.middle_drag_start = None;
        self.right_drag_start = None;
        self.patrol_start = None;
        self.zoom_anchor = None;
        self.pan_keys = [false; 4];
        self.pan_sources = [0; 4];
        self.tilt_keys = [false; 2];
        self.rotation_keys = [false; 2];
    }

    /// Fly back to the north-up Xi'an overview used at startup.
    pub fn fly_home(&mut self) {
        self.keyboard_tilt_target = None;
        self.patrol_start = None;
        self.zoom_anchor = None;
        self.middle_drag_start = None;
        self.right_drag_start = None;
        self.grab_point = None;
        self.grab_orientation = None;
        self.grab_distance_m = None;
        self.pan_keys = [false; 4];
        self.pan_sources = [0; 4];
        self.tilt_keys = [false; 2];
        self.rotation_keys = [false; 2];
        self.target_distance_m = self.distance_m;
        self.home_flight = Some(HomeFlight {
            orientation: self.orientation,
            distance_m: self.distance_m,
            tilt: self.tilt_radians,
            heading: self.heading_radians,
            elapsed: 0.0,
        });
    }

    /// Toggle an automatic orbit around the terrain point at the screen centre.
    /// The picked point stays at the centre while the camera circles it.
    pub fn toggle_patrol(&mut self, terrain: &TerrainLayer) -> bool {
        self.home_flight = None;
        self.keyboard_tilt_target = None;
        if self.patrol_start.take().is_some() {
            return false;
        }
        let center = DVec2::new(
            self.viewport.width as f64 * 0.5,
            self.viewport.height as f64 * 0.5,
        );
        let Some(pivot) = self.pick_surface_terrain(center, terrain) else {
            return false;
        };
        self.target_distance_m = self.distance_m;
        self.middle_drag_start = None;
        self.right_drag_start = None;
        self.zoom_anchor = None;
        self.grab_point = None;
        self.grab_orientation = None;
        self.grab_distance_m = None;
        let start = OrbitDrag {
            cursor: center,
            tilt: self.tilt_radians,
            heading: self.heading_radians,
            orientation: self.orientation,
            distance_m: self.distance_m,
            pivot: Some(pivot),
        };
        // A nadir view would only spin the image in place. Introduce a safe
        // oblique angle while keeping the centre ray on the globe.
        let limb_angle = (pivot.length() / self.distance_m).clamp(0.0, 1.0).asin();
        let desired_tilt = 35.0_f64.to_radians().min(limb_angle * 0.7);
        self.tilt_radians = self.tilt_radians.max(desired_tilt);
        let Some(orientation) = self.orbit_orientation_for_anchor(start, self.distance_m) else {
            self.tilt_radians = start.tilt;
            return false;
        };
        self.orientation = orientation;
        self.patrol_start = Some(start);
        true
    }

    #[cfg(test)]
    pub fn is_patrolling(&self) -> bool {
        self.patrol_start.is_some()
    }

    pub fn input(&mut self, event: &WindowEvent, terrain: &TerrainLayer) {
        if self.is_walking() {
            if matches!(event, WindowEvent::Focused(false)) { self.walk_controls(0.,0.,false); }
            return;
        }
        match event {
            WindowEvent::CursorMoved { position, .. } => {
                let cursor = physical_position(*position);
                self.cursor = Some(cursor);
                if self.middle_drag_start.is_some() {
                    self.move_middle_drag(cursor);
                    return;
                }
                if self.right_drag_start.is_some() {
                    self.move_right_drag(cursor);
                    return;
                }

                let Some(grab_point) = self.grab_point else {
                    return;
                };
                let Some(grab_orientation) = self.grab_orientation else {
                    return;
                };
                let Some(grab_distance_m) = self.grab_distance_m else {
                    return;
                };
                let Some(current_point) = self.pick_surface_with_pose(
                    cursor,
                    grab_orientation,
                    grab_distance_m,
                    Some(terrain),
                ) else {
                    // Leaving the globe must not turn screen-space movement
                    // into an uncontrolled orbit.
                    return;
                };

                let globe_rotation =
                    DQuat::from_rotation_arc(grab_point.normalize(), current_point.normalize());
                let camera_rotation = globe_rotation.conjugate();
                self.orientation = (camera_rotation * grab_orientation).normalize();
                let altitude = grab_distance_m - surface_radius(grab_orientation);
                self.distance_m = surface_radius(self.orientation) + altitude;
                self.target_distance_m = self.distance_m;
            }
            WindowEvent::MouseInput {
                state,
                button: MouseButton::Left,
                ..
            } => {
                if *state == ElementState::Pressed {
                    self.keyboard_tilt_target = None;
                    self.home_flight = None;
                    self.patrol_start = None;
                    self.right_drag_start = None;
                    self.zoom_anchor = None;
                    self.target_distance_m = self.distance_m;
                    self.grab_orientation = Some(self.orientation);
                    self.grab_point = self
                        .cursor
                        .and_then(|cursor| self.pick_surface_terrain(cursor, terrain));
                    self.grab_distance_m = Some(self.distance_m);
                } else {
                    self.grab_point = None;
                    self.grab_orientation = None;
                    self.grab_distance_m = None;
                }
            }
            WindowEvent::MouseInput {
                state,
                button: MouseButton::Middle,
                ..
            } => {
                if *state == ElementState::Pressed {
                    self.keyboard_tilt_target = None;
                    self.home_flight = None;
                }
                self.middle_drag_start = if *state == ElementState::Pressed {
                    self.patrol_start = None;
                    self.zoom_anchor = None;
                    self.target_distance_m = self.distance_m;
                    self.cursor.map(|cursor| OrbitDrag {
                        cursor,
                        tilt: self.tilt_radians,
                        heading: self.heading_radians,
                        orientation: self.orientation,
                        distance_m: self.distance_m,
                        pivot: self.pick_surface_terrain(cursor, terrain),
                    })
                } else {
                    None
                };
                self.right_drag_start = None;
                self.grab_point = None;
                self.grab_orientation = None;
                self.grab_distance_m = None;
            }
            WindowEvent::MouseInput {
                state,
                button: MouseButton::Right,
                ..
            } => {
                if *state == ElementState::Pressed {
                    self.keyboard_tilt_target = None;
                    self.home_flight = None;
                }
                self.right_drag_start = if *state == ElementState::Pressed {
                    self.patrol_start = None;
                    self.zoom_anchor = None;
                    self.target_distance_m = self.distance_m;
                    self.cursor.map(|cursor| OrbitDrag {
                        cursor,
                        tilt: self.tilt_radians,
                        heading: self.heading_radians,
                        orientation: self.orientation,
                        distance_m: self.distance_m,
                        pivot: self.pick_surface_terrain(cursor, terrain),
                    })
                } else {
                    None
                };
                self.middle_drag_start = None;
                self.grab_point = None;
                self.grab_orientation = None;
                self.grab_distance_m = None;
            }
            WindowEvent::MouseWheel { delta, .. } => {
                let amount = match delta {
                    MouseScrollDelta::LineDelta(_, y) => *y as f64,
                    MouseScrollDelta::PixelDelta(p) => p.y * 0.02,
                };
                self.zoom_input(amount, terrain);
            }
            WindowEvent::KeyboardInput { event, .. } => {
                if event.state == ElementState::Pressed {
                    if let Some(amount) = zoom_key_amount(event.physical_key) {
                        self.zoom_input(amount, terrain);
                        return;
                    }
                }
                if let Some((index, source)) = pan_key_binding(event.physical_key) {
                    if event.state == ElementState::Pressed {
                        self.pan_sources[index] |= source;
                    } else {
                        self.pan_sources[index] &= !source;
                    }
                    self.pan_keys[index] = self.pan_sources[index] != 0;
                    if self.pan_keys[index] {
                        self.home_flight = None;
                        self.patrol_start = None;
                        self.zoom_anchor = None;
                        self.target_distance_m = self.distance_m;
                    }
                }
                let pressed = event.state == ElementState::Pressed;
                if let Some(index) = tilt_key_index(event.physical_key) {
                    self.tilt_keys[index] = pressed;
                }
                match event.physical_key {
                    PhysicalKey::Code(KeyCode::KeyA) => self.rotation_keys[0] = pressed,
                    PhysicalKey::Code(KeyCode::KeyD) => self.rotation_keys[1] = pressed,
                    _ => {}
                }
            }
            WindowEvent::Focused(false) | WindowEvent::CursorLeft { .. } => {
                self.pan_keys = [false; 4];
                self.pan_sources = [0; 4];
                self.tilt_keys = [false; 2];
                self.rotation_keys = [false; 2];
                self.keyboard_tilt_target = None;
                self.grab_point = None;
                self.grab_orientation = None;
                self.grab_distance_m = None;
            }
            _ => {}
        }
    }

    pub fn uniform(&self) -> CameraUniform {
        let view_projection = self.view_projection();
        CameraUniform {
            view_projection: view_projection.to_cols_array_2d(),
            eye: [0.0, 0.0, 0.0, 1.0],
        }
    }

    pub fn eye_m(&self) -> DVec3 {
        if let Some(w)=&self.walk{return geo::geodetic_position(w.latitude,w.longitude,w.elevation+1.7);}
        self.orientation * DVec3::Z * self.distance_m
    }

    pub fn is_grabbing_globe(&self) -> bool {
        self.grab_point.is_some()
    }

    /// WGS84 ellipsoidal height of the camera eye in metres.
    pub fn eye_height_m(&self) -> f64 {
        let eye = self.eye_m();
        let (latitude, _) = geo::geodetic_lat_lon(eye);
        geo::geodetic_height(eye, latitude).max(0.0)
    }

    /// Vertical distance from the eye to the DEM directly below it.
    pub fn eye_clearance_m(&self) -> f64 {
        (self.eye_height_m() - self.ground_elevation_m).max(0.0)
    }

    /// Approximate surface metres represented by one physical screen pixel at
    /// the view centre, including loaded terrain in the Sichuan pilot.
    pub fn ground_metres_per_pixel(&self, terrain: &TerrainLayer) -> Option<f64> {
        let center = self.screen_center();
        let mut span =
            (self.viewport.width.min(self.viewport.height) as f64 * 0.12).clamp(12.0, 100.0);
        for _ in 0..3 {
            let left = self.pick_surface_terrain(center - DVec2::new(span * 0.5, 0.0), terrain);
            let right = self.pick_surface_terrain(center + DVec2::new(span * 0.5, 0.0), terrain);
            if let (Some(left), Some(right)) = (left, right) {
                let (lat_a, lon_a) = geo::geodetic_lat_lon(left);
                let (lat_b, lon_b) = geo::geodetic_lat_lon(right);
                let half_lat = ((lat_b - lat_a) * 0.5).sin();
                let half_lon = ((lon_b - lon_a) * 0.5).sin();
                let haversine = (half_lat * half_lat
                    + lat_a.cos() * lat_b.cos() * half_lon * half_lon)
                    .clamp(0.0, 1.0);
                let distance_m = 2.0 * 6_371_008.8 * haversine.sqrt().asin();
                if distance_m.is_finite() && distance_m > 0.0 {
                    return Some(distance_m / span);
                }
            }
            span *= 0.5;
        }
        None
    }

    pub fn view_angles_degrees(&self) -> (f64, f64) {
        (
            self.tilt_radians.to_degrees(),
            self.heading_radians.to_degrees(),
        )
    }

    /// Direction of geographic north on screen, clockwise from screen up.
    pub fn compass_north_angle_radians(&self) -> f64 {
        let center = self.screen_center();
        let point = self
            .pick_surface(center)
            .unwrap_or_else(|| self.orientation * DVec3::Z * surface_radius(self.orientation));
        let (latitude, longitude) = geo::geodetic_lat_lon(point);
        let north = DVec3::new(
            -latitude.sin() * longitude.sin(),
            latitude.cos(),
            -latitude.sin() * longitude.cos(),
        );
        let view = self.view_orientation(self.orientation);
        let x = north.dot(view * DVec3::X);
        let y = north.dot(view * DVec3::Y);
        if x * x + y * y < 1e-12 {
            0.0
        } else {
            x.atan2(y)
        }
    }

    pub fn compass_bearing_degrees(&self) -> f64 {
        (-self.compass_north_angle_radians())
            .rem_euclid(std::f64::consts::TAU)
            .to_degrees()
    }

    /// The entire tilt slider spans the range reachable at the current distance.
    pub fn maximum_tilt_degrees(&self, terrain: &TerrainLayer) -> f64 {
        let radius = self
            .pick_surface_terrain(self.screen_center(), terrain)
            .map(DVec3::length)
            .unwrap_or_else(|| surface_radius(self.orientation));
        self.tilt_limit_radians(radius).to_degrees()
    }

    fn tilt_limit_radians(&self, pivot_radius: f64) -> f64 {
        ((pivot_radius / self.distance_m).clamp(0.0, 1.0).asin() * 0.96).min(75.0_f64.to_radians())
    }

    /// Toggle nadir (0 degrees) and oblique (45 degrees), retaining the ground anchor.
    pub fn toggle_view_tilt(&mut self, terrain: &TerrainLayer) -> bool {
        let target = if self.tilt_radians.abs() > 0.01_f64.to_radians() { 0.0 } else { 45.0 };
        self.set_tilt_degrees(target, terrain)
    }

    /// Set tilt while preserving the current centre-of-screen terrain point.
    pub fn set_tilt_degrees(&mut self, degrees: f64, terrain: &TerrainLayer) -> bool {
        self.keyboard_tilt_target = None;
        self.apply_tilt_degrees(degrees, terrain)
    }

    fn apply_tilt_degrees(&mut self, degrees: f64, terrain: &TerrainLayer) -> bool {
        self.home_flight = None;
        let Some(start) = self.center_orbit_anchor(terrain) else {
            return false;
        };
        let old_tilt = self.tilt_radians;
        let max_tilt = self.tilt_limit_radians(start.pivot.unwrap().length());
        self.tilt_radians = degrees.to_radians().clamp(0.0, max_tilt);
        let Some(orientation) = self.orbit_orientation_for_anchor(start, self.distance_m) else {
            self.tilt_radians = old_tilt;
            return false;
        };
        self.orientation = orientation;
        self.patrol_start = None;
        self.zoom_anchor = None;
        self.target_distance_m = self.distance_m;
        true
    }

    fn queue_keyboard_tilt(&mut self, step_degrees: f64, terrain: &TerrainLayer) {
        if self.is_orbit_dragging() || self.grab_point.is_some() {
            return;
        }
        let current_target = self.keyboard_tilt_target.unwrap_or(self.tilt_radians);
        let maximum = self.maximum_tilt_degrees(terrain).to_radians();
        let target = (current_target + step_degrees.to_radians()).clamp(0.0, maximum);
        self.keyboard_tilt_target = ((target - self.tilt_radians).abs() > 1e-6).then_some(target);
        if self.keyboard_tilt_target.is_some() {
            self.home_flight = None;
            self.patrol_start = None;
            self.zoom_anchor = None;
            self.target_distance_m = self.distance_m;
        }
    }

    /// Ease Q/E tilt toward its queued angle around the screen-centre terrain point.
    pub fn update_keyboard_tilt(&mut self, delta_seconds: f32, terrain: &TerrainLayer) {
        let direction = self.tilt_keys[0] as i32 - self.tilt_keys[1] as i32;
        if direction != 0 {
            self.queue_keyboard_tilt(
                direction as f64 * KEYBOARD_TILT_DEGREES_PER_SECOND * delta_seconds as f64,
                terrain,
            );
        }
        let Some(queued_target) = self.keyboard_tilt_target else {
            return;
        };
        let dt = (delta_seconds as f64).clamp(0.0, 0.05);
        if dt == 0.0 {
            return;
        }
        let target = queued_target.min(self.maximum_tilt_degrees(terrain).to_radians());
        self.keyboard_tilt_target = Some(target);
        let remaining = target - self.tilt_radians;
        let next = if remaining.abs() < 0.02_f64.to_radians() {
            target
        } else {
            self.tilt_radians + remaining * (1.0 - (-KEYBOARD_TILT_RESPONSE_PER_SECOND * dt).exp())
        };
        if !self.apply_tilt_degrees(next.to_degrees(), terrain)
            || (target - self.tilt_radians).abs() < 1e-8
        {
            self.keyboard_tilt_target = None;
        }
    }

    /// Rotate around the terrain point at the screen centre while A/D is held.
    pub fn update_keyboard_rotation(&mut self, delta_seconds: f32, terrain: &TerrainLayer) {
        let direction = self.rotation_keys[1] as i32 - self.rotation_keys[0] as i32;
        if direction == 0 || self.is_orbit_dragging() || self.grab_point.is_some() {
            return;
        }
        let dt = (delta_seconds as f64).clamp(0.0, 0.05);
        if dt == 0.0 {
            return;
        }
        let Some(anchor) = self.center_orbit_anchor(terrain) else {
            return;
        };
        let previous_heading = self.heading_radians;
        self.heading_radians = (previous_heading
            - direction as f64 * KEYBOARD_ROTATION_DEGREES_PER_SECOND.to_radians() * dt)
            .rem_euclid(std::f64::consts::TAU);
        if let Some(orientation) = self.orbit_orientation_for_anchor(anchor, self.distance_m) {
            self.orientation = orientation;
            self.home_flight = None;
            self.patrol_start = None;
            self.zoom_anchor = None;
            self.target_distance_m = self.distance_m;
        } else {
            self.heading_radians = previous_heading;
        }
    }

    /// Set the geographic bearing shown by the compass and heading bar.
    pub fn set_compass_bearing_degrees(&mut self, degrees: f64, terrain: &TerrainLayer) -> bool {
        self.keyboard_tilt_target = None;
        self.home_flight = None;
        let Some(start) = self.center_orbit_anchor(terrain) else {
            return false;
        };
        let old_orientation = self.orientation;
        let old_heading = self.heading_radians;
        let target = degrees.rem_euclid(360.0);
        for _ in 0..5 {
            let current = self.compass_bearing_degrees();
            let correction = (target - current + 180.0).rem_euclid(360.0) - 180.0;
            if correction.abs() < 0.02 {
                break;
            }
            self.heading_radians =
                (self.heading_radians - correction.to_radians()).rem_euclid(std::f64::consts::TAU);
            let Some(orientation) = self.orbit_orientation_for_anchor(start, self.distance_m)
            else {
                self.orientation = old_orientation;
                self.heading_radians = old_heading;
                return false;
            };
            self.orientation = orientation;
        }
        self.patrol_start = None;
        self.zoom_anchor = None;
        self.target_distance_m = self.distance_m;
        true
    }

    fn screen_center(&self) -> DVec2 {
        DVec2::new(
            self.viewport.width as f64 * 0.5,
            self.viewport.height as f64 * 0.5,
        )
    }

    fn center_orbit_anchor(&self, terrain: &TerrainLayer) -> Option<OrbitDrag> {
        let cursor = self.screen_center();
        Some(OrbitDrag {
            cursor,
            tilt: self.tilt_radians,
            heading: self.heading_radians,
            orientation: self.orientation,
            distance_m: self.distance_m,
            pivot: Some(self.pick_surface_terrain(cursor, terrain)?),
        })
    }

    fn view_orientation(&self, orientation: DQuat) -> DQuat {
        let orientation=if let Some(w)=&self.walk {
            let up=DVec3::new(w.latitude.cos()*w.longitude.sin(),w.latitude.sin(),w.latitude.cos()*w.longitude.cos());
            let east=DVec3::new(w.longitude.cos(),0.,-w.longitude.sin());
            DQuat::from_mat3(&DMat3::from_cols(east,up.cross(east),up))
        }else{orientation};
        orientation
            * DQuat::from_rotation_z(self.heading_radians)
            * DQuat::from_rotation_x(self.tilt_radians)
    }

    fn move_middle_drag(&mut self, cursor: DVec2) {
        let Some(start) = self.middle_drag_start else {
            return;
        };
        let previous_tilt = self.tilt_radians;
        let previous_heading = self.heading_radians;
        self.tilt_radians =
            (start.tilt - (cursor.y - start.cursor.y) * 0.004).clamp(0.0, 75.0_f64.to_radians());
        // Horizontal middle-drag follows the direction of the scene orbit
        // around the fixed pivot, rather than the camera's local heading.
        self.heading_radians =
            (start.heading - (cursor.x - start.cursor.x) * 0.004).rem_euclid(std::f64::consts::TAU);
        self.orientation = if start.pivot.is_some() {
            let Some(orientation) = self.orbit_orientation_for_anchor(start, start.distance_m)
            else {
                self.tilt_radians = previous_tilt;
                self.heading_radians = previous_heading;
                return;
            };
            orientation
        } else {
            start.orientation
        };
        self.distance_m = start.distance_m;
        self.target_distance_m = self.distance_m;
    }

    fn move_right_drag(&mut self, cursor: DVec2) {
        let Some(start) = self.right_drag_start else {
            return;
        };
        let previous_heading = self.heading_radians;
        self.heading_radians =
            (start.heading - (cursor.x - start.cursor.x) * 0.004).rem_euclid(std::f64::consts::TAU);

        // Up zooms in, down zooms out. Deriving every frame from the initial
        // press prevents the cursor-event rate from changing the zoom amount.
        let start_radius = surface_radius(start.orientation);
        let start_altitude = (start.distance_m - start_radius).max(MIN_ALTITUDE_M);
        let exponent = ((cursor.y - start.cursor.y) * 0.005).clamp(-12.0, 12.0);
        let altitude = (start_altitude * exponent.exp()).clamp(MIN_ALTITUDE_M, 15.0 * SEMI_MAJOR_M);
        let mut distance = (start_radius + altitude).max(self.min_distance_m);
        let mut orientation = start.orientation;
        if let Some(pivot) = start.pivot {
            // Reconcile the radial WGS84 radius at the new eye position with
            // the fixed screen-space anchor. This also keeps zoom above the
            // picked terrain point and the most recent terrain clearance.
            let minimum = self.min_distance_m.max(pivot.length() + MIN_ALTITUDE_M);
            distance = distance.max(minimum);
            for _ in 0..8 {
                let Some(next_orientation) = self.orbit_orientation_for_anchor(start, distance)
                else {
                    self.heading_radians = previous_heading;
                    return;
                };
                orientation = next_orientation;
                let next_distance = (surface_radius(orientation) + altitude).max(minimum);
                if (next_distance - distance).abs() < 0.0001 {
                    break;
                }
                distance = next_distance;
            }
            let Some(final_orientation) = self.orbit_orientation_for_anchor(start, distance) else {
                self.heading_radians = previous_heading;
                return;
            };
            orientation = final_orientation;
        }
        self.orientation = orientation;
        self.distance_m = distance;
        self.target_distance_m = distance;
    }

    fn orbit_orientation_for_anchor(&self, start: OrbitDrag, distance_m: f64) -> Option<DQuat> {
        let pivot = start.pivot?;
        let direction = self.screen_ray_direction(start.cursor, start.orientation)?;
        let current = geo::ray_sphere_intersection(
            start.orientation * DVec3::Z * distance_m,
            direction,
            pivot.length(),
        )?;
        let turn = DQuat::from_rotation_arc(pivot.normalize(), current.normalize());
        Some((turn.conjugate() * start.orientation).normalize())
    }

    pub fn is_orbit_dragging(&self) -> bool {
        self.middle_drag_start.is_some() || self.right_drag_start.is_some()
    }

    pub fn is_navigation_active(&self) -> bool {
        self.walk.as_ref().is_some_and(|w|w.forward!=0. || w.right!=0.)
            || self.grab_point.is_some()
            || self.is_orbit_dragging()
            || self.pan_keys.into_iter().any(|pressed| pressed)
            || self.tilt_keys.into_iter().any(|pressed| pressed)
            || self.rotation_keys.into_iter().any(|pressed| pressed)
            || self.keyboard_tilt_target.is_some()
            || self.home_flight.is_some()
            || (self.target_distance_m - self.distance_m).abs() > 0.001
    }

    /// Screen position of the fixed surface point used by the current orbit
    /// drag. Projecting the world anchor each frame keeps the indicator tied
    /// to the actual orbit pivot as the camera turns.
    pub fn rotation_marker_position(&self) -> Option<Vec2> {
        let pivot = self
            .middle_drag_start
            .or(self.right_drag_start)
            .or(self.patrol_start)?
            .pivot?;
        let relative = (pivot - self.eye_m()) / SEMI_MAJOR_M;
        let clip = self.view_projection()
            * Vec4::new(relative.x as f32, relative.y as f32, relative.z as f32, 1.0);
        if clip.w <= 0.0 {
            return None;
        }
        let ndc = clip.truncate() / clip.w;
        let position = Vec2::new(
            (ndc.x + 1.0) * self.viewport.width as f32 * 0.5,
            (1.0 - ndc.y) * self.viewport.height as f32 * 0.5,
        );
        (position.x >= 0.0
            && position.y >= 0.0
            && position.x < self.viewport.width as f32
            && position.y < self.viewport.height as f32)
            .then_some(position)
    }

    pub fn update(&mut self, delta_seconds: f32) {
        let dt = (delta_seconds as f64).clamp(0.0, 0.05);
        if self.is_walking(){self.update_walk(dt);return;}
        if self.home_flight.is_some() {
            self.update_home_flight(dt);
            return;
        }
        let zoom_blend = 1.0 - (-12.0 * dt).exp();
        let mut next_distance =
            self.distance_m + (self.target_distance_m - self.distance_m) * zoom_blend;
        let zoom_finished = (self.target_distance_m - next_distance).abs() < 0.001;
        if zoom_finished {
            next_distance = self.target_distance_m;
        }
        if let Some(anchor) = self.zoom_anchor {
            if let Some(orientation) = self.orbit_orientation_for_anchor(anchor, next_distance) {
                self.orientation = orientation;
            } else {
                self.zoom_anchor = None;
            }
        }
        self.distance_m = next_distance;
        if zoom_finished {
            self.zoom_anchor = None;
        }
        if let Some(start) = self.patrol_start {
            let previous_heading = self.heading_radians;
            self.heading_radians = (self.heading_radians + PATROL_RADIANS_PER_SECOND * dt)
                .rem_euclid(std::f64::consts::TAU);
            if let Some(orientation) = self.orbit_orientation_for_anchor(start, self.distance_m) {
                self.orientation = orientation;
            } else {
                self.heading_radians = previous_heading;
                self.patrol_start = None;
            }
        }
        self.update_keyboard_pan(dt);
    }

    fn update_home_flight(&mut self, dt: f64) {
        let Some(mut flight) = self.home_flight else {
            return;
        };
        flight.elapsed += dt;
        let progress = (flight.elapsed / HOME_FLIGHT_SECONDS).clamp(0.0, 1.0);
        let zoom = smoothstep(progress / 0.65);
        let turn = smoothstep((progress - 0.20) / 0.80);
        let level = smoothstep(progress / 0.50);
        self.distance_m = (flight.distance_m + (HOME_DISTANCE_M - flight.distance_m) * zoom)
            .max(self.min_distance_m);
        self.target_distance_m = self.distance_m;
        self.orientation = flight
            .orientation
            .slerp(home_orientation(), turn)
            .normalize();
        self.tilt_radians = flight.tilt * (1.0 - level);
        let heading_delta = (-flight.heading + std::f64::consts::PI)
            .rem_euclid(std::f64::consts::TAU)
            - std::f64::consts::PI;
        self.heading_radians =
            (flight.heading + heading_delta * level).rem_euclid(std::f64::consts::TAU);
        if progress >= 1.0 {
            self.orientation = home_orientation();
            self.distance_m = HOME_DISTANCE_M;
            self.target_distance_m = HOME_DISTANCE_M;
            self.tilt_radians = 0.0;
            self.heading_radians = 0.0;
            self.home_flight = None;
        } else {
            self.home_flight = Some(flight);
        }
    }

    fn update_keyboard_pan(&mut self, dt: f64) {
        if dt <= 0.0
            || self.middle_drag_start.is_some()
            || self.right_drag_start.is_some()
            || self.grab_point.is_some()
        {
            return;
        }
        let horizontal = self.pan_keys[3] as i32 - self.pan_keys[1] as i32;
        let vertical = self.pan_keys[0] as i32 - self.pan_keys[2] as i32;
        if horizontal == 0 && vertical == 0 {
            return;
        }
        let outward = (self.orientation * DVec3::Z).normalize();
        let view = self.view_orientation(self.orientation);
        let right = view * DVec3::X;
        let up = view * DVec3::Y;
        let tangent = (right - outward * right.dot(outward)) * horizontal as f64
            + (up - outward * up.dot(outward)) * vertical as f64;
        if tangent.length_squared() < 1e-12 {
            return;
        }
        let speed_m_per_second =
            (self.eye_clearance_m() * PAN_SPEED_PER_CLEARANCE).clamp(8.0, 3_000_000.0);
        let angle = speed_m_per_second * dt / surface_radius(self.orientation);
        let axis = outward.cross(tangent.normalize()).normalize();
        let old_radius = surface_radius(self.orientation);
        self.orientation = (DQuat::from_axis_angle(axis, angle) * self.orientation).normalize();
        self.distance_m += surface_radius(self.orientation) - old_radius;
        self.target_distance_m = self.distance_m;
    }

    pub fn enforce_terrain_clearance(&mut self, terrain: &TerrainLayer) {
        if self.is_walking(){self.update_walk_surface(terrain);return;}
        self.refresh_terrain_clearance(terrain);
        self.distance_m = self.distance_m.max(self.min_distance_m);
        self.target_distance_m = self.target_distance_m.max(self.min_distance_m);
    }

    /// Raise the eye above newly loaded or newly crossed terrain while
    /// keeping an active middle/right-drag pivot under its original cursor.
    pub fn enforce_drag_terrain_clearance(&mut self, terrain: &TerrainLayer) {
        let anchor = self.middle_drag_start.or(self.right_drag_start);
        for _ in 0..8 {
            self.refresh_terrain_clearance(terrain);
            if self.distance_m >= self.min_distance_m {
                break;
            }
            let distance = self.min_distance_m;
            if let Some(start) = anchor
                && let Some(orientation) = self.orbit_orientation_for_anchor(start, distance)
            {
                self.orientation = orientation;
            }
            self.distance_m = distance;
        }
        self.refresh_terrain_clearance(terrain);
        self.distance_m = self.distance_m.max(self.min_distance_m);
        self.target_distance_m = self.distance_m;
    }

    /// Keep the projection and height readout current during a fixed-pivot
    /// drag without moving its camera anchor mid-gesture.
    pub fn refresh_terrain_clearance(&mut self, terrain: &TerrainLayer) {
        let outward = self.orientation * DVec3::Z;
        let ellipsoid = outward * surface_radius(self.orientation);
        let (latitude, longitude) = geo::geodetic_lat_lon(ellipsoid);
        let elevation = terrain.sample(latitude, longitude).max(0.0);
        self.ground_elevation_m = elevation;
        self.min_distance_m = surface_radius(self.orientation) + elevation + MIN_ALTITUDE_M;
    }

    /// Choose enough source texels for the physical screen pixels at the
    /// center of the view. The tile layer applies each source's own z limit.
    pub fn target_tile_level(&self) -> u8 {
        self.source_texel_screen_pixels(0)
            .log2()
            .ceil()
            .clamp(2.0, 19.0) as u8
    }

    /// Continuous administrative detail scale. A fixed reference latitude
    /// keeps the displayed boundary tier independent of a horizontal pan.
    pub fn administration_zoom_scale(&self) -> f64 {
        let altitude_m = (self.distance_m - surface_radius(self.orientation)).max(1.0);
        let ground_m_per_pixel = 2.0 * altitude_m * ((FIELD_OF_VIEW as f64) * 0.5).tan()
            / self.viewport.height.max(1) as f64;
        let reference_latitude = 35.0_f64.to_radians();
        let metres_per_tile_pixel =
            std::f64::consts::TAU * SEMI_MAJOR_M * reference_latitude.cos() / 256.0;
        (metres_per_tile_pixel / ground_m_per_pixel).log2()
    }

    /// Terrain samples may span up to four physical pixels while imagery
    /// remains near one texel per pixel. Source-specific limits are applied
    /// by TerrainLayer.
    pub fn target_terrain_level(&self) -> u8 {
        self.target_tile_level().saturating_sub(2).min(12)
    }

    /// Screen pixels covered by one source texel at the view centre.
    /// Values above 1 mean the source pixel is being enlarged.
    pub fn source_texel_screen_pixels(&self, level: u8) -> f64 {
        let altitude_m = (self.distance_m - surface_radius(self.orientation)).max(1.0);
        let ground_m_per_screen_pixel = 2.0 * altitude_m * ((FIELD_OF_VIEW as f64) * 0.5).tan()
            / self.viewport.height.max(1) as f64;
        let eye_direction = self.orientation * DVec3::Z;
        let center_surface = eye_direction * surface_radius(self.orientation);
        let (latitude, _) = geo::geodetic_lat_lon(center_surface);
        let tile_m_per_pixel_at_z0 =
            std::f64::consts::TAU * SEMI_MAJOR_M * latitude.cos().max(0.087) / 256.0;
        tile_m_per_pixel_at_z0 / (2.0_f64.powi(level as i32) * ground_m_per_screen_pixel)
    }

    fn apply_zoom(&mut self, wheel_amount: f64) {
        // Scale altitude, not distance from the earth's center. Multiplying
        // the full distance causes a single wheel step near the surface to
        // collapse altitude to the minimum and jump many LOD levels.
        let radius = surface_radius(self.orientation);
        let altitude = self.target_distance_m - radius;
        let step = wheel_amount.clamp(-2.0, 2.0);
        let new_altitude = altitude * (-step * 0.18).exp();
        self.target_distance_m = (radius + new_altitude).clamp(
            self.min_distance_m.max(radius + MIN_ALTITUDE_M),
            16.0 * SEMI_MAJOR_M,
        );
    }

    fn zoom_input(&mut self, amount: f64, terrain: &TerrainLayer) {
        self.keyboard_tilt_target = None;
        self.home_flight = None;
        self.patrol_start = None;
        self.apply_zoom_at_cursor(amount, terrain);
        self.grab_point = None;
        self.grab_orientation = None;
        self.grab_distance_m = None;
        self.middle_drag_start = None;
        self.right_drag_start = None;
    }

    fn apply_zoom_at_cursor(&mut self, wheel_amount: f64, terrain: &TerrainLayer) {
        let anchor = self.cursor.and_then(|cursor| {
            Some(OrbitDrag {
                cursor,
                tilt: self.tilt_radians,
                heading: self.heading_radians,
                orientation: self.orientation,
                distance_m: self.distance_m,
                pivot: Some(self.pick_surface_terrain(cursor, terrain)?),
            })
        });
        self.apply_zoom(wheel_amount);
        if let Some(pivot) = anchor.and_then(|start| start.pivot) {
            self.target_distance_m = self.target_distance_m.max(pivot.length() + MIN_ALTITUDE_M);
        }
        self.zoom_anchor = anchor;
    }

    /// Samples the visible globe through actual screen rays. These points are
    /// used by the tile quadtree instead of guessing visibility from longitude
    /// and latitude bounds.
    pub fn visible_surface_samples(&self, columns: u32, rows: u32) -> Vec<Vec3> {
        let mut samples = Vec::with_capacity((columns * rows) as usize);
        // Horizon rays intersect the ellipsoid kilometres beyond the feet in hills.
        // Explicitly request the local ground footprint before the distant view.
        if let Some(w)=&self.walk {
            let up=DVec3::new(w.latitude.cos()*w.longitude.sin(),w.latitude.sin(),w.latitude.cos()*w.longitude.cos());
            let east=DVec3::new(w.longitude.cos(),0.,-w.longitude.sin());let north=up.cross(east);
            let center=geo::geodetic_position(w.latitude,w.longitude,w.elevation);
            for row in -2_i32..=2 {for col in -2_i32..=2 {
                let point=center+east*(col as f64*15.)+north*(row as f64*15.);
                samples.push((-1_000_000.+(row*row+col*col) as f64,(point/SEMI_MAJOR_M).as_vec3()));
            }}
        }
        for row in 0..rows {
            for column in 0..columns {
                let cursor = DVec2::new(
                    (column as f64 + 0.5) / columns as f64 * self.viewport.width as f64,
                    (row as f64 + 0.5) / rows as f64 * self.viewport.height as f64,
                );
                if let Some(point) = self.pick_surface(cursor) {
                    let center_distance = (cursor
                        - DVec2::new(
                            self.viewport.width as f64 * 0.5,
                            self.viewport.height as f64 * 0.5,
                        ))
                    .length_squared();
                    samples.push((
                        center_distance,
                        Vec3::new(
                            (point.x / SEMI_MAJOR_M) as f32,
                            (point.y / SEMI_MAJOR_M) as f32,
                            (point.z / SEMI_MAJOR_M) as f32,
                        ),
                    ));
                }
            }
        }
        samples.sort_by(|a, b| a.0.total_cmp(&b.0));
        samples.into_iter().map(|(_, point)| point).collect()
    }

    pub(crate) fn view_projection(&self) -> Mat4 {
        let orientation = self.view_orientation(self.orientation);
        let orientation = Quat::from_xyzw(
            orientation.x as f32,
            orientation.y as f32,
            orientation.z as f32,
            orientation.w as f32,
        )
        .normalize();
        let forward = orientation * -Vec3::Z;
        let up = orientation * Vec3::Y;
        let view_matrix = view::look_at_mat4(Vec3::ZERO, forward, up);
        let aspect = self.viewport.width.max(1) as f32 / self.viewport.height.max(1) as f32;
        let near = (self.near_plane_m() / SEMI_MAJOR_M) as f32;
        let projection = directx::perspective(FIELD_OF_VIEW, aspect, near, 100.0);
        projection * view_matrix
    }

    fn near_plane_m(&self) -> f64 {
        // Ellipsoid height can be kilometres while the eye is metres above a
        // mountain. Basing the near plane on it cuts away the foreground DEM.
        (self.eye_clearance_m() * 0.1).clamp(0.5, 63_781.37)
    }

    fn pick_surface(&self, cursor: DVec2) -> Option<DVec3> {
        self.pick_surface_with_pose(cursor, self.orientation, self.distance_m, None)
    }

    fn pick_surface_terrain(&self, cursor: DVec2, terrain: &TerrainLayer) -> Option<DVec3> {
        self.pick_surface_with_pose(cursor, self.orientation, self.distance_m, Some(terrain))
    }

    fn pick_surface_with_pose(
        &self,
        cursor: DVec2,
        orientation: DQuat,
        distance_m: f64,
        terrain: Option<&TerrainLayer>,
    ) -> Option<DVec3> {
        let direction = self.screen_ray_direction(cursor, orientation)?;
        let eye = orientation * DVec3::Z * distance_m;
        let ellipsoid_hit = geo::ray_ellipsoid_intersection(eye, direction)?;
        let Some(terrain) = terrain else {
            return Some(ellipsoid_hit);
        };
        let (lat, lon) = geo::geodetic_lat_lon(ellipsoid_hit);
        if terrain.sample(lat, lon) <= 0.0 {
            return Some(ellipsoid_hit);
        }
        let outer = geo::ray_expanded_ellipsoid_intersection(eye, direction, 9_000.0);
        let mut near = if let Some(outer) = outer {
            ((outer - eye).dot(direction)).min((ellipsoid_hit - eye).dot(direction))
        } else {
            0.0
        };
        if near < 0.0 || geo::geodetic_height(eye, geo::geodetic_lat_lon(eye).0) < 9_000.0 {
            near = 0.0;
        }
        let mut far = (ellipsoid_hit - eye).dot(direction);
        for _ in 0..20 {
            let mid = (near + far) * 0.5;
            let point = eye + direction * mid;
            let (lat, lon) = geo::geodetic_lat_lon(point);
            if geo::geodetic_height(point, lat) > terrain.sample(lat, lon) {
                near = mid;
            } else {
                far = mid;
            }
        }
        Some(eye + direction * far)
    }

    fn screen_ray_direction(&self, cursor: DVec2, orientation: DQuat) -> Option<DVec3> {
        if self.viewport.width == 0 || self.viewport.height == 0 {
            return None;
        }
        let aspect = self.viewport.width as f64 / self.viewport.height as f64;
        let half_height = (FIELD_OF_VIEW as f64 * 0.5).tan();
        let x = (cursor.x / self.viewport.width as f64 * 2.0 - 1.0) * aspect * half_height;
        let y = (1.0 - cursor.y / self.viewport.height as f64 * 2.0) * half_height;
        Some(self.view_orientation(orientation) * DVec3::new(x, y, -1.0).normalize())
    }
}

fn physical_position(position: PhysicalPosition<f64>) -> DVec2 {
    DVec2::new(position.x, position.y)
}

fn surface_radius(orientation: DQuat) -> f64 {
    geo::radial_surface_radius(orientation * DVec3::Z)
}

fn home_orientation() -> DQuat {
    north_up_orientation(34.3416_f64.to_radians(), 108.9398_f64.to_radians())
}

fn smoothstep(value: f64) -> f64 {
    let t = value.clamp(0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}

fn north_up_orientation(latitude: f64, longitude: f64) -> DQuat {
    let outward = geo::geodetic_position(latitude, longitude, 0.0).normalize();
    let east = DVec3::new(longitude.cos(), 0.0, -longitude.sin());
    let north = outward.cross(east).normalize();
    DQuat::from_mat3(&DMat3::from_cols(east, north, outward)).normalize()
}

fn zoom_key_amount(key: PhysicalKey) -> Option<f64> {
    match key {
        PhysicalKey::Code(KeyCode::Equal | KeyCode::NumpadAdd) => Some(1.0),
        PhysicalKey::Code(KeyCode::Minus | KeyCode::NumpadSubtract) => Some(-1.0),
        _ => None,
    }
}

fn pan_key_binding(key: PhysicalKey) -> Option<(usize, u8)> {
    match key {
        PhysicalKey::Code(KeyCode::ArrowUp) => Some((0, 1)),
        PhysicalKey::Code(KeyCode::ArrowLeft) => Some((1, 1)),
        PhysicalKey::Code(KeyCode::ArrowDown) => Some((2, 1)),
        PhysicalKey::Code(KeyCode::ArrowRight) => Some((3, 1)),
        PhysicalKey::Code(KeyCode::KeyW) => Some((0, 2)),
        PhysicalKey::Code(KeyCode::KeyS) => Some((2, 2)),
        _ => None,
    }
}

fn tilt_key_index(key: PhysicalKey) -> Option<usize> {
    match key {
        PhysicalKey::Code(KeyCode::KeyQ) => Some(0),
        PhysicalKey::Code(KeyCode::KeyE) => Some(1),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn projected_cursor(camera: &OrbitCamera, point: DVec3) -> DVec2 {
        let relative = (point - camera.eye_m()) / SEMI_MAJOR_M;
        let clip = camera.view_projection()
            * Vec4::new(relative.x as f32, relative.y as f32, relative.z as f32, 1.0);
        assert!(clip.w > 0.0);
        let ndc = clip.truncate() / clip.w;
        DVec2::new(
            (ndc.x as f64 + 1.0) * camera.viewport.width as f64 * 0.5,
            (1.0 - ndc.y as f64) * camera.viewport.height as f64 * 0.5,
        )
    }

    #[test]
    fn keyboard_bindings_match_navigation_controls() {
        let key = |code| PhysicalKey::Code(code);
        assert_eq!(
            pan_key_binding(key(KeyCode::KeyW)),
            pan_key_binding(key(KeyCode::ArrowUp)).map(|(index, _)| (index, 2))
        );
        assert_eq!(
            pan_key_binding(key(KeyCode::KeyS)),
            pan_key_binding(key(KeyCode::ArrowDown)).map(|(index, _)| (index, 2))
        );
        assert_eq!(tilt_key_index(key(KeyCode::KeyQ)), Some(0));
        assert_eq!(tilt_key_index(key(KeyCode::KeyE)), Some(1));
        assert_eq!(zoom_key_amount(key(KeyCode::KeyQ)), None);
        assert_eq!(zoom_key_amount(key(KeyCode::KeyE)), None);
        assert_eq!(zoom_key_amount(key(KeyCode::Equal)), Some(1.0));
        assert_eq!(zoom_key_amount(key(KeyCode::Minus)), Some(-1.0));
    }

    #[test]
    fn ray_hits_near_side_of_globe() {
        let hit =
            geo::ray_ellipsoid_intersection(DVec3::new(0.0, 0.0, 3.0 * SEMI_MAJOR_M), -DVec3::Z)
                .unwrap();
        assert!((hit - DVec3::Z * SEMI_MAJOR_M).length() < 1e-5);
    }

    #[test]
    fn ray_misses_globe() {
        assert!(
            geo::ray_ellipsoid_intersection(DVec3::new(0.0, 0.0, 3.0 * SEMI_MAJOR_M), DVec3::X)
                .is_none()
        );
    }

    #[test]
    fn center_of_view_picks_surface() {
        let camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let hit = camera.pick_surface(DVec2::new(720.0, 450.0)).unwrap();
        let eye_direction = (camera.orientation * DVec3::Z).normalize();
        assert!(hit.normalize().dot(eye_direction) > 0.999);
    }

    #[test]
    fn startup_view_is_centred_on_xian() {
        let camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let centre = camera.pick_surface(camera.screen_center()).unwrap();
        let (latitude, longitude) = geo::geodetic_lat_lon(centre);
        assert!((latitude.to_degrees() - 34.3416).abs() < 0.001);
        assert!((longitude.to_degrees() - 108.9398).abs() < 0.001);
        let north_pole = projected_cursor(&camera, DVec3::Y * geo::SEMI_MINOR_M);
        assert!((north_pole.x - 720.0).abs() < 0.1);
        assert!(north_pole.y < 450.0);
        let bearing = camera.compass_bearing_degrees();
        assert!(bearing.min(360.0 - bearing) < 0.001);
    }

    #[test]
    fn home_flight_zooms_out_before_turning_and_reaches_startup_pose() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        let start_orientation = camera.orientation;
        let start_distance = camera.distance_m;
        camera.heading_radians = 70.0_f64.to_radians();
        camera.fly_home();
        for _ in 0..3 {
            camera.update(0.05);
        }
        assert!(camera.distance_m > start_distance);
        assert!((1.0 - camera.orientation.dot(start_orientation).abs()) < 1e-12);
        for _ in 0..50 {
            camera.update(0.05);
        }
        assert!(camera.home_flight.is_none());
        assert!((camera.distance_m - HOME_DISTANCE_M).abs() < 1e-6);
        assert!((1.0 - camera.orientation.dot(home_orientation()).abs()) < 1e-12);
        assert_eq!(camera.tilt_radians, 0.0);
        assert_eq!(camera.heading_radians, 0.0);
    }

    #[test]
    fn manual_zoom_cancels_home_flight() {
        let terrain = TerrainLayer::new();
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        camera.fly_home();
        camera.input(
            &WindowEvent::MouseWheel {
                device_id: winit::event::DeviceId::dummy(),
                delta: MouseScrollDelta::LineDelta(0.0, 1.0),
                phase: winit::event::TouchPhase::Moved,
            },
            &terrain,
        );
        assert!(camera.home_flight.is_none());
    }

    #[test]
    fn keyboard_pan_moves_the_scene_opposite_the_pressed_direction() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.orientation = DQuat::IDENTITY;
        camera.distance_m = SEMI_MAJOR_M + 1_000.0;
        camera.target_distance_m = camera.distance_m;
        let ground = DVec3::Z * SEMI_MAJOR_M;

        camera.pan_keys[0] = true; // Up: camera moves screen-up.
        camera.update(0.05);
        assert!(projected_cursor(&camera, ground).y > 450.0);

        camera.orientation = DQuat::IDENTITY;
        camera.distance_m = SEMI_MAJOR_M + 1_000.0;
        camera.target_distance_m = camera.distance_m;
        camera.pan_keys = [false, false, false, true]; // Right: camera moves screen-right.
        camera.update(0.05);
        assert!(projected_cursor(&camera, ground).x < 720.0);
    }

    #[test]
    fn keyboard_pan_stops_after_focus_is_lost() {
        let terrain = TerrainLayer::new();
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.pan_keys = [true, true, false, false];
        camera.input(&WindowEvent::Focused(false), &terrain);
        let original_orientation = camera.orientation;
        camera.update(0.05);
        assert_eq!(camera.pan_keys, [false; 4]);
        assert_eq!(camera.orientation, original_orientation);
    }

    #[test]
    fn left_globe_drag_sets_and_clears_grabbing_state() {
        let terrain = TerrainLayer::new();
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.cursor = Some(camera.screen_center());
        let press = WindowEvent::MouseInput {
            device_id: winit::event::DeviceId::dummy(),
            state: ElementState::Pressed,
            button: MouseButton::Left,
        };
        let release = WindowEvent::MouseInput {
            device_id: winit::event::DeviceId::dummy(),
            state: ElementState::Released,
            button: MouseButton::Left,
        };
        camera.input(&press, &terrain);
        assert!(camera.is_grabbing_globe());
        camera.input(&release, &terrain);
        assert!(!camera.is_grabbing_globe());
        camera.input(&press, &terrain);
        camera.input(&WindowEvent::Focused(false), &terrain);
        assert!(!camera.is_grabbing_globe());
    }

    #[test]
    fn keyboard_pan_follows_the_screen_when_tilted_and_rotated() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.orientation = DQuat::IDENTITY;
        camera.distance_m = SEMI_MAJOR_M + 100_000.0;
        camera.target_distance_m = camera.distance_m;
        camera.tilt_radians = 35.0_f64.to_radians();
        camera.heading_radians = 50.0_f64.to_radians();
        let pivot = camera.pick_surface(camera.screen_center()).unwrap();
        camera.pan_keys[0] = true;
        camera.update(0.05);
        let moved = projected_cursor(&camera, pivot);
        assert!(
            moved.y > 450.0,
            "Up should move the terrain down: {moved:?}"
        );
    }

    #[test]
    fn near_plane_uses_ground_clearance_in_mountains() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.orientation = DQuat::IDENTITY;
        camera.distance_m = SEMI_MAJOR_M + 1_500.0;
        camera.ground_elevation_m = 1_480.0;
        assert!((camera.eye_height_m() - 1_500.0).abs() < 1e-6);
        assert!((camera.eye_clearance_m() - 20.0).abs() < 1e-6);
        assert!((camera.near_plane_m() - 2.0).abs() < 1e-6);
    }

    #[test]
    fn ground_scale_shrinks_as_camera_approaches_surface() {
        let terrain = TerrainLayer::new();
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let far = camera.ground_metres_per_pixel(&terrain).unwrap();
        let far_height = camera.eye_height_m();
        camera.distance_m = surface_radius(camera.orientation) + 1_000.0;
        let near = camera.ground_metres_per_pixel(&terrain).unwrap();
        assert!(near > 0.0 && near < far);
        assert!(camera.eye_height_m() < far_height);
    }

    #[test]
    fn one_wheel_step_does_not_skip_lod_levels() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.distance_m = 1.1 * SEMI_MAJOR_M;
        camera.target_distance_m = 1.1 * SEMI_MAJOR_M;
        let before = camera.target_tile_level();
        camera.apply_zoom(1.0);
        for _ in 0..60 {
            camera.update(1.0 / 60.0);
        }
        let after = camera.target_tile_level();
        assert!(after <= before + 1, "LOD jumped from z{before} to z{after}");
        assert!(camera.target_distance_m > 1.05 * SEMI_MAJOR_M);
    }

    #[test]
    fn administrative_scale_does_not_change_with_latitude_at_fixed_height() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let height = 50_000.0;
        camera.orientation = north_up_orientation(20.0_f64.to_radians(), 110.0_f64.to_radians());
        camera.distance_m = surface_radius(camera.orientation) + height;
        let first = camera.administration_zoom_scale();
        camera.orientation = north_up_orientation(50.0_f64.to_radians(), 110.0_f64.to_radians());
        camera.distance_m = surface_radius(camera.orientation) + height;
        assert!((camera.administration_zoom_scale() - first).abs() < 1e-12);
    }

    #[test]
    fn wheel_zoom_keeps_the_ground_under_the_cursor() {
        let terrain = TerrainLayer::new();
        for (terrain_view, wheel_amount) in
            [(false, 1.0_f32), (false, -1.0), (true, 1.0), (true, -1.0)]
        {
            let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
            if terrain_view {
                camera.focus_terrain_pilot();
            }
            let cursor = if terrain_view {
                DVec2::new(820.0, 420.0)
            } else {
                DVec2::new(900.0, 390.0)
            };
            let anchor = camera.pick_surface_terrain(cursor, &terrain).unwrap();
            camera.cursor = Some(cursor);
            camera.input(
                &WindowEvent::MouseWheel {
                    device_id: winit::event::DeviceId::dummy(),
                    delta: MouseScrollDelta::LineDelta(0.0, wheel_amount),
                    phase: winit::event::TouchPhase::Moved,
                },
                &terrain,
            );
            for _ in 0..90 {
                camera.update(1.0 / 60.0);
                let actual = projected_cursor(&camera, anchor);
                assert!(
                    actual.distance(cursor) < 0.5,
                    "terrain view {terrain_view}, wheel {wheel_amount}: anchor moved {} px",
                    actual.distance(cursor)
                );
            }
        }
    }

    #[test]
    fn repeated_wheel_input_reanchors_at_the_new_cursor() {
        let terrain = TerrainLayer::new();
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        camera.cursor = Some(DVec2::new(800.0, 420.0));
        camera.apply_zoom_at_cursor(1.0, &terrain);
        for _ in 0..12 {
            camera.update(1.0 / 60.0);
        }
        let next_cursor = DVec2::new(680.0, 500.0);
        let next_anchor = camera.pick_surface_terrain(next_cursor, &terrain).unwrap();
        camera.cursor = Some(next_cursor);
        camera.apply_zoom_at_cursor(1.0, &terrain);
        for _ in 0..90 {
            camera.update(1.0 / 60.0);
            assert!(projected_cursor(&camera, next_anchor).distance(next_cursor) < 0.5);
        }
    }

    #[test]
    fn close_wheel_zoom_preserves_cursor_anchor() {
        let terrain = TerrainLayer::new();
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        camera.distance_m = surface_radius(camera.orientation) + 1_000.0;
        camera.target_distance_m = camera.distance_m;
        let cursor = DVec2::new(775.0, 425.0);
        let anchor = camera.pick_surface_terrain(cursor, &terrain).unwrap();
        camera.cursor = Some(cursor);
        camera.apply_zoom_at_cursor(1.0, &terrain);
        for _ in 0..90 {
            camera.update(1.0 / 60.0);
            assert!(projected_cursor(&camera, anchor).distance(cursor) < 0.5);
        }
    }

    #[test]
    fn wheel_over_space_keeps_the_globe_orientation() {
        let terrain = TerrainLayer::new();
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.cursor = Some(DVec2::new(10.0, 10.0));
        let orientation = camera.orientation;
        let distance = camera.distance_m;
        camera.apply_zoom_at_cursor(1.0, &terrain);
        assert!(camera.zoom_anchor.is_none());
        for _ in 0..30 {
            camera.update(1.0 / 60.0);
        }
        assert!((1.0 - camera.orientation.dot(orientation).abs()) < 1e-12);
        assert!(camera.distance_m < distance);
    }

    #[test]
    fn closest_camera_stays_above_wgs84_surface() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.target_distance_m = 1.001 * SEMI_MAJOR_M;
        for _ in 0..100 {
            camera.apply_zoom(1.0);
        }
        assert!(camera.target_distance_m >= surface_radius(camera.orientation) + MIN_ALTITUDE_M);
        camera.distance_m = camera.target_distance_m;
        assert_eq!(camera.target_tile_level(), 19);
    }

    #[test]
    fn short_drag_at_z18_changes_orientation() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.distance_m = SEMI_MAJOR_M + 100.0;
        let center = DVec2::new(720.0, 450.0);
        let anchor = camera.pick_surface(center).unwrap();
        let moved = camera.pick_surface(center + DVec2::new(2.0, 0.0)).unwrap();
        let turn = DQuat::from_rotation_arc(anchor.normalize(), moved.normalize());
        assert!((turn.x.abs() + turn.y.abs() + turn.z.abs()) > 1e-8);
    }

    #[test]
    fn close_view_requests_source_resolution_near_screen_resolution() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.distance_m = surface_radius(camera.orientation) + 1_000.0;
        assert!(camera.target_tile_level() >= 17);
    }

    #[test]
    fn terrain_demo_looks_at_sichuan_with_oblique_view() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        let center = camera.pick_surface(DVec2::new(720.0, 450.0)).unwrap();
        let (latitude, longitude) = geo::geodetic_lat_lon(center);
        assert!((29.0..=33.0).contains(&latitude.to_degrees()));
        assert!((100.0..=105.0).contains(&longitude.to_degrees()));
        assert!(camera.tilt_radians > 0.0);
        assert!(camera.target_tile_level() >= 12);
    }

    #[test]
    fn navigation_controls_preserve_screen_center_and_set_angles() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        let terrain = TerrainLayer::new();
        let center = camera.screen_center();
        let anchor = camera.pick_surface_terrain(center, &terrain).unwrap();

        assert!(camera.set_tilt_degrees(25.0, &terrain));
        assert!((camera.view_angles_degrees().0 - 25.0).abs() < 0.05);
        assert!(camera.set_compass_bearing_degrees(90.0, &terrain));
        let delta = (camera.compass_bearing_degrees() - 90.0 + 180.0).rem_euclid(360.0) - 180.0;
        assert!(delta.abs() < 0.5, "bearing offset {delta}");
        let moved = camera.pick_surface_terrain(center, &terrain).unwrap();
        assert!(
            anchor.distance(moved) < 20.0,
            "center moved {} m",
            anchor.distance(moved)
        );
    }

    #[test]
    fn keyboard_tilt_eases_to_target_and_keeps_center_fixed() {
        let terrain = TerrainLayer::new();
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        let center = camera.screen_center();
        let anchor = camera.pick_surface_terrain(center, &terrain).unwrap();
        let initial = camera.view_angles_degrees().0;
        camera.queue_keyboard_tilt(3.0, &terrain);
        assert!((camera.view_angles_degrees().0 - initial).abs() < 1e-6);
        camera.update_keyboard_tilt(1.0 / 60.0, &terrain);
        let first = camera.view_angles_degrees().0;
        assert!(first > initial && first < initial + 3.0);
        for _ in 0..60 {
            camera.update_keyboard_tilt(1.0 / 60.0, &terrain);
        }
        assert!((camera.view_angles_degrees().0 - initial - 3.0).abs() < 0.03);
        assert!(camera.keyboard_tilt_target.is_none());
        let moved = camera.pick_surface_terrain(center, &terrain).unwrap();
        assert!(anchor.distance(moved) < 20.0);

        camera.queue_keyboard_tilt(-3.0, &terrain);
        camera.set_tilt_degrees(10.0, &terrain);
        assert!(camera.keyboard_tilt_target.is_none());
    }

    #[test]
    fn held_tilt_and_rotation_keys_preserve_the_screen_centre() {
        let terrain = TerrainLayer::new();
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        let centre = camera.screen_center();
        let anchor = camera.pick_surface_terrain(centre, &terrain).unwrap();
        let initial_tilt = camera.view_angles_degrees().0;
        camera.tilt_keys[0] = true;
        camera.update_keyboard_tilt(1.0 / 60.0, &terrain);
        assert!(camera.view_angles_degrees().0 > initial_tilt);
        camera.tilt_keys = [false; 2];
        let initial_bearing = camera.compass_bearing_degrees();
        camera.rotation_keys[1] = true;
        camera.update_keyboard_rotation(1.0 / 60.0, &terrain);
        assert!(camera.compass_bearing_degrees() > initial_bearing);
        let moved = camera.pick_surface_terrain(centre, &terrain).unwrap();
        assert!(anchor.distance(moved) < 20.0);
    }

    #[test]
    fn distant_view_tilt_slider_uses_its_full_width() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let terrain = TerrainLayer::new();
        let maximum = camera.maximum_tilt_degrees(&terrain);
        assert!((15.0..25.0).contains(&maximum));
        assert!(camera.set_tilt_degrees(maximum, &terrain));
        let actual = camera.view_angles_degrees().0;
        assert!((actual - maximum).abs() < 0.01);
        assert!((actual / maximum - 1.0).abs() < 0.001);
    }

    #[test]
    fn middle_drag_keeps_clicked_surface_point_under_marker() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        let terrain = TerrainLayer::new();
        assert!(camera.rotation_marker_position().is_none());
        let start = DVec2::new(620.0, 480.0);
        let anchor = camera.pick_surface_terrain(start, &terrain).unwrap();
        camera.cursor = Some(start);
        camera.input(
            &WindowEvent::MouseInput {
                device_id: winit::event::DeviceId::dummy(),
                state: ElementState::Pressed,
                button: MouseButton::Middle,
            },
            &terrain,
        );
        assert!(
            camera
                .middle_drag_start
                .unwrap()
                .pivot
                .unwrap()
                .distance(anchor)
                < 1e-5
        );
        let marker = camera.rotation_marker_position().unwrap();
        assert!((marker - start.as_vec2()).length() < 1.0);
        camera.move_middle_drag(start + DVec2::new(100.0, 50.0));
        let marker = camera.rotation_marker_position().unwrap();
        assert!((marker - start.as_vec2()).length() < 1.0);
        let after = geo::ray_sphere_intersection(
            camera.eye_m(),
            camera
                .screen_ray_direction(start, camera.orientation)
                .unwrap(),
            anchor.length(),
        )
        .unwrap();
        assert!((camera.tilt_radians.to_degrees() - 23.54).abs() < 0.02);
        assert!((camera.heading_radians.to_degrees() - (360.0 - 22.92)).abs() < 0.02);
        assert!(
            anchor.distance(after) < 1e-4,
            "clicked anchor shifted by {} m",
            anchor.distance(after)
        );
        let orientation = camera.orientation;
        camera.move_middle_drag(start + DVec2::new(100.0, 50.0));
        assert!((1.0 - camera.orientation.dot(orientation).abs()) < 1e-12);
        camera.input(
            &WindowEvent::MouseInput {
                device_id: winit::event::DeviceId::dummy(),
                state: ElementState::Released,
                button: MouseButton::Middle,
            },
            &terrain,
        );
        assert!(camera.rotation_marker_position().is_none());
    }

    #[test]
    fn right_drag_rotates_and_zooms_around_clicked_surface_point() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        let terrain = TerrainLayer::new();
        let click = DVec2::new(620.0, 480.0);
        let anchor = camera.pick_surface_terrain(click, &terrain).unwrap();
        let initial_altitude = camera.distance_m - surface_radius(camera.orientation);
        camera.cursor = Some(click);
        camera.input(
            &WindowEvent::MouseInput {
                device_id: winit::event::DeviceId::dummy(),
                state: ElementState::Pressed,
                button: MouseButton::Right,
            },
            &terrain,
        );
        assert!(camera.is_orbit_dragging());
        assert!(
            camera
                .right_drag_start
                .unwrap()
                .pivot
                .unwrap()
                .distance(anchor)
                < 1e-5
        );
        camera.move_right_drag(click + DVec2::new(100.0, -70.0));
        let marker = camera.rotation_marker_position().unwrap();
        assert!((marker - click.as_vec2()).length() < 1.0);
        assert!((camera.heading_radians.to_degrees() - (360.0 - 22.92)).abs() < 0.02);
        assert!((camera.tilt_radians.to_degrees() - 35.0).abs() < 0.02);
        let new_altitude = camera.distance_m - surface_radius(camera.orientation);
        assert!(new_altitude < initial_altitude);
        assert!((new_altitude / initial_altitude - (-0.35_f64).exp()).abs() < 0.01);
        let after = geo::ray_sphere_intersection(
            camera.eye_m(),
            camera
                .screen_ray_direction(click, camera.orientation)
                .unwrap(),
            anchor.length(),
        )
        .unwrap();
        assert!(anchor.distance(after) < 1e-3);
        let orientation = camera.orientation;
        let distance = camera.distance_m;
        camera.move_right_drag(click + DVec2::new(100.0, -70.0));
        assert!((1.0 - camera.orientation.dot(orientation).abs()) < 1e-12);
        assert!((camera.distance_m - distance).abs() < 1e-6);
        camera.input(
            &WindowEvent::MouseInput {
                device_id: winit::event::DeviceId::dummy(),
                state: ElementState::Released,
                button: MouseButton::Right,
            },
            &terrain,
        );
        assert!(!camera.is_orbit_dragging());
        assert!(camera.rotation_marker_position().is_none());
        camera.update(0.016);
        assert!((camera.distance_m - distance).abs() < 1e-6);
    }

    #[test]
    fn patrol_orbits_around_the_current_screen_center() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let terrain = TerrainLayer::new();
        let original_orientation = camera.orientation;
        let original_distance = camera.distance_m;
        assert!(camera.toggle_patrol(&terrain));
        assert!(camera.tilt_radians > 0.0);
        for _ in 0..120 {
            camera.update(1.0 / 60.0);
            let marker = camera.rotation_marker_position().unwrap();
            assert!((marker - Vec2::new(720.0, 450.0)).length() < 1.0);
        }
        assert!((1.0 - camera.orientation.dot(original_orientation).abs()) > 1e-6);
        assert!((camera.distance_m - original_distance).abs() < 1e-6);
        assert!(!camera.toggle_patrol(&terrain));
        assert!(camera.rotation_marker_position().is_none());
    }

    #[test]
    fn manual_navigation_stops_patrol() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let terrain = TerrainLayer::new();
        camera.focus_terrain_pilot();
        assert!(camera.toggle_patrol(&terrain));
        camera.input(
            &WindowEvent::MouseWheel {
                device_id: winit::event::DeviceId::dummy(),
                delta: MouseScrollDelta::LineDelta(0.0, 1.0),
                phase: winit::event::TouchPhase::Moved,
            },
            &terrain,
        );
        assert!(!camera.is_patrolling());
    }
}

include!("keeper_camera.rs");

#[cfg(test)]
mod view_toggle_tests {
    use super::*;
    #[test]
    fn toggle_preserves_anchor_and_returns_to_nadir() {
        let terrain=TerrainLayer::new();
        let mut camera=OrbitCamera::new(winit::dpi::PhysicalSize::new(800,600));
        camera.keeper_set_view(&serde_json::json!({"longitude":111.6452,"latitude":32.7489,"height":500.,"heading":30.,"tilt":0.})).unwrap();
        let center=DVec2::new(400.,300.);
        let anchor=camera.pick_surface_terrain(center,&terrain).unwrap();
        assert!(camera.toggle_view_tilt(&terrain));
        assert!((camera.tilt_radians.to_degrees()-45.).abs()<1e-6);
        assert!(anchor.distance(camera.pick_surface_terrain(center,&terrain).unwrap())<0.1);
        assert!(camera.toggle_view_tilt(&terrain));
        assert!(camera.tilt_radians.abs()<1e-6);
        assert!(anchor.distance(camera.pick_surface_terrain(center,&terrain).unwrap())<0.1);
        assert!((camera.heading_radians.to_degrees()-30.).abs()<1e-6);
    }
}

include!("walk_camera.rs");
