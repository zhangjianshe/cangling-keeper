//! Ground-mode sky, drawn behind native geometry without DOM overlays.
use wgpu::util::DeviceExt;
#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct Uniform { inverse_view: [[f32;4];4], up: [f32;4] }
pub struct Sky { pipeline:wgpu::RenderPipeline, uniform:wgpu::Buffer, group:wgpu::BindGroup }
impl Sky {
    pub fn new(device:&wgpu::Device,format:wgpu::TextureFormat)->Self {
        let uniform=device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label:Some("sky uniform"),contents:bytemuck::bytes_of(&Uniform{inverse_view:glam::Mat4::IDENTITY.to_cols_array_2d(),up:[0.,1.,0.,0.]}),
            usage:wgpu::BufferUsages::UNIFORM|wgpu::BufferUsages::COPY_DST,
        });
        let bindings=device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor{label:Some("sky bindings"),entries:&[wgpu::BindGroupLayoutEntry{
            binding:0,visibility:wgpu::ShaderStages::VERTEX_FRAGMENT,ty:wgpu::BindingType::Buffer{ty:wgpu::BufferBindingType::Uniform,has_dynamic_offset:false,min_binding_size:None},count:None,
        }]});
        let group=device.create_bind_group(&wgpu::BindGroupDescriptor{label:Some("sky"),layout:&bindings,entries:&[wgpu::BindGroupEntry{binding:0,resource:uniform.as_entire_binding()}]});
        let shader=device.create_shader_module(wgpu::ShaderModuleDescriptor{label:Some("ground sky"),source:wgpu::ShaderSource::Wgsl(include_str!("sky.wgsl").into())});
        let layout=device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor{label:Some("sky layout"),bind_group_layouts:&[Some(&bindings)],immediate_size:0});
        let pipeline=device.create_render_pipeline(&wgpu::RenderPipelineDescriptor{
            label:Some("ground sky"),layout:Some(&layout),
            vertex:wgpu::VertexState{module:&shader,entry_point:Some("vs_main"),buffers:&[],compilation_options:Default::default()},
            fragment:Some(wgpu::FragmentState{module:&shader,entry_point:Some("fs_main"),targets:&[Some(wgpu::ColorTargetState{format,blend:None,write_mask:wgpu::ColorWrites::ALL})],compilation_options:Default::default()}),
            primitive:Default::default(),depth_stencil:Some(wgpu::DepthStencilState{format:wgpu::TextureFormat::Depth32Float,depth_write_enabled:Some(false),depth_compare:Some(wgpu::CompareFunction::Always),stencil:Default::default(),bias:Default::default()}),
            multisample:Default::default(),multiview_mask:None,cache:None,
        });
        Self{pipeline,uniform,group}
    }
    pub fn update(&self,queue:&wgpu::Queue,camera:&crate::camera::OrbitCamera){
        let eye=camera.eye_m();let (lat,lon)=crate::geo::geodetic_lat_lon(eye);
        let up=[(lat.cos()*lon.sin()) as f32,lat.sin() as f32,(lat.cos()*lon.cos()) as f32,0.];
        queue.write_buffer(&self.uniform,0,bytemuck::bytes_of(&Uniform{inverse_view:camera.view_projection().inverse().to_cols_array_2d(),up}));
    }
    pub fn draw<'a>(&'a self,pass:&mut wgpu::RenderPass<'a>){pass.set_pipeline(&self.pipeline);pass.set_bind_group(0,&self.group,&[]);pass.draw(0..3,0..1);}
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn sky_shader_validates() {
        let module=naga::front::wgsl::parse_str(include_str!("sky.wgsl")).unwrap();
        naga::valid::Validator::new(naga::valid::ValidationFlags::all(),naga::valid::Capabilities::all()).validate(&module).unwrap();
    }
    #[test]
    fn sky_pipeline_passes_device_validation() {
        let instance=wgpu::Instance::default();
        let Ok(adapter)=pollster::block_on(instance.request_adapter(&Default::default())) else{return;};
        let (device,queue)=pollster::block_on(adapter.request_device(&Default::default())).unwrap();
        let scope=device.push_error_scope(wgpu::ErrorFilter::Validation);
        let sky=Sky::new(&device,wgpu::TextureFormat::Rgba8UnormSrgb);
        sky.update(&queue,&crate::camera::OrbitCamera::new(winit::dpi::PhysicalSize::new(800,600)));
        assert!(pollster::block_on(scope.pop()).is_none());
    }
}
