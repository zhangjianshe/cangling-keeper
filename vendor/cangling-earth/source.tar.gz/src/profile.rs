//! Sparse GPU timestamps avoid a readback stall in the render loop.

use crossbeam_channel::{Receiver, Sender, unbounded};

struct Slot {
    queries: wgpu::QuerySet,
    resolve: wgpu::Buffer,
    readback: wgpu::Buffer,
    busy: bool,
}

#[derive(Clone, Copy, Default)]
pub struct GpuTimes {
    pub imagery_ms: f32,
    pub hud_ms: f32,
    pub available: bool,
}

pub struct GpuProfiler {
    slots: Vec<Slot>,
    sender: Sender<(usize, bool)>,
    receiver: Receiver<(usize, bool)>,
    frame: u64,
    times: GpuTimes,
}

impl GpuProfiler {
    pub fn new(device: &wgpu::Device) -> Self {
        let (sender, receiver) = unbounded();
        let mut slots = Vec::new();
        if device.features().contains(wgpu::Features::TIMESTAMP_QUERY) {
            for index in 0..3 {
                let queries = device.create_query_set(&wgpu::QuerySetDescriptor {
                    label: Some("frame GPU timestamps"),
                    ty: wgpu::QueryType::Timestamp,
                    count: 4,
                });
                let resolve = device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("timestamp resolve"),
                    size: 32,
                    usage: wgpu::BufferUsages::QUERY_RESOLVE | wgpu::BufferUsages::COPY_SRC,
                    mapped_at_creation: false,
                });
                let readback = device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("timestamp readback"),
                    size: 32,
                    usage: wgpu::BufferUsages::MAP_READ | wgpu::BufferUsages::COPY_DST,
                    mapped_at_creation: false,
                });
                log::debug!("created GPU timestamp slot {index}");
                slots.push(Slot {
                    queries,
                    resolve,
                    readback,
                    busy: false,
                });
            }
        }
        Self {
            slots,
            sender,
            receiver,
            frame: 0,
            times: GpuTimes::default(),
        }
    }

    pub fn poll(&mut self, device: &wgpu::Device, timestamp_period_ns: f32) {
        if self.slots.iter().any(|slot| slot.busy) {
            let _ = device.poll(wgpu::PollType::Poll);
        }
        while let Ok((index, success)) = self.receiver.try_recv() {
            let slot = &mut self.slots[index];
            if success {
                if let Ok(mapped) = slot.readback.slice(..).get_mapped_range() {
                    let values: Vec<u64> = mapped
                        .chunks_exact(8)
                        .map(|chunk| u64::from_le_bytes(chunk.try_into().expect("u64 timestamp")))
                        .collect();
                    if values.len() == 4 && values[1] >= values[0] && values[3] >= values[2] {
                        self.times = GpuTimes {
                            imagery_ms: (values[1] - values[0]) as f32 * timestamp_period_ns / 1e6,
                            hud_ms: (values[3] - values[2]) as f32 * timestamp_period_ns / 1e6,
                            available: true,
                        };
                    }
                    drop(mapped);
                }
                slot.readback.unmap();
            }
            slot.busy = false;
        }
    }

    pub fn begin_sample(&mut self) -> Option<usize> {
        self.frame = self.frame.wrapping_add(1);
        if !self.frame.is_multiple_of(30) {
            return None;
        }
        let index = self.slots.iter().position(|slot| !slot.busy)?;
        self.slots[index].busy = true;
        Some(index)
    }

    pub fn pass_writes(
        &self,
        index: usize,
        begin: u32,
        end: u32,
    ) -> wgpu::RenderPassTimestampWrites<'_> {
        wgpu::RenderPassTimestampWrites {
            query_set: &self.slots[index].queries,
            beginning_of_pass_write_index: Some(begin),
            end_of_pass_write_index: Some(end),
        }
    }

    pub fn resolve(&self, encoder: &mut wgpu::CommandEncoder, index: usize) {
        let slot = &self.slots[index];
        encoder.resolve_query_set(&slot.queries, 0..4, &slot.resolve, 0);
        encoder.copy_buffer_to_buffer(&slot.resolve, 0, &slot.readback, 0, 32);
    }

    pub fn request_readback(&self, index: usize) {
        let sender = self.sender.clone();
        self.slots[index]
            .readback
            .slice(..)
            .map_async(wgpu::MapMode::Read, move |result| {
                let _ = sender.send((index, result.is_ok()));
            });
    }

    pub fn times(&self) -> GpuTimes {
        self.times
    }
}
