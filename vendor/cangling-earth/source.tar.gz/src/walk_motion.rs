//! Bounded terrain sweep for the built-in ground controller (not mesh/building collision).
pub const STEP_HEIGHT:f64=0.45;
const SWEEP_SPACING:f64=0.25;
#[derive(Clone,Copy,Debug,PartialEq)]
pub enum Block {Steep,Missing}
#[derive(Clone,Copy,Debug)]
pub struct Sweep {pub distance:f64,pub height:Option<f64>,pub blocked:Option<Block>}
/// The extra sample beyond an obstacle distinguishes a small flat step from
/// a continuously steep slope. Missing DEM never counts as sea level.
pub fn sweep(distance:f64,foot_height:f64,airborne:bool,mut height:impl FnMut(f64)->Option<f64>)->Sweep {
    let valid=|v:Option<f64>|v.filter(|v|v.is_finite()).map(|v|v.max(0.));
    let Some(mut current)=valid(height(0.)) else{return Sweep{distance:0.,height:None,blocked:Some(Block::Missing)};};
    let mut result=Sweep{distance:0.,height:Some(current),blocked:None};
    if distance<=0. || !distance.is_finite(){return result;}
    // Runtime displacement is at most 40 m/frame; cap arbitrary callers too.
    let distance=distance.min(40.);
    let count=(distance/SWEEP_SPACING).ceil().clamp(1.,160.) as usize;
    let increment=distance/count as f64;
    for index in 1..=count {
        let d=increment*index as f64;
        let Some(next)=valid(height(d)) else{result.blocked=Some(Block::Missing);break;};
        let rise=next-current;
        if rise>increment+1e-5 && !(airborne&&next<=foot_height+0.02) {
            let plateau=valid(height(d+0.5));
            let small_step=rise<=STEP_HEIGHT && plateau.is_some_and(|p|(p-next).abs()<=0.08);
            if !small_step {result.blocked=Some(Block::Steep);break;}
        }
        result.distance=d;result.height=Some(next);current=next;
    }
    result
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]fn flat_slope_and_small_step_are_walkable(){
        assert_eq!(sweep(2.,0.,false,|_|Some(0.)).distance,2.);
        assert_eq!(sweep(2.,0.,false,|d|Some(d*0.8)).distance,2.);
        assert_eq!(sweep(2.,0.,false,|d|Some(if d<0.5{0.}else{0.4})).distance,2.);
    }
    #[test]fn steep_slope_and_high_step_block_even_during_sprint(){
        let slope=sweep(20.,0.,false,|d|Some(d*2.));assert_eq!(slope.blocked,Some(Block::Steep));assert_eq!(slope.distance,0.);
        let wall=sweep(40.,0.,false,|d|Some(if d<3.1{0.}else{2.}));assert_eq!(wall.blocked,Some(Block::Steep));assert!(wall.distance<3.1);
    }
    #[test]fn jumping_clears_low_obstacles_but_not_higher_ground(){
        assert_eq!(sweep(2.,1.2,true,|d|Some(if d<0.5{0.}else{0.8})).distance,2.);
        assert_eq!(sweep(2.,0.6,true,|d|Some(if d<0.5{0.}else{1.5})).blocked,Some(Block::Steep));
    }
    #[test]fn missing_and_invalid_dem_stop_at_last_known_ground(){
        assert_eq!(sweep(1.,100.,false,|_|None).blocked,Some(Block::Missing));
        let missing=sweep(2.,100.,false,|d|if d<0.8{Some(100.)}else{Some(f64::NAN)});
        assert_eq!(missing.blocked,Some(Block::Missing));assert_eq!(missing.height,Some(100.));assert_eq!(missing.distance,0.75);
        assert_eq!(sweep(2.,100.,false,|d|Some(100.-d*4.)).distance,2.);
    }
}
