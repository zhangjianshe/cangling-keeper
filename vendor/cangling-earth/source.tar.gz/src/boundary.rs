//! Terrain-draped administrative boundaries retained in world coordinates.
//! Camera movement updates one uniform; the GPU projects and extrudes the lines.

use std::collections::HashMap;
use std::hash::{Hash, Hasher};

use bytemuck::{Pod, Zeroable};
use glam::{DVec3, Vec4};
use wgpu::util::DeviceExt;

use crate::{camera::OrbitCamera, geo, terrain::TerrainLayer, tile::TileKey};

struct RingSamples {
    segments: Vec<(DVec3, DVec3)>,
    vertices: Vec<WorldLineVertex>,
    bounds: [f64; 4],
}

pub struct BoundaryUpdateStats {
    pub bytes: usize,
    pub resampled: usize,
    pub reused: usize,
    pub skipped: bool,
    pub patched: bool,
}

#[repr(C)]
#[derive(Clone, Copy, PartialEq, Pod, Zeroable)]
struct WorldLineVertex {
    start_high: [f32; 3],
    start_low: [f32; 3],
    end_high: [f32; 3],
    end_low: [f32; 3],
    corner: [f32; 2],
    style: f32,
}

impl WorldLineVertex {
    const ATTRIBUTES: [wgpu::VertexAttribute; 6] = wgpu::vertex_attr_array![
        0 => Float32x3, 1 => Float32x3, 2 => Float32x3,
        3 => Float32x3, 4 => Float32x2, 5 => Float32
    ];

    fn layout() -> wgpu::VertexBufferLayout<'static> {
        wgpu::VertexBufferLayout {
            array_stride: std::mem::size_of::<Self>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &Self::ATTRIBUTES,
        }
    }
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct BoundaryView {
    eye_high: [f32; 4],
    eye_low: [f32; 4],
    viewport: [f32; 4],
}

// Keep draw calls bounded while avoiding vertex work for off-screen paths.
const SEGMENTS_PER_BATCH: usize = 2048;

struct BoundaryBatch {
    first_index: u32,
    index_count: u32,
    center: DVec3,
    radius: f64,
}

struct BatchBuilder {
    first_index: u32,
    segments: usize,
    min: DVec3,
    max: DVec3,
}

impl BatchBuilder {
    fn new(first_index: u32) -> Self {
        Self {
            first_index,
            segments: 0,
            min: DVec3::splat(f64::INFINITY),
            max: DVec3::splat(f64::NEG_INFINITY),
        }
    }

    fn include(&mut self, start: DVec3, end: DVec3) {
        self.min = self.min.min(start).min(end);
        self.max = self.max.max(start).max(end);
        self.segments += 1;
    }

    fn finish(&self) -> Option<BoundaryBatch> {
        if self.segments == 0 {
            return None;
        }
        let center = (self.min + self.max) * 0.5;
        Some(BoundaryBatch {
            first_index: self.first_index,
            index_count: (self.segments * 6) as u32,
            center,
            radius: (self.max - center).length() + 8.0,
        })
    }
}

pub struct BoundaryLayer {
    pipeline: wgpu::RenderPipeline,
    view_buffer: wgpu::Buffer,
    view_bind_group: wgpu::BindGroup,
    vertices: wgpu::Buffer,
    indices: wgpu::Buffer,
    batches: Vec<BoundaryBatch>,
    ring_cache: HashMap<u64, RingSamples>,
    ring_keys: Vec<u64>,
    ring_layout: HashMap<u64, (usize, usize)>,
    previous_vertices: Vec<WorldLineVertex>,
    previous_indices: Vec<u32>,
    far_distance_m: f64,
}

impl BoundaryLayer {
    pub fn invalidate(&mut self) {
        self.ring_keys.clear();
        self.ring_cache.clear();
        self.ring_layout.clear();
        self.batches.clear();
    }

    pub fn new(
        device: &wgpu::Device,
        format: wgpu::TextureFormat,
        camera_layout: &wgpu::BindGroupLayout,
    ) -> Self {
        let view_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("boundary view"),
            contents: bytemuck::bytes_of(&BoundaryView {
                eye_high: [0.0; 4],
                eye_low: [0.0; 4],
                viewport: [1.0, 1.0, 0.0, 0.0],
            }),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let view_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("boundary view layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let view_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("boundary view bind group"),
            layout: &view_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: view_buffer.as_entire_binding(),
            }],
        });
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("world boundary shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("boundary.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("world boundary pipeline layout"),
            bind_group_layouts: &[Some(camera_layout), Some(&view_layout)],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("world-space administrative boundaries"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[Some(WorldLineVertex::layout())],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                cull_mode: None,
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: Some(false),
                depth_compare: Some(wgpu::CompareFunction::LessEqual),
                stencil: Default::default(),
                bias: wgpu::DepthBiasState {
                    constant: -2,
                    slope_scale: -1.0,
                    clamp: 0.0,
                },
            }),
            multisample: Default::default(),
            multiview_mask: None,
            cache: None,
        });
        let vertices = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("world boundary vertices"),
            size: std::mem::size_of::<WorldLineVertex>() as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let indices = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("world boundary indices"),
            size: std::mem::size_of::<u32>() as u64,
            usage: wgpu::BufferUsages::INDEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        Self {
            pipeline,
            view_buffer,
            view_bind_group,
            vertices,
            indices,
            batches: Vec::new(),
            ring_cache: HashMap::new(),
            ring_keys: Vec::new(),
            ring_layout: HashMap::new(),
            previous_vertices: Vec::new(),
            previous_indices: Vec::new(),
            far_distance_m: f64::INFINITY,
        }
    }

    pub fn update_geometry(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        major_rings: &[Vec<[f64; 2]>],
        minor_rings: &[Vec<[f64; 2]>],
        zoom: u8,
        terrain: &TerrainLayer,
        dirty_dem: &[TileKey],
    ) -> BoundaryUpdateStats {
        let dirty_bounds: Vec<_> = dirty_dem.iter().copied().map(tile_bounds).collect();
        let ring_keys: Vec<_> = minor_rings
            .iter()
            .map(|ring| ring_key(ring, zoom, 1.0))
            .chain(major_rings.iter().map(|ring| ring_key(ring, zoom, 2.0)))
            .collect();
        if ring_keys == self.ring_keys
            && !dirty_bounds.iter().any(|&tile| {
                self.ring_cache
                    .values()
                    .any(|samples| bounds_intersect(tile, samples.bounds))
            })
        {
            return BoundaryUpdateStats {
                bytes: 0,
                resampled: 0,
                reused: ring_keys.len(),
                skipped: true,
                patched: false,
            };
        }
        if ring_keys == self.ring_keys {
            if let Some(stats) = self.patch_terrain_rings(
                queue,
                major_rings,
                minor_rings,
                zoom,
                terrain,
                &dirty_bounds,
            ) {
                return stats;
            }
        }
        let mut vertices = Vec::new();
        let mut indices = Vec::new();
        let mut batches = Vec::new();
        let mut batch = BatchBuilder::new(0);
        let mut previous = std::mem::take(&mut self.ring_cache);
        let mut ring_cache = HashMap::new();
        let mut ring_layout = HashMap::new();
        let mut stats = BoundaryUpdateStats {
            bytes: 0,
            resampled: 0,
            reused: 0,
            skipped: false,
            patched: false,
        };
        let max_step = (360.0 / (1_u32 << zoom.min(18)) as f64 / 64.0).clamp(0.0005, 0.2);
        for (rings, style) in [(minor_rings, 1.0), (major_rings, 2.0)] {
            for ring in rings {
                let key = ring_key(ring, zoom, style);
                let cached = previous.remove(&key);
                let bounds = cached
                    .as_ref()
                    .map_or_else(|| geographic_bounds(ring), |item| item.bounds);
                let dirty = dirty_bounds
                    .iter()
                    .any(|&tile| bounds_intersect(tile, bounds));
                let samples = if !dirty {
                    if let Some(cached) = cached {
                        stats.reused += 1;
                        cached
                    } else {
                        stats.resampled += 1;
                        sample_ring(ring, max_step, terrain, bounds, style)
                    }
                } else {
                    stats.resampled += 1;
                    sample_ring(ring, max_step, terrain, bounds, style)
                };
                ring_layout.insert(key, (vertices.len() / 4, samples.segments.len()));
                append_samples(
                    &mut vertices,
                    &mut indices,
                    &mut batches,
                    &mut batch,
                    &samples,
                );
                ring_cache.insert(key, samples);
            }
        }
        self.ring_cache = ring_cache;
        self.ring_keys = ring_keys;
        self.ring_layout = ring_layout;
        if let Some(last) = batch.finish() {
            batches.push(last);
        }
        self.batches = batches;
        if vertices.is_empty() {
            self.previous_vertices.clear();
            self.previous_indices.clear();
            return stats;
        }
        let bytes = bytemuck::cast_slice(&vertices);
        let mut vertex_buffer_replaced = false;
        if bytes.len() as u64 > self.vertices.size() {
            self.vertices = device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("world boundary vertices"),
                size: (bytes.len() as u64).next_power_of_two(),
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
            vertex_buffer_replaced = true;
        }
        stats.bytes += write_changed_chunks(
            queue,
            &self.vertices,
            bytes,
            bytemuck::cast_slice(&self.previous_vertices),
            vertex_buffer_replaced,
        );
        let index_bytes = bytemuck::cast_slice(&indices);
        let mut index_buffer_replaced = false;
        if index_bytes.len() as u64 > self.indices.size() {
            self.indices = device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("world boundary indices"),
                size: (index_bytes.len() as u64).next_power_of_two(),
                usage: wgpu::BufferUsages::INDEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
            index_buffer_replaced = true;
        }
        stats.bytes += write_changed_chunks(
            queue,
            &self.indices,
            index_bytes,
            bytemuck::cast_slice(&self.previous_indices),
            index_buffer_replaced,
        );
        self.previous_vertices = vertices;
        self.previous_indices = indices;
        stats
    }

    fn patch_terrain_rings(
        &mut self,
        queue: &wgpu::Queue,
        major_rings: &[Vec<[f64; 2]>],
        minor_rings: &[Vec<[f64; 2]>],
        zoom: u8,
        terrain: &TerrainLayer,
        dirty_bounds: &[[f64; 4]],
    ) -> Option<BoundaryUpdateStats> {
        let max_step = (360.0 / (1_u32 << zoom.min(18)) as f64 / 64.0).clamp(0.0005, 0.2);
        let mut stats = BoundaryUpdateStats {
            bytes: 0,
            resampled: 0,
            reused: 0,
            skipped: false,
            patched: true,
        };
        let mut changed = Vec::new();
        for (rings, style) in [(minor_rings, 1.0), (major_rings, 2.0)] {
            for ring in rings {
                let key = ring_key(ring, zoom, style);
                let cached = self.ring_cache.get(&key)?;
                let &(first_segment, segment_count) = self.ring_layout.get(&key)?;
                if !dirty_bounds
                    .iter()
                    .any(|&tile| bounds_intersect(tile, cached.bounds))
                {
                    stats.reused += 1;
                    continue;
                }
                let samples = sample_ring(ring, max_step, terrain, cached.bounds, style);
                if samples.segments.len() != segment_count {
                    return None;
                }
                changed.push((key, first_segment, samples));
                stats.resampled += 1;
            }
        }
        let mut uploads = Vec::new();
        for (key, first_segment, samples) in changed {
            let start_vertex = first_segment * 4;
            let end_vertex = start_vertex + samples.vertices.len();
            if self.previous_vertices[start_vertex..end_vertex] != samples.vertices {
                self.previous_vertices[start_vertex..end_vertex].copy_from_slice(&samples.vertices);
                uploads.push((start_vertex, end_vertex));
                for (segment_index, &(start, end)) in samples.segments.iter().enumerate() {
                    let batch =
                        &mut self.batches[(first_segment + segment_index) / SEGMENTS_PER_BATCH];
                    batch.radius = batch
                        .radius
                        .max(start.distance(batch.center) + 8.0)
                        .max(end.distance(batch.center) + 8.0);
                }
            }
            self.ring_cache.insert(key, samples);
        }
        uploads.sort_unstable_by_key(|range| range.0);
        let mut merged: Vec<(usize, usize)> = Vec::new();
        for (start, end) in uploads {
            if let Some(last) = merged.last_mut() {
                if start <= last.1 {
                    last.1 = last.1.max(end);
                    continue;
                }
            }
            merged.push((start, end));
        }
        for (start, end) in merged {
            let bytes = bytemuck::cast_slice(&self.previous_vertices[start..end]);
            queue.write_buffer(
                &self.vertices,
                (start * std::mem::size_of::<WorldLineVertex>()) as u64,
                bytes,
            );
            stats.bytes += bytes.len();
        }
        Some(stats)
    }

    pub fn update_view(
        &mut self,
        queue: &wgpu::Queue,
        camera: &OrbitCamera,
        width: u32,
        height: u32,
        minor_opacity: f32,
        near_distance_m: f64,
    ) {
        self.far_distance_m = near_distance_m.max(1.0) * 5.5;
        let (eye_high, eye_low) = split_position(camera.eye_m());
        queue.write_buffer(
            &self.view_buffer,
            0,
            bytemuck::bytes_of(&BoundaryView {
                eye_high: [eye_high[0], eye_high[1], eye_high[2], 0.0],
                eye_low: [eye_low[0], eye_low[1], eye_low[2], 0.0],
                viewport: [
                    width.max(1) as f32,
                    height.max(1) as f32,
                    minor_opacity,
                    (near_distance_m.max(1.0) / geo::SEMI_MAJOR_M) as f32,
                ],
            }),
        );
    }

    pub fn draw<'a>(
        &'a self,
        pass: &mut wgpu::RenderPass<'a>,
        camera_bind_group: &'a wgpu::BindGroup,
        camera: &OrbitCamera,
    ) -> (usize, u64) {
        if self.batches.is_empty() {
            return (0, 0);
        }
        pass.set_pipeline(&self.pipeline);
        pass.set_bind_group(0, camera_bind_group, &[]);
        pass.set_bind_group(1, &self.view_bind_group, &[]);
        pass.set_vertex_buffer(0, self.vertices.slice(..));
        pass.set_index_buffer(self.indices.slice(..), wgpu::IndexFormat::Uint32);
        let eye = camera.eye_m();
        let planes = frustum_planes(camera.view_projection());
        let mut batches = 0;
        let mut indices = 0;
        for batch in &self.batches {
            if eye.distance(batch.center) - batch.radius <= self.far_distance_m
                && sphere_in_frustum(&planes, batch.center, batch.radius, eye)
            {
                pass.draw_indexed(
                    batch.first_index..batch.first_index + batch.index_count,
                    0,
                    0..1,
                );
                batches += 1;
                indices += batch.index_count as u64;
            }
        }
        (batches, indices)
    }
}

fn frustum_planes(matrix: glam::Mat4) -> [Vec4; 6] {
    let rows = [
        Vec4::new(
            matrix.x_axis.x,
            matrix.y_axis.x,
            matrix.z_axis.x,
            matrix.w_axis.x,
        ),
        Vec4::new(
            matrix.x_axis.y,
            matrix.y_axis.y,
            matrix.z_axis.y,
            matrix.w_axis.y,
        ),
        Vec4::new(
            matrix.x_axis.z,
            matrix.y_axis.z,
            matrix.z_axis.z,
            matrix.w_axis.z,
        ),
        Vec4::new(
            matrix.x_axis.w,
            matrix.y_axis.w,
            matrix.z_axis.w,
            matrix.w_axis.w,
        ),
    ];
    let candidates = [
        rows[3] + rows[0],
        rows[3] - rows[0],
        rows[3] + rows[1],
        rows[3] - rows[1],
        rows[2],
        rows[3] - rows[2],
    ];
    candidates.map(|plane| plane / plane.truncate().length())
}

fn sphere_in_frustum(planes: &[Vec4; 6], center: DVec3, radius: f64, eye: DVec3) -> bool {
    let relative = ((center - eye) / geo::SEMI_MAJOR_M).as_vec3();
    let radius = (radius / geo::SEMI_MAJOR_M) as f32;
    planes
        .iter()
        .all(|plane| plane.truncate().dot(relative) + plane.w >= -radius)
}

fn write_changed_chunks(
    queue: &wgpu::Queue,
    buffer: &wgpu::Buffer,
    current: &[u8],
    previous: &[u8],
    replaced: bool,
) -> usize {
    const CHUNK_BYTES: usize = 64 * 1024;
    if replaced || current.len() != previous.len() {
        queue.write_buffer(buffer, 0, current);
        return current.len();
    }
    let mut written = 0;
    for (chunk_index, chunk) in current.chunks(CHUNK_BYTES).enumerate() {
        let start = chunk_index * CHUNK_BYTES;
        if chunk != &previous[start..start + chunk.len()] {
            queue.write_buffer(buffer, start as u64, chunk);
            written += chunk.len();
        }
    }
    written
}

fn ring_key(ring: &[[f64; 2]], zoom: u8, style: f32) -> u64 {
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    zoom.hash(&mut hasher);
    style.to_bits().hash(&mut hasher);
    ring.len().hash(&mut hasher);
    for coordinate in ring {
        coordinate[0].to_bits().hash(&mut hasher);
        coordinate[1].to_bits().hash(&mut hasher);
    }
    hasher.finish()
}

fn geographic_bounds(ring: &[[f64; 2]]) -> [f64; 4] {
    ring.iter().fold(
        [
            f64::INFINITY,
            f64::INFINITY,
            f64::NEG_INFINITY,
            f64::NEG_INFINITY,
        ],
        |bounds, p| {
            [
                bounds[0].min(p[0]),
                bounds[1].min(p[1]),
                bounds[2].max(p[0]),
                bounds[3].max(p[1]),
            ]
        },
    )
}

fn tile_bounds(tile: TileKey) -> [f64; 4] {
    let count = (1_u32 << tile.z.min(30)) as f64;
    let west = tile.x as f64 / count * 360.0 - 180.0;
    let east = (tile.x as f64 + 1.0) / count * 360.0 - 180.0;
    let lat = |y: f64| {
        ((std::f64::consts::PI * (1.0 - 2.0 * y / count)).sinh())
            .atan()
            .to_degrees()
    };
    [west, lat(tile.y as f64 + 1.0), east, lat(tile.y as f64)]
}

fn bounds_intersect(a: [f64; 4], b: [f64; 4]) -> bool {
    b[0].is_finite() && a[0] <= b[2] && a[2] >= b[0] && a[1] <= b[3] && a[3] >= b[1]
}

fn sample_ring(
    ring: &[[f64; 2]],
    max_step: f64,
    terrain: &TerrainLayer,
    bounds: [f64; 4],
    style: f32,
) -> RingSamples {
    let mut samples = RingSamples {
        segments: Vec::new(),
        vertices: Vec::new(),
        bounds,
    };
    let Some(&first) = ring.first() else {
        return samples;
    };
    let sample = |coord| terrain_point(coord, terrain);
    let mut start_coord = first;
    let mut start = sample(first);
    for (index, &end_coord) in ring.iter().enumerate().skip(1) {
        let span = (end_coord[0] - start_coord[0])
            .abs()
            .max((end_coord[1] - start_coord[1]).abs());
        if span < max_step * 0.25 && index + 1 < ring.len() {
            continue;
        }
        let steps = (span / max_step).ceil().clamp(1.0, 64.0) as usize;
        let mut segment_start_coord = start_coord;
        for part in 1..=steps {
            let fraction = part as f64 / steps as f64;
            let coord = [
                start_coord[0] + (end_coord[0] - start_coord[0]) * fraction,
                start_coord[1] + (end_coord[1] - start_coord[1]) * fraction,
            ];
            let end = sample(coord);
            append_draped_segment(
                &mut samples,
                segment_start_coord,
                start,
                coord,
                end,
                style,
                0,
                &sample,
            );
            start = end;
            segment_start_coord = coord;
        }
        start_coord = end_coord;
    }
    samples
}

fn append_draped_segment<F: Fn([f64; 2]) -> DVec3>(
    samples: &mut RingSamples,
    start_coord: [f64; 2],
    start: DVec3,
    end_coord: [f64; 2],
    end: DVec3,
    style: f32,
    depth: u8,
    sample: &F,
) {
    let midpoint_coord = [
        (start_coord[0] + end_coord[0]) * 0.5,
        (start_coord[1] + end_coord[1]) * 0.5,
    ];
    let midpoint = sample(midpoint_coord);
    if depth < 4 && midpoint.distance((start + end) * 0.5) > 4.0 {
        append_draped_segment(
            samples,
            start_coord,
            start,
            midpoint_coord,
            midpoint,
            style,
            depth + 1,
            sample,
        );
        append_draped_segment(
            samples,
            midpoint_coord,
            midpoint,
            end_coord,
            end,
            style,
            depth + 1,
            sample,
        );
    } else if start.distance_squared(end) > 0.01 {
        samples.segments.push((start, end));
        samples
            .vertices
            .extend_from_slice(&segment_vertices(start, end, style));
    }
}

fn append_samples(
    vertices: &mut Vec<WorldLineVertex>,
    indices: &mut Vec<u32>,
    batches: &mut Vec<BoundaryBatch>,
    batch: &mut BatchBuilder,
    samples: &RingSamples,
) {
    for (segment_index, &(start, end)) in samples.segments.iter().enumerate() {
        if batch.segments == SEGMENTS_PER_BATCH {
            batches.push(batch.finish().expect("full boundary batch"));
            *batch = BatchBuilder::new(indices.len() as u32);
        }
        let base = vertices.len() as u32;
        vertices.extend_from_slice(&samples.vertices[segment_index * 4..segment_index * 4 + 4]);
        indices.extend_from_slice(&[base, base + 1, base + 2, base + 2, base + 1, base + 3]);
        batch.include(start, end);
    }
}

fn terrain_point(coord: [f64; 2], terrain: &TerrainLayer) -> DVec3 {
    let lat = coord[1].clamp(-89.9999, 89.9999).to_radians();
    let lon = (coord[0] + 180.0).rem_euclid(360.0).to_radians() - std::f64::consts::PI;
    geo::geodetic_position(lat, lon, terrain.sample(lat, lon) + 12.0)
}

fn split_position(position: DVec3) -> ([f32; 3], [f32; 3]) {
    let normalized = position / geo::SEMI_MAJOR_M;
    let high = [
        normalized.x as f32,
        normalized.y as f32,
        normalized.z as f32,
    ];
    let low = [
        (normalized.x - high[0] as f64) as f32,
        (normalized.y - high[1] as f64) as f32,
        (normalized.z - high[2] as f64) as f32,
    ];
    (high, low)
}

fn segment_vertices(start: DVec3, end: DVec3, style: f32) -> [WorldLineVertex; 4] {
    let (start_high, start_low) = split_position(start);
    let (end_high, end_low) = split_position(end);
    let vertex = |endpoint, side| WorldLineVertex {
        start_high,
        start_low,
        end_high,
        end_low,
        corner: [endpoint, side],
        style,
    };
    [
        vertex(0.0, -1.0),
        vertex(1.0, -1.0),
        vertex(0.0, 1.0),
        vertex(1.0, 1.0),
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shader_is_valid_wgsl() {
        let module = naga::front::wgsl::parse_str(include_str!("boundary.wgsl"))
            .expect("boundary shader parses");
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&module)
        .expect("boundary shader validates");
    }

    #[test]
    fn rugged_terrain_subdivides_without_breaking_line_continuity() {
        let sample = |coordinate: [f64; 2]| {
            let x = coordinate[0];
            DVec3::new(x * 100.0, 0.0, 40.0 * (1.0 - (2.0 * x - 1.0).powi(2)))
        };
        let mut samples = RingSamples {
            segments: Vec::new(),
            vertices: Vec::new(),
            bounds: [0.0; 4],
        };
        append_draped_segment(
            &mut samples,
            [0.0, 0.0],
            sample([0.0, 0.0]),
            [1.0, 0.0],
            sample([1.0, 0.0]),
            2.0,
            0,
            &sample,
        );
        assert!(samples.segments.len() >= 4);
        assert_eq!(samples.vertices.len(), samples.segments.len() * 4);
        for pair in samples.segments.windows(2) {
            assert_eq!(pair[0].1, pair[1].0);
        }
        assert!(samples.segments.iter().any(|segment| segment.1.z >= 40.0));
    }

    #[test]
    fn world_line_vertices_reconstruct_precise_earth_positions() {
        let point = geo::geodetic_position(30.0_f64.to_radians(), 102.0_f64.to_radians(), 3000.0);
        let (high, low) = split_position(point);
        let restored = DVec3::new(
            high[0] as f64 + low[0] as f64,
            high[1] as f64 + low[1] as f64,
            high[2] as f64 + low[2] as f64,
        ) * geo::SEMI_MAJOR_M;
        assert!(restored.distance(point) < 0.01);
    }

    #[test]
    fn indexed_segments_share_vertices_and_keep_six_triangle_indices() {
        let mut vertices = Vec::new();
        let mut indices = Vec::new();
        let mut batches = Vec::new();
        let mut batch = BatchBuilder::new(0);
        let samples = RingSamples {
            segments: vec![(DVec3::ZERO, DVec3::X)],
            vertices: segment_vertices(DVec3::ZERO, DVec3::X, 2.0).to_vec(),
            bounds: [0.0; 4],
        };
        append_samples(
            &mut vertices,
            &mut indices,
            &mut batches,
            &mut batch,
            &samples,
        );
        assert_eq!(vertices.len(), 4);
        assert_eq!(indices, [0, 1, 2, 2, 1, 3]);
    }

    #[test]
    fn batch_culling_keeps_intersecting_spheres() {
        let planes = frustum_planes(glam::Mat4::IDENTITY);
        assert!(sphere_in_frustum(&planes, DVec3::ZERO, 0.0, DVec3::ZERO));
        assert!(!sphere_in_frustum(
            &planes,
            DVec3::X * (2.0 * geo::SEMI_MAJOR_M),
            0.0,
            DVec3::ZERO,
        ));
        assert!(sphere_in_frustum(
            &planes,
            DVec3::X * (2.0 * geo::SEMI_MAJOR_M),
            geo::SEMI_MAJOR_M,
            DVec3::ZERO,
        ));
    }

    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn world_boundary_pipeline_passes_device_validation() {
        let instance = wgpu::Instance::default();
        let Ok(adapter) = pollster::block_on(instance.request_adapter(&Default::default())) else {
            return;
        };
        let (device, queue) = pollster::block_on(adapter.request_device(&Default::default()))
            .expect("request a device for boundary pipeline validation");
        let camera_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("test camera layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let error_scope = device.push_error_scope(wgpu::ErrorFilter::Validation);
        let mut layer =
            BoundaryLayer::new(&device, wgpu::TextureFormat::Rgba8UnormSrgb, &camera_layout);
        let terrain = TerrainLayer::new();
        let ring = vec![vec![[108.0, 34.0], [109.0, 34.0]]];
        let first = layer.update_geometry(&device, &queue, &ring, &[], 5, &terrain, &[]);
        assert_eq!((first.resampled, first.reused), (1, 0));
        let second = layer.update_geometry(&device, &queue, &ring, &[], 5, &terrain, &[]);
        assert_eq!((second.resampled, second.reused), (0, 1));
        assert_eq!(second.bytes, 0);
        let dirty = [TileKey { z: 5, x: 25, y: 12 }];
        let third = layer.update_geometry(&device, &queue, &ring, &[], 5, &terrain, &dirty);
        assert_eq!((third.resampled, third.reused), (1, 0));
        assert!(third.patched);
        assert_eq!(
            third.bytes, 0,
            "unchanged DEM samples must not upload geometry"
        );
        let extended = vec![vec![[108.0, 34.0], [109.0, 34.0], [109.5, 34.0]]];
        let fourth = layer.update_geometry(&device, &queue, &extended, &[], 5, &terrain, &[]);
        assert!(
            !fourth.patched,
            "changed boundary topology needs a full rebuild"
        );
        assert!(pollster::block_on(error_scope.pop()).is_none());
    }
}
