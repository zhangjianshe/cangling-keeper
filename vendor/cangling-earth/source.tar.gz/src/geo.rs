use glam::DVec3;

/// WGS84 ellipsoid. CPU positions and camera altitudes are in metres.
pub const SEMI_MAJOR_M: f64 = 6_378_137.0;
pub const INVERSE_FLATTENING: f64 = 298.257_223_563;
pub const FLATTENING: f64 = 1.0 / INVERSE_FLATTENING;
pub const SEMI_MINOR_M: f64 = SEMI_MAJOR_M * (1.0 - FLATTENING);
pub const ECCENTRICITY_SQUARED: f64 = FLATTENING * (2.0 - FLATTENING);

/// The GPU uses equatorial-radius units; all geodesy is calculated in f64 first.
pub fn geodetic_position(latitude: f64, longitude: f64, height_m: f64) -> DVec3 {
    let (sin_lat, cos_lat) = latitude.sin_cos();
    let (sin_lon, cos_lon) = longitude.sin_cos();
    let prime_vertical = SEMI_MAJOR_M / (1.0 - ECCENTRICITY_SQUARED * sin_lat * sin_lat).sqrt();
    DVec3::new(
        (prime_vertical + height_m) * cos_lat * sin_lon,
        (prime_vertical * (1.0 - ECCENTRICITY_SQUARED) + height_m) * sin_lat,
        (prime_vertical + height_m) * cos_lat * cos_lon,
    )
}

pub fn geodetic_lat_lon(position: DVec3) -> (f64, f64) {
    let longitude = position.x.atan2(position.z);
    let horizontal = position.x.hypot(position.z);
    let mut latitude = position.y.atan2(horizontal * (1.0 - ECCENTRICITY_SQUARED));
    for _ in 0..5 {
        let sin_lat = latitude.sin();
        let n = SEMI_MAJOR_M / (1.0 - ECCENTRICITY_SQUARED * sin_lat * sin_lat).sqrt();
        latitude = (position.y + ECCENTRICITY_SQUARED * n * sin_lat).atan2(horizontal);
    }
    (latitude, longitude)
}

pub fn geodetic_height(position: DVec3, latitude: f64) -> f64 {
    let horizontal = position.x.hypot(position.z);
    let sin_lat = latitude.sin();
    let n = SEMI_MAJOR_M / (1.0 - ECCENTRICITY_SQUARED * sin_lat * sin_lat).sqrt();
    if latitude.cos().abs() > 1e-8 {
        horizontal / latitude.cos() - n
    } else {
        position.y / sin_lat - n * (1.0 - ECCENTRICITY_SQUARED)
    }
}

pub fn ray_ellipsoid_intersection(origin: DVec3, direction: DVec3) -> Option<DVec3> {
    ray_expanded_ellipsoid_intersection(origin, direction, 0.0)
}

pub fn ray_expanded_ellipsoid_intersection(
    origin: DVec3,
    direction: DVec3,
    margin_m: f64,
) -> Option<DVec3> {
    let scale = DVec3::new(
        1.0 / (SEMI_MAJOR_M + margin_m),
        1.0 / (SEMI_MINOR_M + margin_m),
        1.0 / (SEMI_MAJOR_M + margin_m),
    );
    let o = origin * scale;
    let d = direction * scale;
    let a = d.length_squared();
    let b = o.dot(d);
    let c = o.length_squared() - 1.0;
    let discriminant = b * b - a * c;
    if discriminant < 0.0 {
        return None;
    }
    let root = discriminant.sqrt();
    let near = (-b - root) / a;
    let far = (-b + root) / a;
    let t = if near >= 0.0 { near } else { far };
    (t >= 0.0).then(|| origin + direction * t)
}

/// A fixed-radius surface for a stable middle-drag anchor while DEM tiles load.
pub fn ray_sphere_intersection(origin: DVec3, direction: DVec3, radius_m: f64) -> Option<DVec3> {
    let direction = direction.normalize();
    let b = origin.dot(direction);
    let c = origin.length_squared() - radius_m * radius_m;
    let discriminant = b * b - c;
    if discriminant < 0.0 {
        return None;
    }
    let root = discriminant.sqrt();
    let near = -b - root;
    let far = -b + root;
    let distance = if near >= 0.0 { near } else { far };
    (distance >= 0.0).then(|| origin + direction * distance)
}

pub fn radial_surface_radius(direction: DVec3) -> f64 {
    let direction = direction.normalize();
    1.0 / ((direction.x * direction.x + direction.z * direction.z) / SEMI_MAJOR_M.powi(2)
        + direction.y * direction.y / SEMI_MINOR_M.powi(2))
    .sqrt()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn wgs84_axes_match_definition() {
        assert!((geodetic_position(0.0, 0.0, 0.0).z - SEMI_MAJOR_M).abs() < 1e-6);
        assert!(
            (geodetic_position(std::f64::consts::FRAC_PI_2, 0.0, 0.0).y - SEMI_MINOR_M).abs()
                < 1e-6
        );
    }

    #[test]
    fn high_zoom_ray_resolves_small_ground_motion() {
        let origin = DVec3::new(0.0, 0.0, SEMI_MAJOR_M + 150.0);
        let first = ray_ellipsoid_intersection(origin, -DVec3::Z).unwrap();
        let second =
            ray_ellipsoid_intersection(origin, DVec3::new(0.0001, 0.0, -1.0).normalize()).unwrap();
        assert!(second.distance(first) > 0.01);
    }

    #[test]
    fn radial_radius_tracks_equator_and_poles() {
        assert!((radial_surface_radius(DVec3::Z) - SEMI_MAJOR_M).abs() < 1e-6);
        assert!((radial_surface_radius(DVec3::Y) - SEMI_MINOR_M).abs() < 1e-6);
    }

    #[test]
    fn sphere_pick_returns_near_surface() {
        let eye = DVec3::new(0.0, 0.0, SEMI_MAJOR_M + 1_000.0);
        let hit = ray_sphere_intersection(eye, -DVec3::Z, SEMI_MAJOR_M).unwrap();
        assert!((hit.z - SEMI_MAJOR_M).abs() < 1e-5);
    }

    #[test]
    fn ecef_height_round_trips_at_alps() {
        let latitude = 46.84_f64.to_radians();
        let point = geodetic_position(latitude, 8.55_f64.to_radians(), 3_200.0);
        let (derived_lat, _) = geodetic_lat_lon(point);
        assert!((geodetic_height(point, derived_lat) - 3_200.0).abs() < 1e-5);
    }
}
