//! Lightweight rigid-joint animation for the built-in avatar only.
use glam::{DQuat,DVec3};
#[derive(Clone,Copy,Debug,Default)]
pub struct WalkerPose {pub phase:f64,pub time:f64,pub moving:f64,pub running:f64,pub airborne:bool,pub landing:f64}
impl WalkerPose {
    pub fn transform(&self,joint:&str,p:DVec3,n:DVec3)->(DVec3,DVec3){
        let stride=self.phase.sin()*self.moving*(0.5+0.35*self.running);
        let crouch=self.landing*0.08;
        let breathing=(self.time*2.).sin()*0.012*(1.-self.moving);
        let (pivot,angle)=match joint {
            "left_leg"=>(DVec3::new(-0.14,0.76,0.),if self.airborne{-0.35}else{stride}),
            "right_leg"=>(DVec3::new(0.14,0.76,0.),if self.airborne{0.25}else{-stride}),
            "left_arm"=>(DVec3::new(-0.34,1.31,0.),if self.airborne{-0.8}else{-stride*0.85}),
            "right_arm"=>(DVec3::new(0.34,1.31,0.),if self.airborne{-0.8}else{stride*0.85}),
            "torso"|"head"=>(DVec3::new(0.,0.76,0.),-0.08*self.running*self.moving),
            _=>return(p,n),
        };
        let rotation=DQuat::from_rotation_x(angle);
        let bob=if self.airborne{0.}else{0.025*self.moving*(self.phase*2.).sin().abs()};
        let offset=if joint.ends_with("leg"){bob}else{bob+breathing-crouch};
        (pivot+rotation*(p-pivot)+DVec3::Y*offset,rotation*n)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn joints_swing_oppositely_and_normals_rotate(){
        let pose=WalkerPose{phase:std::f64::consts::FRAC_PI_2,moving:1.,..Default::default()};
        let (left,normal)=pose.transform("left_leg",DVec3::new(-0.14,0.,0.),DVec3::Z);
        let (right,_)=pose.transform("right_leg",DVec3::new(0.14,0.,0.),DVec3::Z);
        assert!(left.z*right.z<0.);assert!((normal.length()-1.).abs()<1e-10);
        let running=WalkerPose{running:1.,..pose};assert!(running.transform("left_leg",DVec3::new(-0.14,0.,0.),DVec3::Z).0.z.abs()>left.z.abs());
        assert_eq!(pose.transform("unrelated",DVec3::X,DVec3::Y),(DVec3::X,DVec3::Y));
    }
    #[test] fn idle_jump_and_landing_have_distinct_poses(){
        let point=DVec3::new(-0.34,0.7,0.);let idle=WalkerPose{time:0.5,..Default::default()};
        let air=WalkerPose{airborne:true,..idle};assert_ne!(idle.transform("left_arm",point,DVec3::Z),air.transform("left_arm",point,DVec3::Z));
        let landed=WalkerPose{landing:1.,..idle};assert!(landed.transform("torso",DVec3::Y,DVec3::Z).0.y<idle.transform("torso",DVec3::Y,DVec3::Z).0.y);
    }
}
