use std::sync::Arc;

use anyhow::Result;
use cangling_desktop::renderer::{RenderStatus, Renderer};
use winit::{
    application::ApplicationHandler,
    dpi::LogicalSize,
    event::WindowEvent,
    event_loop::{ActiveEventLoop, ControlFlow, EventLoop},
    window::{CursorIcon, Window, WindowAttributes, WindowId},
};

#[derive(Default)]
struct App {
    window: Option<Arc<Window>>,
    renderer: Option<Renderer>,
}

impl ApplicationHandler for App {
    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        if self.window.is_some() {
            return;
        }

        let attributes = WindowAttributes::default()
            .with_title("Cangling Desktop · Earth")
            .with_inner_size(LogicalSize::new(1440, 900));
        let window = Arc::new(event_loop.create_window(attributes).expect("create window"));
        self.renderer =
            Some(pollster::block_on(Renderer::new(window.clone())).expect("initialize GPU"));
        self.window = Some(window);
    }

    fn window_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        window_id: WindowId,
        event: WindowEvent,
    ) {
        let Some(window) = self.window.as_ref() else {
            return;
        };
        if window.id() != window_id {
            return;
        }

        if matches!(event, WindowEvent::CloseRequested) {
            event_loop.exit();
            return;
        }

        if let Some(renderer) = self.renderer.as_mut() {
            renderer.input(&event);
            if matches!(
                event,
                WindowEvent::MouseInput { .. }
                    | WindowEvent::MouseWheel { .. }
                    | WindowEvent::KeyboardInput { .. }
                    | WindowEvent::CursorLeft { .. }
                    | WindowEvent::Focused(false)
            ) {
                window.set_cursor(if renderer.is_grabbing_globe() {
                    CursorIcon::Grabbing
                } else {
                    CursorIcon::Default
                });
            }
            match event {
                WindowEvent::Resized(size) => renderer.resize(size),
                WindowEvent::RedrawRequested => {
                    renderer.update();
                    match renderer.render() {
                        RenderStatus::Presented | RenderStatus::Skipped => {}
                        RenderStatus::Reconfigure => renderer.resize(window.inner_size()),
                    }
                    window.request_redraw();
                }
                _ => {}
            }
        }
    }

    fn about_to_wait(&mut self, _event_loop: &ActiveEventLoop) {
        if let Some(window) = &self.window {
            window.request_redraw();
        }
    }
}

fn main() -> Result<()> {
    env_logger::init();
    let event_loop = EventLoop::new()?;
    event_loop.set_control_flow(ControlFlow::Poll);
    event_loop.run_app(&mut App::default())?;
    Ok(())
}
