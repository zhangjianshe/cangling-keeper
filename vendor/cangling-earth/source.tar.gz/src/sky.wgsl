struct Sky { inverse_view: mat4x4<f32>, up: vec4<f32> };
@group(0) @binding(0) var<uniform> sky: Sky;
struct Output { @builtin(position) position:vec4<f32>, @location(0) ray:vec3<f32> };
@vertex fn vs_main(@builtin(vertex_index) index:u32)->Output {
    let vertices=array<vec2<f32>,3>(vec2<f32>(-1.,-1.),vec2<f32>(3.,-1.),vec2<f32>(-1.,3.));
    let xy=vertices[index];
    let world=sky.inverse_view*vec4<f32>(xy,0.5,1.);
    var out:Output;out.position=vec4<f32>(xy,1.,1.);out.ray=world.xyz/world.w;return out;
}
@fragment fn fs_main(input:Output)->@location(0) vec4<f32> {
    let elevation=dot(normalize(input.ray),sky.up.xyz);
    let horizon=vec3<f32>(0.64,0.79,0.92);
    let zenith=vec3<f32>(0.07,0.29,0.64);
    let color=mix(horizon,zenith,pow(clamp(elevation,0.,1.),0.55));
    // Below the horizon, use soft atmospheric haze; terrain still draws over it.
    return vec4<f32>(mix(color,vec3<f32>(0.48,0.59,0.65),clamp(-elevation,0.,1.)),1.);
}
