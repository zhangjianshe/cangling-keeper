impl Renderer {
    pub fn keeper_command(&mut self,method:&str,args:&serde_json::Value)->Result<serde_json::Value,String>{
        match method {
            "get_view"=>Ok(self.camera.keeper_view()),
            "set_view"=>{self.camera.keeper_set_view(args)?;Ok(self.camera.keeper_view())},
            "project"=>{if !args.is_array()||args.as_array().unwrap().len()>10000{return Err("invalid coordinates".into());}Ok(self.camera.keeper_project(args))},
            "pick"=>{let x=args["x"].as_f64().filter(|n|(0.0..=1.0).contains(n)).ok_or("invalid x")?;let y=args["y"].as_f64().filter(|n|(0.0..=1.0).contains(n)).ok_or("invalid y")?;Ok(self.camera.keeper_pick(x,y,&self.terrain))},
            "layers"=>{if let Some(v)=args["boundaries"].as_bool(){self.boundaries_visible=v;self.boundaries_need_refresh=true;}if let Some(v)=args["graticule"].as_bool(){self.graticule.keeper_visible(v);}if let Some(source)=args["source"].as_u64(){if source>1{return Err("invalid source".into());}self.tiles.keeper_source(source as usize);}Ok(args.clone())},
            _=>Err("unknown Earth method".into())
        }
    }
}
