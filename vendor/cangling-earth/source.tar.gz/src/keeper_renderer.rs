impl Renderer {
    pub fn keeper_model(&mut self,id:&str,bytes:&[u8],placement:&serde_json::Value)->Result<(),String>{self.models.upload(&self.device,&self.queue,id,bytes,placement)}
    pub fn keeper_image(&mut self,id:&str,bytes:&[u8],points:&[[f64;2]])->Result<(),String>{self.images.upload(&self.device,&self.queue,id,bytes,points)}
    pub fn keeper_command(&mut self,method:&str,args:&serde_json::Value)->Result<serde_json::Value,String>{
        match method {
            "vector_scene"=>{self.vectors.scene(args)?;Ok(serde_json::json!(true))},
            "vector_pick"=>{let x=args["x"].as_f64().filter(|v|(0.0..=1.0).contains(v)).ok_or("invalid x")?;let y=args["y"].as_f64().filter(|v|(0.0..=1.0).contains(v)).ok_or("invalid y")?;Ok(self.vectors.pick(x as f32*self.config.width as f32,y as f32*self.config.height as f32))},
            "model_scene"=>{self.models.scene(args)?;Ok(serde_json::json!(true))},
            "image_scene"=>{self.images.scene(args)?;Ok(serde_json::json!(true))},
            "get_view"=>Ok(self.camera.keeper_view()),
            "set_view"=>{self.camera.keeper_set_view(args)?;Ok(self.camera.keeper_view())},
            "project"=>{if !args.is_array()||args.as_array().unwrap().len()>10000{return Err("invalid coordinates".into());}Ok(self.camera.keeper_project(args))},
            "pick"=>{let x=args["x"].as_f64().filter(|n|(0.0..=1.0).contains(n)).ok_or("invalid x")?;let y=args["y"].as_f64().filter(|n|(0.0..=1.0).contains(n)).ok_or("invalid y")?;Ok(self.camera.keeper_pick(x,y,&self.terrain))},
            "layers"=>{if let Some(v)=args["boundaries"].as_bool(){self.boundaries_visible=v;self.boundaries_need_refresh=true;}if let Some(v)=args["graticule"].as_bool(){self.graticule.keeper_visible(v);}if let Some(source)=args["source"].as_u64(){if source>1{return Err("invalid source".into());}self.tiles.keeper_source(source as usize);}Ok(args.clone())},
            _=>Err("unknown Earth method".into())
        }
    }
}
