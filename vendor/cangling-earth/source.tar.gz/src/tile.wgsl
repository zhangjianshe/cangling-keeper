struct Camera {
    view_projection: mat4x4<f32>,
    eye: vec4<f32>,
};

@group(0) @binding(0) var<uniform> camera: Camera;
@group(1) @binding(0) var tile_texture: texture_2d<f32>;
@group(1) @binding(1) var tile_sampler: sampler;
struct TileOffset {
    relative_origin: vec4<f32>,
};
@group(1) @binding(2) var<uniform> tile_offset: TileOffset;

struct VertexInput {
    @location(0) position: vec3<f32>,
    @location(1) normal: vec3<f32>,
    @location(2) uv: vec2<f32>,
};

struct VertexOutput {
    @builtin(position) clip_position: vec4<f32>,
    @location(0) uv: vec2<f32>,
};

@vertex
fn vs_main(input: VertexInput) -> VertexOutput {
    var out: VertexOutput;
    let position_from_eye = input.position + tile_offset.relative_origin.xyz;
    out.clip_position = camera.view_projection * vec4(position_from_eye, 1.0);
    out.uv = input.uv;
    return out;
}

@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    // Raster tiles already carry their own illumination and contrast. Their
    // sRGB texture format performs the color-space conversion on sampling;
    // an extra diffuse multiplier would darken large parts of the globe.
    return textureSample(tile_texture, tile_sampler, input.uv);
}
