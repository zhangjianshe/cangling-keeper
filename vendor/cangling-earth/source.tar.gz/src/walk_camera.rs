// First-person navigation in a local east/north/up frame on WGS84.
struct WalkState {
    latitude: f64,
    longitude: f64,
    elevation: f64,
    forward: f64,
    right: f64,
    sprint: bool,
    saved: (DQuat, f64, f64, f64),
}
impl OrbitCamera {
    pub fn is_walking(&self) -> bool { self.walk.is_some() }
    pub fn set_walking(&mut self, enabled: bool, terrain: &TerrainLayer) -> Result<(), String> {
        if enabled == self.is_walking() { return Ok(()); }
        if enabled {
            let point=self.pick_surface_terrain(self.screen_center(),terrain).ok_or("请先将画面中心对准地面")?;
            let (latitude,longitude)=geo::geodetic_lat_lon(point);
            let saved=(self.orientation,self.distance_m,self.tilt_radians,self.heading_radians);
            self.resize(self.viewport);
            self.home_flight=None; self.patrol_start=None; self.keyboard_tilt_target=None;
            self.walk=Some(WalkState{latitude,longitude,elevation:terrain.sample(latitude,longitude).max(0.),forward:0.,right:0.,sprint:false,saved});
            self.tilt_radians=std::f64::consts::FRAC_PI_2;
            self.update_walk_surface(terrain);
        } else if let Some(w)=self.walk.take() {
            self.orientation=w.saved.0; self.distance_m=w.saved.1; self.target_distance_m=w.saved.1;
            self.tilt_radians=w.saved.2; self.heading_radians=w.saved.3;
            self.resize(self.viewport); self.refresh_terrain_clearance(terrain);
        }
        Ok(())
    }
    pub fn walk_controls(&mut self, forward:f64,right:f64,sprint:bool) {
        if let Some(w)=self.walk.as_mut(){w.forward=forward.clamp(-1.,1.);w.right=right.clamp(-1.,1.);w.sprint=sprint;}
    }
    pub fn walk_look(&mut self,x:f64,y:f64) {
        if self.is_walking(){
            self.heading_radians=(self.heading_radians-x.clamp(-200.,200.)*0.002).rem_euclid(std::f64::consts::TAU);
            self.tilt_radians=(self.tilt_radians-y.clamp(-200.,200.)*0.002).clamp(10_f64.to_radians(),170_f64.to_radians());
        }
    }
    fn update_walk(&mut self,dt:f64) {
        let Some(w)=self.walk.as_mut() else{return};
        let normal=DVec3::new(w.latitude.cos()*w.longitude.sin(),w.latitude.sin(),w.latitude.cos()*w.longitude.cos());
        let east=DVec3::new(w.longitude.cos(),0.,-w.longitude.sin());let north=normal.cross(east);
        let forward=north*self.heading_radians.cos()-east*self.heading_radians.sin();
        let right=east*self.heading_radians.cos()+north*self.heading_radians.sin();
        let motion=(forward*w.forward+right*w.right).clamp_length_max(1.)*dt*if w.sprint{8.}else{2.};
        let p=geo::geodetic_position(w.latitude,w.longitude,0.)+motion;
        (w.latitude,w.longitude)=geo::geodetic_lat_lon(p);
        self.orientation=north_up_orientation(w.latitude,w.longitude);
    }
    fn update_walk_surface(&mut self,terrain:&TerrainLayer) {
        if let Some(w)=self.walk.as_mut(){
            w.elevation=terrain.sample(w.latitude,w.longitude).max(0.);
            self.orientation=north_up_orientation(w.latitude,w.longitude);
            self.distance_m=geo::geodetic_position(w.latitude,w.longitude,w.elevation+1.7).length();
            self.target_distance_m=self.distance_m;self.ground_elevation_m=w.elevation;
        }
    }
}
#[cfg(test)]
mod walk_tests {
    use super::*;
    #[test]
    fn walk_moves_at_human_speed_and_restores_orbit() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));
        let original=(c.eye_m(),c.view_projection());
        c.set_walking(true,&terrain).unwrap();let first=c.eye_m();
        assert!((c.eye_clearance_m()-1.7).abs()<0.02);
        let samples=c.visible_surface_samples(16,10);assert!((samples[0].as_dvec3()*SEMI_MAJOR_M-c.eye_m()).length()<3.);
        c.walk_controls(1.,0.,false);for _ in 0..20{c.update(0.05);c.enforce_terrain_clearance(&terrain);}
        assert!((c.eye_m().distance(first)-2.).abs()<0.05);
        c.walk_controls(0.,0.,false);let stopped=c.eye_m();c.update(0.05);c.enforce_terrain_clearance(&terrain);assert!(c.eye_m().distance(stopped)<0.01);
        c.walk_look(30.,20.);assert_ne!(c.view_projection(),original.1);
        c.set_walking(false,&terrain).unwrap();assert!(c.eye_m().distance(original.0)<0.01);assert_eq!(c.view_projection(),original.1);
    }
}
