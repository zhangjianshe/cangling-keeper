// Limit DEM downward corrections independently of frame rate. Never treat missing data as zero.
fn settle_ground(current:f64,target:f64,dt:f64)->f64 {
    if target>=current { return target; }
    (current - 12.0 * dt.clamp(0.0,0.05)).max(target)
}
// First-person navigation in a local east/north/up frame on WGS84.
struct WalkState {
    latitude: f64,
    longitude: f64,
    elevation: f64,
    target_elevation: f64,
    jump_height: f64,
    vertical_velocity: f64,
    forward: f64,
    right: f64,
    sprint: bool,
    speed: f64,
    animation: crate::walker_animation::WalkerPose,
    blocked: Option<crate::walk_motion::Block>,
    third_person: bool,
    follow_eye: DVec3,
    saved: (DQuat, f64, f64, f64),
}
impl OrbitCamera {
    /// Runtime entry point: sweep the requested movement before accepting it.
    pub fn update_ground_navigation(&mut self,seconds:f32,terrain:&TerrainLayer) {
        self.update_ground_sampled(seconds,terrain,|lat,lon|terrain.sample_available(lat,lon));
    }
    fn update_ground_sampled(&mut self,seconds:f32,terrain:&TerrainLayer,mut sample:impl FnMut(f64,f64)->Option<f64>) {
        let previous=self.walk.as_ref().map(|w|(w.latitude,w.longitude));
        self.update(seconds);
        let Some((lat,lon))=previous else{return;};
        let Some(w)=self.walk.as_mut() else{return;};
        let origin=geo::geodetic_position(lat,lon,0.);
        let destination=geo::geodetic_position(w.latitude,w.longitude,0.);
        let delta=destination-origin;let length=delta.length();
        if length<1e-6 {w.blocked=None;return;}
        let direction=delta/length;
        let airborne=w.jump_height>0. || w.vertical_velocity!=0.;
        let foot=w.elevation+w.jump_height;
        let result=crate::walk_motion::sweep(length,foot,airborne,|distance| {
            let (lat,lon)=geo::geodetic_lat_lon(origin+direction*distance);
            sample(lat,lon)
        });
        (w.latitude,w.longitude)=geo::geodetic_lat_lon(origin+direction*result.distance);
        w.blocked=result.blocked;
        if let Some(ground)=result.height {
            // Moving off an edge keeps absolute foot height; gravity completes
            // the descent. Small downward steps stay attached to the ground.
            if airborne || w.elevation-ground>crate::walk_motion::STEP_HEIGHT {
                w.jump_height=(foot-ground).max(0.);
                if w.jump_height==0. && w.vertical_velocity<0. {w.vertical_velocity=0.;w.animation.landing=1.;}
            }
            w.elevation=ground;w.target_elevation=ground;
            w.animation.airborne=w.jump_height>0. || w.vertical_velocity!=0.;
        }
        if result.distance<1e-6 {w.animation.moving*=(-12.*(seconds as f64).clamp(0.,0.05)).exp();}
        self.update_walk_surface(terrain);
    }
    pub fn walk_foot(&self)->Option<DVec3>{self.walk.as_ref().map(|w|geo::geodetic_position(w.latitude,w.longitude,w.elevation+w.jump_height))}
    pub fn clip_walk_motion(&mut self,start:DVec3,fraction:f64,terrain:&TerrainLayer) {
        if fraction>=1. {return;}
        let Some(w)=self.walk.as_mut() else{return;};
        let end=geo::geodetic_position(w.latitude,w.longitude,w.elevation+w.jump_height);
        let point=start.lerp(end,fraction.clamp(0.,1.));let (lat,lon)=geo::geodetic_lat_lon(point);
        let up=DVec3::new(lat.cos()*lon.sin(),lat.sin(),lat.cos()*lon.cos());
        if (end-start).dot(up)>0.01 && w.vertical_velocity>0. {w.vertical_velocity=0.;}
        w.latitude=lat;w.longitude=lon;
        let ground=terrain.sample_available(lat,lon).unwrap_or(w.elevation);
        w.elevation=ground;w.target_elevation=ground;w.jump_height=(geo::geodetic_height(point,lat)-ground).max(0.);
        w.blocked=Some(crate::walk_motion::Block::Building);w.animation.moving=0.;
        self.update_walk_surface(terrain);
    }
    pub fn follow_segment(&self)->Option<(DVec3,DVec3)> {
        self.walk.as_ref().filter(|w|w.third_person).map(|w|(geo::geodetic_position(w.latitude,w.longitude,w.elevation+w.jump_height+1.3),w.follow_eye))
    }
    pub fn shorten_follow_camera(&mut self,fraction:f64) {
        if let Some((target,end))=self.follow_segment(){
            if let Some(w)=self.walk.as_mut(){w.follow_eye=target.lerp(end,fraction.clamp(0.,1.));}
        }
    }
    pub fn walk_position(&self)->Option<(f64,f64)> { self.walk.as_ref().map(|w|(w.latitude,w.longitude)) }
    pub fn protect_rendered_ground(&mut self,height:Option<f64>,terrain:&TerrainLayer) {
        if let (Some(w),Some(height))=(&mut self.walk,height.filter(|h|h.is_finite())) {
            w.elevation=w.elevation.max(height);
            self.update_walk_surface(terrain);
        }
    }
    pub fn protect_follow_camera(&mut self,height:Option<f64>) {
        if let (Some(w),Some(ground))=(&mut self.walk,height.filter(|h|h.is_finite())) {
            if w.third_person {
                let (lat,lon)=geo::geodetic_lat_lon(w.follow_eye);
                let elevation=geo::geodetic_height(w.follow_eye,lat).max(ground+0.8);
                w.follow_eye=geo::geodetic_position(lat,lon,elevation);
                self.ground_elevation_m=self.ground_elevation_m.max(ground);
            }
        }
    }
    pub fn is_walking(&self) -> bool { self.walk.is_some() }
    pub fn set_walking(&mut self, enabled: bool, terrain: &TerrainLayer) -> Result<(), String> {
        if enabled == self.is_walking() { return Ok(()); }
        if enabled {
            let point=self.pick_surface_terrain(self.screen_center(),terrain).ok_or("请先将画面中心对准地面")?;
            let (latitude,longitude)=geo::geodetic_lat_lon(point);
            let saved=(self.orientation,self.distance_m,self.tilt_radians,self.heading_radians);
            self.resize(self.viewport);
            self.home_flight=None; self.patrol_start=None; self.keyboard_tilt_target=None;
            self.walk=Some(WalkState{latitude,longitude,elevation:terrain.sample(latitude,longitude).max(0.),jump_height:0.,vertical_velocity:0.,target_elevation:terrain.sample(latitude,longitude).max(0.),forward:0.,right:0.,sprint:false,speed:12.,animation:Default::default(),blocked:None,third_person:false,follow_eye:DVec3::ZERO,saved});
            self.tilt_radians=std::f64::consts::FRAC_PI_2;
            self.update_walk_surface(terrain);
        } else if let Some(w)=self.walk.take() {
            self.orientation=w.saved.0; self.distance_m=w.saved.1; self.target_distance_m=w.saved.1;
            self.tilt_radians=w.saved.2; self.heading_radians=w.saved.3;
            self.resize(self.viewport); self.refresh_terrain_clearance(terrain);
        }
        Ok(())
    }
    pub fn walk_controls(&mut self, forward:f64,right:f64,sprint:bool) {
        if let Some(w)=self.walk.as_mut(){w.forward=forward.clamp(-1.,1.);w.right=right.clamp(-1.,1.);w.sprint=sprint;}
    }
    /// Start a single ground-relative jump. Repeated presses in the air do nothing.
    pub fn walk_jump(&mut self) -> bool {
        let Some(w) = self.walk.as_mut() else { return false; };
        if w.jump_height > 0.0 || w.vertical_velocity != 0.0 { return false; }
        w.vertical_velocity = 5.0;
        true
    }
    pub fn walk_settings(&mut self,speed:Option<f64>,third_person:Option<bool>) {
        if let Some(w)=self.walk.as_mut(){
            if let Some(v)=speed.filter(|v|v.is_finite()){w.speed=v.clamp(1.,200.);}
            if let Some(v)=third_person { if v!=w.third_person {w.third_person=v;self.tilt_radians=if v{75_f64.to_radians()}else{std::f64::consts::FRAC_PI_2};} }
        }
    }
    pub fn walk_status(&self)->serde_json::Value {
        serde_json::json!({"walking":self.is_walking(),"blocked":self.walk.as_ref().and_then(|w|w.blocked.map(|b|match b{crate::walk_motion::Block::Building=>"building",crate::walk_motion::Block::Steep=>"steep",crate::walk_motion::Block::Missing=>"terrain_pending"})),"jumpHeight":self.walk.as_ref().map_or(0.,|w|w.jump_height),"speed":self.walk.as_ref().map_or(12.,|w|w.speed),"thirdPerson":self.walk.as_ref().is_some_and(|w|w.third_person)})
    }
    pub fn walk_animation(&self)->Option<crate::walker_animation::WalkerPose>{self.walk.as_ref().map(|w|w.animation)}
    pub fn walk_avatar(&self)->serde_json::Value {
        let Some(w)=&self.walk else{return serde_json::json!([{"id":"walker","visible":false}])};
        serde_json::json!([{"id":"walker","visible":w.third_person && w.follow_eye.distance(geo::geodetic_position(w.latitude,w.longitude,w.elevation+w.jump_height+1.3))>0.8,"longitude":w.longitude.to_degrees(),"latitude":w.latitude.to_degrees(),"height":w.elevation+w.jump_height,"altitudeMode":"absolute","heading":-self.heading_radians.to_degrees(),"scale":1.}])
    }
    pub fn walk_look(&mut self,x:f64,y:f64) {
        if self.is_walking(){
            self.heading_radians=(self.heading_radians-x.clamp(-200.,200.)*0.002).rem_euclid(std::f64::consts::TAU);
            self.tilt_radians=(self.tilt_radians-y.clamp(-200.,200.)*0.002).clamp(10_f64.to_radians(),if self.walk.as_ref().is_some_and(|w|w.third_person){85_f64.to_radians()}else{170_f64.to_radians()});
        }
    }
    fn update_walk(&mut self,dt:f64) {
        let Some(w)=self.walk.as_mut() else{return};
        let moving=if (w.forward!=0. || w.right!=0.) && w.blocked.is_none() {1.}else{0.};
        let blend=1.-(-12.*dt).exp();
        w.animation.time=(w.animation.time+dt).rem_euclid(1000.);
        w.animation.moving+=(moving-w.animation.moving)*blend;
        w.animation.running+=((if w.sprint{1.}else{0.})-w.animation.running)*blend;
        if moving>0. {
            let frequency=if w.sprint{2.8}else{1.7};
            w.animation.phase=(w.animation.phase+dt*std::f64::consts::TAU*frequency*if w.forward<0.{-1.}else{1.}).rem_euclid(std::f64::consts::TAU);
        }
        w.animation.landing=(w.animation.landing-dt*5.).max(0.);
        let was_airborne=w.vertical_velocity!=0. || w.jump_height>0.;
        // Descend gradually when DEM refines; upward correction is immediate
        // so an arriving mountain cannot leave the eye below the ground.
        w.elevation = settle_ground(w.elevation, w.target_elevation, dt);
        if w.vertical_velocity != 0.0 || w.jump_height > 0.0 {
            w.jump_height += w.vertical_velocity * dt - 0.5 * 9.81 * dt * dt;
            w.vertical_velocity -= 9.81 * dt;
            if w.jump_height <= 0.0 { w.jump_height = 0.0; w.vertical_velocity = 0.0; }
        }
        w.animation.airborne=w.vertical_velocity!=0. || w.jump_height>0.;
        if was_airborne && !w.animation.airborne {w.animation.landing=1.;}
        let normal=DVec3::new(w.latitude.cos()*w.longitude.sin(),w.latitude.sin(),w.latitude.cos()*w.longitude.cos());
        let east=DVec3::new(w.longitude.cos(),0.,-w.longitude.sin());let north=normal.cross(east);
        let forward=north*self.heading_radians.cos()-east*self.heading_radians.sin();
        let right=east*self.heading_radians.cos()+north*self.heading_radians.sin();
        let motion=(forward*w.forward+right*w.right).clamp_length_max(1.)*dt*w.speed*if w.sprint{4.}else{1.};
        let p=geo::geodetic_position(w.latitude,w.longitude,0.)+motion;
        (w.latitude,w.longitude)=geo::geodetic_lat_lon(p);
        self.orientation=north_up_orientation(w.latitude,w.longitude);
    }
    fn update_walk_surface(&mut self,terrain:&TerrainLayer) {
        if let Some(w)=self.walk.as_mut(){
            if let Some(height) = terrain.sample_available(w.latitude,w.longitude).filter(|v| v.is_finite()) {
                w.target_elevation=height.max(0.);
                w.elevation=w.elevation.max(w.target_elevation);
            }
            self.orientation=north_up_orientation(w.latitude,w.longitude);
            self.distance_m=geo::geodetic_position(w.latitude,w.longitude,w.elevation+w.jump_height+1.7).length();
            self.target_distance_m=self.distance_m;self.ground_elevation_m=w.elevation;
        }
        if self.walk.as_ref().is_some_and(|w|w.third_person){
            let w=self.walk.as_ref().unwrap();
            let target=geo::geodetic_position(w.latitude,w.longitude,w.elevation+w.jump_height+1.3);
            let desired=target-(self.view_orientation(self.orientation)*-DVec3::Z)*6.;
            let (lat,lon)=geo::geodetic_lat_lon(desired);let ground=terrain.sample_available(lat,lon).unwrap_or(w.elevation).max(0.);
            let height=geo::geodetic_height(desired,lat).max(ground+0.8);
            self.walk.as_mut().unwrap().follow_eye=geo::geodetic_position(lat,lon,height);
            self.ground_elevation_m=ground;
        }
    }
}
#[cfg(test)]
mod walk_tests {
    use super::*;
    #[test]
    fn building_contact_clips_motion_and_camera_recovers() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));c.set_walking(true,&terrain).unwrap();c.walk_settings(None,Some(true));c.enforce_terrain_clearance(&terrain);
        let start=c.walk_foot().unwrap();c.walk_controls(1.,0.,true);c.update(0.05);let length=c.walk_foot().unwrap().distance(start);
        c.clip_walk_motion(start,0.25,&terrain);assert!((c.walk_foot().unwrap().distance(start)-length*0.25).abs()<0.001);assert_eq!(c.walk_status()["blocked"],"building");
        let (target,end)=c.follow_segment().unwrap();c.shorten_follow_camera(0.25);assert!((c.eye_m().distance(target)-end.distance(target)*0.25).abs()<1e-6);
        c.enforce_terrain_clearance(&terrain);assert!(c.eye_m().distance(target)>5.9);
        c.walk_settings(None,Some(false));assert!(c.follow_segment().is_none());
    }
    #[test]
    fn controller_stops_at_missing_dem_and_resumes_when_it_arrives() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));c.set_walking(true,&terrain).unwrap();
        let before=c.walk_position().unwrap();c.walk_controls(1.,0.,true);
        c.update_ground_sampled(0.05,&terrain,|_,_|None);
        let after=c.walk_position().unwrap();assert!((after.0-before.0).abs()<1e-10);assert_eq!(c.walk_status()["blocked"],"terrain_pending");
        c.update_ground_sampled(0.05,&terrain,|_,_|Some(0.));assert_ne!(c.walk_position().unwrap(),before);assert!(c.walk_status()["blocked"].is_null());
    }
    #[test]
    fn stepping_off_a_drop_falls_then_lands_without_air_jump() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));c.set_walking(true,&terrain).unwrap();
        {let w=c.walk.as_mut().unwrap();w.elevation=3.;w.target_elevation=3.;}
        c.walk_controls(1.,0.,false);c.update_ground_sampled(0.05,&terrain,|_,_|Some(0.));
        let w=c.walk.as_ref().unwrap();assert_eq!(w.elevation,0.);assert!((w.jump_height-3.).abs()<1e-6);assert!(!c.walk_jump());
        c.walk_controls(0.,0.,false);for _ in 0..30{c.update_ground_sampled(0.05,&terrain,|_,_|Some(0.));}
        assert_eq!(c.walk.as_ref().unwrap().jump_height,0.);assert!(c.walk_jump());
    }
    #[test]
    fn mouse_view_avatar_and_forward_motion_agree_in_both_perspectives() {
        let terrain=TerrainLayer::new();
        for third in [false,true] {
            let mut c=OrbitCamera::new(PhysicalSize::new(800,600));c.set_walking(true,&terrain).unwrap();c.walk_settings(None,Some(third));
            let w=c.walk.as_ref().unwrap();let lat=w.latitude;let lon=w.longitude;
            let up=DVec3::new(lat.cos()*lon.sin(),lat.sin(),lat.cos()*lon.cos());
            let east=DVec3::new(lon.cos(),0.,-lon.sin());let north=up.cross(east);
            let old_right=c.view_orientation(c.orientation)*DVec3::X;
            c.walk_look(100.,0.);
            let view=c.view_orientation(c.orientation)*-DVec3::Z;
            assert!(view.dot(old_right)>0.,"mouse right must look right");
            let heading=c.walk_avatar()[0]["heading"].as_f64().unwrap().to_radians();
            let avatar=east*heading.sin()+north*heading.cos();
            let horizontal=(view-up*view.dot(up)).normalize();assert!(avatar.dot(horizontal)>0.999999);
            let before=geo::geodetic_position(lat,lon,0.);c.walk_controls(1.,0.,false);c.update(0.05);
            let w=c.walk.as_ref().unwrap();let motion=geo::geodetic_position(w.latitude,w.longitude,0.)-before;
            assert!(motion.normalize().dot(horizontal)>0.99999,"W follows the camera and avatar");
            let before_up=(c.view_orientation(c.orientation)*-DVec3::Z).dot(up);
            c.walk_look(0.,100.);assert!((c.view_orientation(c.orientation)*-DVec3::Z).dot(up)<before_up,"mouse down looks down");
        }
    }
    #[test]
    fn animation_transitions_from_idle_to_run_jump_and_rest() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));c.set_walking(true,&terrain).unwrap();
        assert_eq!(c.walk_animation().unwrap().moving,0.);c.walk_controls(1.,0.,false);
        for _ in 0..10{c.update(0.05);}let walk=c.walk_animation().unwrap();assert!(walk.moving>0.99);assert_eq!(walk.running,0.);
        c.walk_controls(1.,0.,true);for _ in 0..10{c.update(0.05);}assert!(c.walk_animation().unwrap().running>0.99);
        c.walk_jump();c.update(0.05);assert!(c.walk_animation().unwrap().airborne);
        c.walk_controls(0.,0.,false);for _ in 0..20{c.update(0.05);}assert!(!c.walk_animation().unwrap().airborne);assert!(c.walk_animation().unwrap().landing>0.);
        for _ in 0..20{c.update(0.05);}let idle=c.walk_animation().unwrap();assert!(idle.moving<0.001);assert_eq!(idle.landing,0.);
        c.set_walking(false,&terrain).unwrap();assert!(c.walk_animation().is_none());
    }
    #[test]
    fn missing_dem_preserves_height_and_descent_is_bounded() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));c.set_walking(true,&terrain).unwrap();
        {let w=c.walk.as_mut().unwrap();w.elevation=120.;w.target_elevation=120.;}
        c.enforce_terrain_clearance(&terrain);assert_eq!(c.walk.as_ref().unwrap().elevation,120.);
        assert_eq!(settle_ground(120.,0.,0.05),119.4);assert_eq!(settle_ground(100.,150.,0.05),150.);
        c.protect_rendered_ground(Some(140.),&terrain);assert_eq!(c.walk.as_ref().unwrap().elevation,140.);
        c.protect_rendered_ground(None,&terrain);assert_eq!(c.walk.as_ref().unwrap().elevation,140.);
    }
    #[test]
    fn walking_prefetches_feet_and_forward_corridor() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));c.set_walking(true,&terrain).unwrap();
        c.walk_settings(Some(100.),None);c.walk_controls(1.,0.,true);
        let samples=c.visible_surface_samples(0,0);assert_eq!(samples.len(),37);
        let w=c.walk.as_ref().unwrap();let center=geo::geodetic_position(w.latitude,w.longitude,w.elevation);
        assert!((samples[0].as_dvec3()*SEMI_MAJOR_M-center).length()<1.);
        let furthest=samples.iter().map(|p|(p.as_dvec3()*SEMI_MAJOR_M-center).length()).fold(0.,f64::max);
        assert!(furthest>790. && furthest<810.);
    }
    #[test]
    fn jump_lands_and_cannot_restart_in_air() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));
        assert!(!c.walk_jump());c.set_walking(true,&terrain).unwrap();
        let ground=c.eye_m();assert!(c.walk_jump());assert!(!c.walk_jump());
        let mut peak:f64=0.;
        for _ in 0..12 {c.update(0.05);c.enforce_terrain_clearance(&terrain);peak=peak.max(c.walk.as_ref().unwrap().jump_height);}
        assert!(peak>1.2 && peak<1.3);assert!(c.eye_m().distance(ground)>1.);
        c.walk_settings(None,Some(true));c.enforce_terrain_clearance(&terrain);
        let w=c.walk.as_ref().unwrap();assert_eq!(c.walk_avatar()[0]["height"].as_f64().unwrap(),w.elevation+w.jump_height);
        assert!(!c.walk_jump());
        for _ in 0..20 {c.update(0.05);c.enforce_terrain_clearance(&terrain);}
        assert_eq!(c.walk.as_ref().unwrap().jump_height,0.);assert!(c.walk_jump());
        c.set_walking(false,&terrain).unwrap();c.set_walking(true,&terrain).unwrap();
        assert_eq!(c.walk.as_ref().unwrap().jump_height,0.);
    }
    #[test]
    fn speed_sprint_and_follow_camera_are_bounded() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));c.set_walking(true,&terrain).unwrap();
        c.walk_settings(Some(30.),None);let first=c.eye_m();c.walk_controls(1.,1.,true);
        for _ in 0..20{c.update(0.05);c.enforce_terrain_clearance(&terrain);}
        assert!((c.eye_m().distance(first)-120.).abs()<0.05);
        c.walk_controls(0.,0.,false);c.walk_settings(None,Some(true));c.enforce_terrain_clearance(&terrain);
        let w=c.walk.as_ref().unwrap();let target=geo::geodetic_position(w.latitude,w.longitude,w.elevation+w.jump_height+1.3);
        assert!((c.eye_m().distance(target)-6.).abs()<0.05);assert!(c.eye_clearance_m()>0.8);
        assert_eq!(c.walk_avatar()[0]["visible"],true);
        c.walk_settings(Some(f64::NAN),Some(false));c.enforce_terrain_clearance(&terrain);assert_eq!(c.walk_status()["speed"],30.);assert_eq!(c.walk_avatar()[0]["visible"],false);
        c.walk_settings(Some(999.),None);assert_eq!(c.walk_status()["speed"],200.);
    }
    #[test]
    fn walk_moves_at_configured_speed_and_restores_orbit() {
        let terrain=TerrainLayer::new();let mut c=OrbitCamera::new(PhysicalSize::new(800,600));
        let original=(c.eye_m(),c.view_projection());
        c.set_walking(true,&terrain).unwrap();let first=c.eye_m();
        assert!((c.eye_clearance_m()-1.7).abs()<0.02);
        let samples=c.visible_surface_samples(16,10);assert!((samples[0].as_dvec3()*SEMI_MAJOR_M-c.eye_m()).length()<3.);
        c.walk_controls(1.,0.,false);for _ in 0..20{c.update(0.05);c.enforce_terrain_clearance(&terrain);}
        assert!((c.eye_m().distance(first)-12.).abs()<0.05);
        c.walk_controls(0.,0.,false);let stopped=c.eye_m();c.update(0.05);c.enforce_terrain_clearance(&terrain);assert!(c.eye_m().distance(stopped)<0.01);
        c.walk_look(30.,20.);assert_ne!(c.view_projection(),original.1);
        c.set_walking(false,&terrain).unwrap();assert!(c.eye_m().distance(original.0)<0.01);assert_eq!(c.view_projection(),original.1);
    }
}
