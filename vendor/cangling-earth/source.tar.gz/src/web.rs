//! Browser entry point. The camera and renderer are shared with desktop;
//! only window startup and the tile/DEM I/O paths are platform-specific.

use std::sync::atomic::{AtomicBool, Ordering};
use std::{cell::RefCell, rc::Rc, sync::Arc};

use wasm_bindgen::{JsValue, prelude::wasm_bindgen};
use wasm_bindgen_futures::spawn_local;
use winit::{
    application::ApplicationHandler,
    dpi::LogicalSize,
    event::WindowEvent,
    event_loop::{ActiveEventLoop, ControlFlow, EventLoop},
    platform::web::{EventLoopExtWebSys, WindowAttributesExtWebSys},
    window::{CursorIcon, Window, WindowAttributes, WindowId},
};

use crate::renderer::{RenderStatus, Renderer};

struct WebApp {
    window: Option<Arc<Window>>,
    renderer: Rc<RefCell<Option<Renderer>>>,
    backend: wgpu::Backends,
    ready_emitted: bool,
}

impl ApplicationHandler for WebApp {
    fn resumed(&mut self, event_loop: &ActiveEventLoop) {
        if self.window.is_some() {
            return;
        }
        let attributes = WindowAttributes::default()
            .with_title("Cangling Earth · Web")
            .with_inner_size(LogicalSize::new(1440, 900))
            .with_append(true)
            .with_prevent_default(true);
        let window = Arc::new(
            event_loop
                .create_window(attributes)
                .expect("create web canvas"),
        );
        let renderer = self.renderer.clone();
        let init_window = window.clone();
        let backend = self.backend;
        spawn_local(async move {
            match Renderer::new_web(init_window.clone(), backend).await {
                Ok(mut value) => {
                    value.resize(init_window.inner_size());
                    *renderer.borrow_mut() = Some(value);
                    init_window.request_redraw();
                }
                Err(error) => {
                    let message = format!("Cangling graphics initialization failed: {error:#}");
                    set_status(Some(&message));
                    web_sys::console::error_1(&JsValue::from_str(&message));
                }
            }
        });
        KEEPER_WINDOW.with(|slot|*slot.borrow_mut()=Some(window.clone()));
        self.window = Some(window);
    }

    fn window_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        window_id: WindowId,
        event: WindowEvent,
    ) {
        let Some(window) = self.window.as_ref() else {
            return;
        };
        if window.id() != window_id {
            return;
        }
        if matches!(event, WindowEvent::CloseRequested) {
            event_loop.exit();
            return;
        }
        let mut renderer = self.renderer.borrow_mut();
        let Some(renderer) = renderer.as_mut() else {
            return;
        };
        renderer.input(&event);
        if matches!(
            event,
            WindowEvent::MouseInput { .. }
                | WindowEvent::MouseWheel { .. }
                | WindowEvent::KeyboardInput { .. }
                | WindowEvent::CursorLeft { .. }
                | WindowEvent::Focused(false)
        ) {
            window.set_cursor(if renderer.is_grabbing_globe() {
                CursorIcon::Grabbing
            } else {
                CursorIcon::Default
            });
        }
        match event {
            WindowEvent::Resized(size) => renderer.resize(size),
            WindowEvent::RedrawRequested => {
                if KEEPER_PAUSED.with(|v|v.get()){return;}
                renderer.update();
                match renderer.render() {
                    RenderStatus::Presented => {
                        if let (Some(w),Ok(event))=(web_sys::window(),web_sys::Event::new("cangling-earth-frame")){let _=w.dispatch_event(&event);}
                        if !self.ready_emitted {
                            self.ready_emitted = true;
                            set_status(None);
                            dispatch_ready();
                        }
                    }
                    RenderStatus::Skipped => {}
                    RenderStatus::Reconfigure => renderer.resize(window.inner_size()),
                }
                window.request_redraw();
            }
            _ => {}
        }
    }

    fn about_to_wait(&mut self, _event_loop: &ActiveEventLoop) {
        if !KEEPER_PAUSED.with(|v|v.get()) && let Some(window) = &self.window {
            window.request_redraw();
        }
    }
}

#[wasm_bindgen]
pub fn start(backend: &str) -> Result<(), JsValue> {
    console_error_panic_hook::set_once();
    let backend = match backend {
        "webgpu" => wgpu::Backends::BROWSER_WEBGPU,
        "webgl2" => wgpu::Backends::GL,
        _ => return Err(JsValue::from_str("backend must be webgpu or webgl2")),
    };
    let event_loop = EventLoop::new().map_err(|error| JsValue::from_str(&error.to_string()))?;
    event_loop.set_control_flow(ControlFlow::Wait);
    let renderer=Rc::new(RefCell::new(None));KEEPER_RENDERER.with(|slot|*slot.borrow_mut()=Some(renderer.clone()));
    event_loop.spawn_app(WebApp {
        window: None,
        renderer,
        backend,
        ready_emitted: false,
    });
    Ok(())
}

fn dispatch_ready() {
    if let Some(window) = web_sys::window()
        && let Ok(event) = web_sys::Event::new("cangling-earth-ready")
    {
        let _ = window.dispatch_event(&event);
    }
}

fn set_status(message: Option<&str>) {
    let element = web_sys::window()
        .and_then(|window| window.document())
        .and_then(|document| document.get_element_by_id("status"));
    if let Some(element) = element {
        if let Some(message) = message {
            element.set_text_content(Some(message));
        } else {
            element.remove();
        }
    }
}

pub(crate) fn report_gpu_error(message: &str) {
    static REPORTED: AtomicBool = AtomicBool::new(false);
    if REPORTED.swap(true, Ordering::Relaxed) {
        return;
    }
    web_sys::console::error_1(&JsValue::from_str(message));
    if let Some(window) = web_sys::window() {
        let _ = js_sys::Reflect::set(
            window.as_ref(),
            &JsValue::from_str("canglingLastGpuError"),
            &JsValue::from_str(message),
        );
        if let Ok(event) = web_sys::Event::new("cangling-gpu-error") {
            let _ = window.dispatch_event(&event);
        }
    }
}

include!("keeper_bridge.rs");
