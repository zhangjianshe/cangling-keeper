struct Viewport {
    size_px: vec2<f32>,
    visibility: f32,
    padding: f32,
};

@group(0) @binding(0) var<uniform> viewport: Viewport;

struct VertexInput {
    @location(0) position_px: vec2<f32>,
    @location(1) depth: f32,
    @location(2) side_px: f32,
    @location(3) opacity: f32,
    @location(4) style: f32,
};

struct VertexOutput {
    @builtin(position) position: vec4<f32>,
    @location(0) side_px: f32,
    @location(1) opacity: f32,
    @location(2) style: f32,
};

@vertex
fn vs_main(input: VertexInput) -> VertexOutput {
    var out: VertexOutput;
    let ndc = vec2<f32>(
        input.position_px.x / viewport.size_px.x * 2.0 - 1.0,
        1.0 - input.position_px.y / viewport.size_px.y * 2.0,
    );
    out.position = vec4<f32>(ndc, input.depth, 1.0);
    out.side_px = input.side_px;
    out.opacity = input.opacity;
    out.style = input.style;
    return out;
}

@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    let distance = abs(input.side_px);
    if (input.style > 1.5) {
        let halo = 1.0 - smoothstep(1.0, 1.5, distance);
        let core = 1.0 - smoothstep(0.35, 1.15, distance);
        let color = mix(vec3<f32>(0.06, 0.08, 0.10), vec3<f32>(1.0, 1.0, 1.0), core);
        return vec4<f32>(color, (0.28 * halo + 0.70 * core) * input.opacity * viewport.visibility);
    }
    if (input.style > 0.5) {
        let outline = 1.0 - smoothstep(0.9, 1.5, distance);
        let core = 1.0 - smoothstep(0.35, 0.9, distance);
        let color = mix(vec3<f32>(0.015, 0.025, 0.045), vec3<f32>(0.91, 0.95, 1.0), core);
        return vec4<f32>(color, (0.2 * outline + 0.8 * core) * input.opacity * viewport.visibility);
    }
    let outline = 1.0 - smoothstep(0.9, 1.5, distance);
    let core = 1.0 - smoothstep(0.35, 0.9, distance);
    let color = mix(vec3<f32>(0.015, 0.025, 0.045), vec3<f32>(0.87, 0.94, 1.0), core);
    return vec4<f32>(color, (0.48 * outline + 0.27 * core) * input.opacity * viewport.visibility);
}
