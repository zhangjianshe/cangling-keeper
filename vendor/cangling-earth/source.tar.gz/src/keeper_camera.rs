// Keeper integration: JSON view state and bounded geographic projection.
impl OrbitCamera {
    pub fn keeper_view(&self) -> serde_json::Value {
        let (lat,lon)=geo::geodetic_lat_lon(self.orientation*DVec3::Z*surface_radius(self.orientation));
        serde_json::json!({"latitude":lat.to_degrees(),"longitude":lon.to_degrees(),"height":self.distance_m-surface_radius(self.orientation),"tilt":self.tilt_radians.to_degrees(),"heading":self.heading_radians.to_degrees()})
    }
    pub fn keeper_set_view(&mut self,v:&serde_json::Value)->Result<(),String>{
        let number=|k:&str,min:f64,max:f64|v[k].as_f64().filter(|n|n.is_finite()&&*n>=min&&*n<=max).ok_or(format!("invalid {k}"));
        let lat=number("latitude",-90.,90.)?;let lon=number("longitude",-180.,180.)?;let height=number("height",20.,100_000_000.)?;
        let tilt=number("tilt",0.,75.)?;let heading=number("heading",-360.,360.)?;
        *self=Self::new(self.viewport);self.orientation=north_up_orientation(lat.to_radians(),lon.to_radians());self.distance_m=surface_radius(self.orientation)+height;self.target_distance_m=self.distance_m;self.tilt_radians=tilt.to_radians();self.heading_radians=heading.to_radians();Ok(())
    }
    pub fn keeper_project(&self,coordinates:&serde_json::Value)->serde_json::Value{
        let eye=self.eye_m();let matrix=self.view_projection();
        serde_json::json!(coordinates.as_array().unwrap().iter().take(10000).map(|c|{
            let lon=c[0].as_f64()?;let lat=c[1].as_f64()?;let height=c[2].as_f64().unwrap_or(0.);
            let p=geo::geodetic_position(lat.to_radians(),lon.to_radians(),height);
            let normal=DVec3::new(p.x/geo::SEMI_MAJOR_M.powi(2),p.y/geo::SEMI_MINOR_M.powi(2),p.z/geo::SEMI_MAJOR_M.powi(2));
            if normal.dot(eye-p)<=0. {return None;}
            let clip=matrix*((p-eye)/geo::SEMI_MAJOR_M).as_vec3().extend(1.);if clip.w<=0. {return None;}let n=clip.truncate()/clip.w;
            Some([(n.x as f64+1.)/2.,(1.-n.y as f64)/2.])
        }).collect::<Vec<_>>())
    }
    pub fn keeper_pick(&self,x:f64,y:f64,terrain:&TerrainLayer)->serde_json::Value{
        let p=self.pick_surface_terrain(DVec2::new(x*self.viewport.width as f64,y*self.viewport.height as f64),terrain);
        p.map(|p|{let(lat,lon)=geo::geodetic_lat_lon(p);serde_json::json!({"longitude":lon.to_degrees(),"latitude":lat.to_degrees(),"height":geo::geodetic_height(p,lat)})}).unwrap_or(serde_json::Value::Null)
    }
}
