//! GPU-native geographic raster overlays, sharing the globe camera and depth buffer.
use crate::{camera::OrbitCamera, geo, terrain::TerrainLayer};
use wgpu::util::DeviceExt;
#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct ImageVertex {
    position: [f32; 3],
    normal: [f32; 3],
    uv: [f32; 2],
}
impl ImageVertex {
    fn layout() -> wgpu::VertexBufferLayout<'static> {
        const A: [wgpu::VertexAttribute; 3] =
            wgpu::vertex_attr_array![0=>Float32x3,1=>Float32x3,2=>Float32x2];
        wgpu::VertexBufferLayout {
            array_stride: 32,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &A,
        }
    }
}
struct Layer {
    id: String,
    visible: bool,
    bounds: [f64; 4],
    vertex: wgpu::Buffer,
    index: wgpu::Buffer,
    _offset: wgpu::Buffer,
    bind: wgpu::BindGroup,
    count: u32,
}
pub struct ImageLayerRenderer {
    pipeline: wgpu::RenderPipeline,
    texture_layout: wgpu::BindGroupLayout,
    layers: Vec<Layer>,
}
fn inside(x: f64, y: f64, p: &[[f64; 2]]) -> bool {
    let mut hit = false;
    let mut j = p.len() - 1;
    for i in 0..p.len() {
        let a = p[i];
        let b = p[j];
        if (a[1] > y) != (b[1] > y) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0] {
            hit = !hit;
        }
        j = i;
    }
    hit
}
impl ImageLayerRenderer {
    pub fn new(
        device: &wgpu::Device,
        surface_format: wgpu::TextureFormat,
        camera_layout: &wgpu::BindGroupLayout,
    ) -> Self {
        let texture_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Geographic image texture layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 2,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
            ],
        });
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("Geographic image shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("image_layer.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("Geographic image pipeline layout"),
            bind_group_layouts: &[Some(camera_layout), Some(&texture_layout)],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("Geographic image pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[Some(ImageVertex::layout())],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: surface_format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                cull_mode: None,
                front_face: wgpu::FrontFace::Ccw,
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: Some(false),
                depth_compare: Some(wgpu::CompareFunction::LessEqual),
                stencil: Default::default(),
                bias: wgpu::DepthBiasState {
                    constant: -2,
                    slope_scale: -2.0,
                    clamp: 0.0,
                },
            }),
            multisample: Default::default(),
            multiview_mask: None,
            cache: None,
        });

        Self {
            pipeline,
            texture_layout,
            layers: Vec::new(),
        }
    }
    pub fn scene(&mut self, values: &serde_json::Value) -> Result<(), String> {
        let list = values
            .as_array()
            .filter(|v| v.len() <= 8)
            .ok_or("invalid image scene")?;
        self.layers
            .retain(|l| list.iter().any(|v| v["id"].as_str() == Some(&l.id)));
        for l in &mut self.layers {
            l.visible = list
                .iter()
                .any(|v| v["id"].as_str() == Some(&l.id) && v["visible"] == true);
        }
        Ok(())
    }
    pub fn upload(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        id: &str,
        bytes: &[u8],
        points: &[[f64; 2]],
    ) -> Result<(), String> {
        if bytes.len() > 4 * 1024 * 1024
            || points.len() < 3
            || points.len() > 32
            || points.iter().any(|p| {
                !p[0].is_finite() || !p[1].is_finite() || p[0].abs() > 180. || p[1].abs() > 90.
            })
        {
            return Err("invalid image input".into());
        }
        if self.layers.len() >= 8 && !self.layers.iter().any(|l| l.id == id) {
            return Err("image layer limit".into());
        }
        let bounds = [
            points.iter().map(|p| p[0]).fold(f64::INFINITY, f64::min),
            points.iter().map(|p| p[1]).fold(f64::INFINITY, f64::min),
            points
                .iter()
                .map(|p| p[0])
                .fold(f64::NEG_INFINITY, f64::max),
            points
                .iter()
                .map(|p| p[1])
                .fold(f64::NEG_INFINITY, f64::max),
        ];
        if bounds[2] <= bounds[0] || bounds[3] <= bounds[1] || bounds[2] - bounds[0] > 180. {
            return Err("invalid image bounds".into());
        }
        let reader = image::ImageReader::new(std::io::Cursor::new(bytes))
            .with_guessed_format()
            .map_err(|e| e.to_string())?;
        let (w, h) = reader.into_dimensions().map_err(|e| e.to_string())?;
        if w > 8192 || h > 8192 || u64::from(w) * u64::from(h) > 24_000_000 {
            return Err("image dimensions exceed limit".into());
        }
        let mut image = image::load_from_memory(bytes)
            .map_err(|e| e.to_string())?
            .thumbnail(2048, 2048)
            .to_rgba8();
        let (w, h) = image.dimensions();
        for (x, y, pixel) in image.enumerate_pixels_mut() {
            let lon = bounds[0] + (bounds[2] - bounds[0]) * (x as f64 + 0.5) / w as f64;
            let lat = bounds[3] - (bounds[3] - bounds[1]) * (y as f64 + 0.5) / h as f64;
            if !inside(lon, lat, points) {
                pixel[3] = 0;
            }
        }
        let texture = device.create_texture_with_data(
            queue,
            &wgpu::TextureDescriptor {
                label: Some("Geographic image"),
                size: wgpu::Extent3d {
                    width: w,
                    height: h,
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: wgpu::TextureFormat::Rgba8UnormSrgb,
                usage: wgpu::TextureUsages::TEXTURE_BINDING,
                view_formats: &[],
            },
            wgpu::util::TextureDataOrder::LayerMajor,
            image.as_raw(),
        );
        let view = texture.create_view(&Default::default());
        let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            ..Default::default()
        });
        let offset = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: None,
            contents: bytemuck::cast_slice(&[0f32; 4]),
            usage: wgpu::BufferUsages::UNIFORM,
        });
        let bind = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &self.texture_layout,
            entries: &[
                wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::TextureView(&view),
                },
                wgpu::BindGroupEntry {
                    binding: 1,
                    resource: wgpu::BindingResource::Sampler(&sampler),
                },
                wgpu::BindGroupEntry {
                    binding: 2,
                    resource: offset.as_entire_binding(),
                },
            ],
        });
        let mut indices = Vec::<u32>::new();
        for y in 0..64 {
            for x in 0..64 {
                let a = y * 65 + x;
                indices.extend_from_slice(&[a, a + 1, a + 66, a, a + 66, a + 65]);
            }
        }
        let vertex = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Geographic image mesh"),
            size: 65 * 65 * 32,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let index = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: None,
            contents: bytemuck::cast_slice(&indices),
            usage: wgpu::BufferUsages::INDEX,
        });
        self.layers.retain(|l| l.id != id);
        self.layers.push(Layer {
            id: id.into(),
            visible: true,
            bounds,
            vertex,
            index,
            _offset: offset,
            bind,
            count: indices.len() as u32,
        });
        Ok(())
    }
    pub fn update(&self, queue: &wgpu::Queue, camera: &OrbitCamera, terrain: &TerrainLayer) {
        for l in self.layers.iter().filter(|l| l.visible) {
            let mut vertices = Vec::with_capacity(65 * 65);
            for y in 0..=64 {
                for x in 0..=64 {
                    let u = x as f64 / 64.;
                    let v = y as f64 / 64.;
                    let lon = (l.bounds[0] + (l.bounds[2] - l.bounds[0]) * u).to_radians();
                    let lat = (l.bounds[3] - (l.bounds[3] - l.bounds[1]) * v).to_radians();
                    let p = geo::geodetic_position(lat, lon, terrain.sample(lat, lon) + 1.);
                    vertices.push(ImageVertex {
                        position: ((p - camera.eye_m()) / geo::SEMI_MAJOR_M)
                            .as_vec3()
                            .to_array(),
                        normal: [0.; 3],
                        uv: [u as f32, v as f32],
                    });
                }
            }
            queue.write_buffer(&l.vertex, 0, bytemuck::cast_slice(&vertices));
        }
    }
    pub fn draw<'a>(&'a self, pass: &mut wgpu::RenderPass<'a>, camera: &'a wgpu::BindGroup) {
        pass.set_pipeline(&self.pipeline);
        pass.set_bind_group(0, camera, &[]);
        for l in self.layers.iter().filter(|l| l.visible) {
            pass.set_bind_group(1, &l.bind, &[]);
            pass.set_vertex_buffer(0, l.vertex.slice(..));
            pass.set_index_buffer(l.index.slice(..), wgpu::IndexFormat::Uint32);
            pass.draw_indexed(0..l.count, 0, 0..1);
        }
    }
}
#[cfg(test)]
mod tests {
    #[test]
    fn polygon_mask() {
        let p = [[0., 0.], [2., 0.], [2., 2.], [1., 1.], [0., 2.]];
        assert!(super::inside(1., 0.5, &p));
        assert!(!super::inside(1., 1.5, &p));
        assert!(!super::inside(3., 1., &p));
    }
    #[test]
    fn shader_valid() {
        let m = naga::front::wgsl::parse_str(include_str!("image_layer.wgsl")).unwrap();
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&m)
        .unwrap();
    }
}

#[cfg(all(test, not(target_arch = "wasm32")))]
mod gpu_test {
    #[test]
    fn upload_native_layer() {
        pollster::block_on(async {
            let instance = wgpu::Instance::default();
            let adapter = instance
                .request_adapter(&wgpu::RequestAdapterOptions::default())
                .await
                .expect("GPU adapter");
            let (device, queue) = adapter
                .request_device(&wgpu::DeviceDescriptor::default())
                .await
                .unwrap();
            let layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::VERTEX,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                }],
            });
            let mut renderer =
                super::ImageLayerRenderer::new(&device, wgpu::TextureFormat::Rgba8Unorm, &layout);
            let mut bytes = std::io::Cursor::new(Vec::new());
            image::DynamicImage::new_rgba8(16, 16)
                .write_to(&mut bytes, image::ImageFormat::Png)
                .unwrap();
            renderer
                .upload(
                    &device,
                    &queue,
                    "test",
                    bytes.get_ref(),
                    &[[0., 0.], [1., 0.], [1., 1.], [0., 1.]],
                )
                .unwrap();
            assert_eq!(renderer.layers.len(), 1);
            renderer
                .scene(&serde_json::json!([{"id":"test","visible":false}]))
                .unwrap();
            assert!(!renderer.layers[0].visible);
            renderer.scene(&serde_json::json!([])).unwrap();
            assert!(renderer.layers.is_empty());
        });
    }
}
