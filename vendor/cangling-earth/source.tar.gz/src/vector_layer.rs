//! Native vector meshes. Geodetic coordinates are converted to WGS84 ECEF,
//! sampled on terrain, then expanded to constant-pixel-width GPU triangles.
use crate::{camera::OrbitCamera, geo, terrain::TerrainLayer};
use glam::{DVec3, Vec2, Vec4};
use serde_json::{Value, json};
use wgpu::util::DeviceExt;
const MAX_VERTICES: usize = 300000;
#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct Vertex {
    position: [f32; 4],
}
impl Vertex {
    fn layout() -> wgpu::VertexBufferLayout<'static> {
        const A: [wgpu::VertexAttribute; 1] = wgpu::vertex_attr_array![0=>Float32x4];
        wgpu::VertexBufferLayout {
            array_stride: 16,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &A,
        }
    }
}
struct Part {
    extent_m: f64,
    points: Vec<[f64; 3]>,
    feature: Value,
}
struct Hit {
    a: Vec2,
    b: Vec2,
    feature: Value,
}
pub struct VectorLayerRenderer {
    pipeline: wgpu::RenderPipeline,
    buffer: wgpu::Buffer,
    count: u32,
    parts: Vec<Part>,
    hits: Vec<Hit>,
    scene: Value,
}
fn coordinate(v: &Value) -> Result<[f64; 3], String> {
    let a = v
        .as_array()
        .filter(|a| a.len() >= 2)
        .ok_or("invalid coordinate")?;
    let x = a[0]
        .as_f64()
        .filter(|x| x.is_finite() && x.abs() <= 180.)
        .ok_or("invalid longitude")?;
    let y = a[1]
        .as_f64()
        .filter(|y| y.is_finite() && y.abs() <= 90.)
        .ok_or("invalid latitude")?;
    let z = if a.len() > 2 {
        a[2].as_f64()
            .filter(|z| z.is_finite() && z.abs() <= 100000.)
            .ok_or("invalid altitude")?
    } else {
        f64::NAN
    };
    Ok([x, y, z])
}
fn parts(g: &Value) -> Result<Vec<Vec<[f64; 3]>>, String> {
    let c = &g["coordinates"];
    let line = |c: &Value| -> Result<Vec<[f64; 3]>, String> {
        c.as_array()
            .ok_or("invalid coordinates")?
            .iter()
            .map(coordinate)
            .collect()
    };
    match g["type"].as_str() {
        Some("Point") => Ok(vec![vec![coordinate(c)?]]),
        Some("MultiPoint") => Ok(line(c)?.into_iter().map(|p| vec![p]).collect()),
        Some("LineString") => Ok(vec![line(c)?]),
        Some("Polygon" | "MultiLineString") => c
            .as_array()
            .ok_or("invalid rings")?
            .iter()
            .map(line)
            .collect(),
        Some("MultiPolygon") => {
            let mut out = Vec::new();
            for p in c.as_array().ok_or("invalid polygons")? {
                for r in p.as_array().ok_or("invalid rings")? {
                    out.push(line(r)?);
                }
            }
            Ok(out)
        }
        _ => Err("unsupported geometry".into()),
    }
}
// Metre-based tessellation: close views sample terrain every 5 metres.
fn segment_count(a: [f64; 3], b: [f64; 3], step: f64) -> usize {
    let lat1 = a[1].to_radians();
    let lat2 = b[1].to_radians();
    let dl = ((b[0] - a[0] + 180.).rem_euclid(360.) - 180.).to_radians();
    let h = ((lat2 - lat1) / 2.).sin().powi(2) + lat1.cos() * lat2.cos() * (dl / 2.).sin().powi(2);
    ((2. * geo::SEMI_MAJOR_M * h.clamp(0., 1.).sqrt().asin() / step).ceil() as usize).clamp(1, 8192)
}
fn interpolate(a: [f64; 3], b: [f64; 3], t: f64) -> [f64; 3] {
    let dx = (b[0] - a[0] + 180.).rem_euclid(360.) - 180.;
    [
        (a[0] + dx * t + 180.).rem_euclid(360.) - 180.,
        a[1] + (b[1] - a[1]) * t,
        a[2] + (b[2] - a[2]) * t,
    ]
}
// ECEF bounds avoid the 359-degree extent problem at the antimeridian.
fn extent_metres(points: &[[f64; 3]]) -> f64 {
    if points.is_empty() {
        return 0.;
    }
    let mut min = DVec3::splat(f64::INFINITY);
    let mut max = DVec3::splat(f64::NEG_INFINITY);
    for p in points {
        let xyz = geo::geodetic_position(p[1].to_radians(), p[0].to_radians(), 0.);
        min = min.min(xyz);
        max = max.max(xyz);
    }
    (max - min).length()
}
fn adaptive_step(extent: f64, altitude: f64, height: u32) -> f64 {
    // About 256 subdivisions across the feature; zooming closer refines it.
    (extent / 256.)
        .min(altitude / f64::from(height.max(1)))
        .clamp(1., 5000.)
}
fn surface_position(p: [f64; 3], sample: impl Fn(f64, f64) -> f64) -> DVec3 {
    let lat = p[1].to_radians();
    let lon = p[0].to_radians();
    let height = if p[2].is_finite() {
        p[2]
    } else {
        sample(lat, lon)
    };
    geo::geodetic_position(lat, lon, height + 2.)
}
impl VectorLayerRenderer {
    pub fn new(device: &wgpu::Device, format: wgpu::TextureFormat) -> Self {
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("native GeoJSON"),
            source: wgpu::ShaderSource::Wgsl(include_str!("vector_layer.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: None,
            bind_group_layouts: &[],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("antialiased latitude longitude grid"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[Some(Vertex::layout())],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                cull_mode: None,
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: Some(false),
                depth_compare: Some(wgpu::CompareFunction::LessEqual),
                stencil: Default::default(),
                bias: wgpu::DepthBiasState {
                    constant: -2,
                    slope_scale: -2.0,
                    clamp: 0.0,
                },
            }),
            multisample: Default::default(),
            multiview_mask: None,
            cache: None,
        });

        let buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("GeoJSON triangles"),
            contents: &vec![0; MAX_VERTICES * 16],
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
        });
        Self {
            pipeline,
            buffer,
            count: 0,
            parts: Vec::new(),
            hits: Vec::new(),
            scene: Value::Null,
        }
    }
    pub fn scene(&mut self, layers: &Value) -> Result<(), String> {
        if self.scene == *layers {
            return Ok(());
        }
        let mut out = Vec::new();
        let mut total = 0;
        for l in layers
            .as_array()
            .filter(|l| l.len() <= 32)
            .ok_or("invalid vector layers")?
        {
            if l["visible"] != true {
                continue;
            }
            let data = &l["data"];
            let features = if data["type"] == "FeatureCollection" {
                data["features"]
                    .as_array()
                    .ok_or("invalid features")?
                    .clone()
            } else {
                vec![data.clone()]
            };
            for (index, f) in features.iter().enumerate() {
                let g = if f["type"] == "Feature" {
                    &f["geometry"]
                } else {
                    f
                };
                for points in parts(g)? {
                    total += points.len();
                    if total > 20000 {
                        return Err("vector coordinate limit".into());
                    }
                    out.push(Part{extent_m:extent_metres(&points),points,feature:json!({"layer":l["path"],"feature":index,"properties":f["properties"]})});
                }
            }
        }
        let estimated: usize = out
            .iter()
            .map(|p| {
                if p.points.len() == 1 {
                    36
                } else {
                    p.points.len().saturating_sub(1) * 6
                }
            })
            .sum();
        if estimated > MAX_VERTICES {
            return Err("GeoJSON mesh limit exceeded; simplify or split the data".into());
        }
        self.parts = out;
        self.hits.clear();
        self.count = 0;
        self.scene = layers.clone();
        Ok(())
    }
    pub fn update(
        &mut self,
        queue: &wgpu::Queue,
        camera: &OrbitCamera,
        terrain: &TerrainLayer,
        width: u32,
        height: u32,
    ) {
        let size = Vec2::new(width as f32, height as f32);
        let eye = camera.eye_m();
        let matrix = camera.view_projection();
        let project = |p: [f64; 3]| -> Option<Vec4> {
            let world = surface_position(p, |lat, lon| terrain.sample(lat, lon));
            let normal = DVec3::new(
                world.x / geo::SEMI_MAJOR_M.powi(2),
                world.y / geo::SEMI_MINOR_M.powi(2),
                world.z / geo::SEMI_MAJOR_M.powi(2),
            );
            if normal.dot(eye - world) <= 0. {
                return None;
            }
            let clip = matrix * ((world - eye) / geo::SEMI_MAJOR_M).as_vec3().extend(1.);
            (clip.w > 0. && clip.z >= 0. && clip.z <= clip.w).then_some(clip)
        };
        let screen = |p: Vec4| {
            Vec2::new(
                (p.x / p.w + 1.) * 0.5 * size.x,
                (1. - p.y / p.w) * 0.5 * size.y,
            )
        };
        let offset = |mut p: Vec4, d: Vec2| {
            p.x += d.x / size.x * 2. * p.w;
            p.y -= d.y / size.y * 2. * p.w;
            Vertex {
                position: p.to_array(),
            }
        };
        let altitude = camera.keeper_view()["height"].as_f64().unwrap_or(1000000.);

        let point_cost = self.parts.iter().filter(|p| p.points.len() == 1).count() * 36;
        let edges = self
            .parts
            .iter()
            .map(|p| p.points.len().saturating_sub(1))
            .sum::<usize>();
        let extra_budget = (MAX_VERTICES - point_cost) / 6 - edges;
        let desired_extra = self
            .parts
            .iter()
            .flat_map(|part| {
                let step = adaptive_step(part.extent_m, altitude, height);
                part.points
                    .windows(2)
                    .map(move |p| segment_count(p[0], p[1], step) - 1)
            })
            .sum::<usize>();
        let scale = if desired_extra == 0 {
            1.
        } else {
            (extra_budget as f64 / desired_extra as f64).min(1.)
        };
        let mut vertices = Vec::new();
        self.hits.clear();
        for part in &self.parts {
            let step = adaptive_step(part.extent_m, altitude, height);
            if part.points.len() == 1 {
                if let Some(p) = project(part.points[0]) {
                    for i in 0..12 {
                        let a = i as f32 * std::f32::consts::TAU / 12.;
                        let b = (i + 1) as f32 * std::f32::consts::TAU / 12.;
                        vertices.extend_from_slice(&[
                            offset(p, Vec2::ZERO),
                            offset(p, Vec2::new(a.cos(), a.sin()) * 6.),
                            offset(p, Vec2::new(b.cos(), b.sin()) * 6.),
                        ]);
                    }
                    self.hits.push(Hit {
                        a: screen(p),
                        b: screen(p),
                        feature: part.feature.clone(),
                    });
                }
            } else {
                for pair in part.points.windows(2) {
                    let a = pair[0];
                    let b = pair[1];
                    let n = 1 + ((segment_count(a, b, step) - 1) as f64 * scale).floor() as usize;
                    for i in 0..n {
                        if vertices.len() + 6 > MAX_VERTICES {
                            break;
                        }
                        let point = |i: usize| interpolate(a, b, i as f64 / n as f64);
                        if let (Some(p), Some(q)) = (project(point(i)), project(point(i + 1))) {
                            let u = screen(p);
                            let v = screen(q);
                            let d = v - u;
                            if d.length_squared() < 0.001 {
                                continue;
                            }
                            let normal = Vec2::new(-d.y, d.x).normalize() * 1.5;
                            vertices.extend_from_slice(&[
                                offset(p, normal),
                                offset(p, -normal),
                                offset(q, normal),
                                offset(q, normal),
                                offset(p, -normal),
                                offset(q, -normal),
                            ]);
                            self.hits.push(Hit {
                                a: u,
                                b: v,
                                feature: part.feature.clone(),
                            });
                        }
                    }
                }
            }
            if vertices.len() + 36 > MAX_VERTICES {
                break;
            }
        }
        self.count = vertices.len() as u32;
        if !vertices.is_empty() {
            queue.write_buffer(&self.buffer, 0, bytemuck::cast_slice(&vertices));
        }
    }
    pub fn pick(&self, x: f32, y: f32) -> Value {
        let p = Vec2::new(x, y);
        self.hits
            .iter()
            .rev()
            .find(|h| {
                let d = h.b - h.a;
                let t = if d.length_squared() > 0. {
                    ((p - h.a).dot(d) / d.length_squared()).clamp(0., 1.)
                } else {
                    0.
                };
                p.distance(h.a + d * t) < 8.
            })
            .map(|h| h.feature.clone())
            .unwrap_or(Value::Null)
    }
    pub fn draw<'a>(&'a self, pass: &mut wgpu::RenderPass<'a>) {
        if self.count == 0 {
            return;
        }
        pass.set_pipeline(&self.pipeline);
        pass.set_vertex_buffer(0, self.buffer.slice(..));
        pass.draw(0..self.count, 0..1);
    }
}
#[cfg(test)]
mod tests {
    #[test]
    fn geometry() {
        use serde_json::json;
        assert_eq!(
            super::parts(&json!({"type":"MultiPoint","coordinates":[[1,2],[3,4]]}))
                .unwrap()
                .len(),
            2
        );
        assert_eq!(
            super::parts(&json!({"type":"Polygon","coordinates":[[[0,0],[1,0],[0,0]]]})).unwrap()
                [0]
            .len(),
            3
        );
        assert!(super::coordinate(&json!([200, 0])).is_err());
    }
    #[test]
    fn shader() {
        let m = naga::front::wgsl::parse_str(include_str!("vector_layer.wgsl")).unwrap();
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&m)
        .unwrap();
    }
}

#[cfg(all(test, not(target_arch = "wasm32")))]
mod gpu_tests {
    #[test]
    fn mesh_and_pick() {
        pollster::block_on(async {
            let instance = wgpu::Instance::default();
            let adapter = instance
                .request_adapter(&wgpu::RequestAdapterOptions::default())
                .await
                .expect("GPU adapter");
            let (device, queue) = adapter
                .request_device(&wgpu::DeviceDescriptor::default())
                .await
                .unwrap();
            let mut renderer =
                super::VectorLayerRenderer::new(&device, wgpu::TextureFormat::Rgba8Unorm);
            let mut camera =
                crate::camera::OrbitCamera::new(winit::dpi::PhysicalSize::new(800, 600));
            camera.keeper_set_view(&serde_json::json!({"longitude":0,"latitude":0,"height":1000000,"heading":0,"tilt":0})).unwrap();
            let terrain = crate::terrain::TerrainLayer::new();
            renderer.scene(&serde_json::json!([{"path":"demo.geojson","visible":true,"data":{"type":"Feature","properties":{"name":"point"},"geometry":{"type":"Point","coordinates":[0,0]}}}])).unwrap();
            renderer.update(&queue, &camera, &terrain, 800, 600);
            assert_eq!(renderer.count, 36);
            assert_eq!(renderer.pick(400., 300.)["properties"]["name"], "point");
            let target = |format, usage| {
                device
                    .create_texture(&wgpu::TextureDescriptor {
                        label: None,
                        size: wgpu::Extent3d {
                            width: 800,
                            height: 600,
                            depth_or_array_layers: 1,
                        },
                        mip_level_count: 1,
                        sample_count: 1,
                        dimension: wgpu::TextureDimension::D2,
                        format,
                        usage,
                        view_formats: &[],
                    })
                    .create_view(&Default::default())
            };
            let color = target(
                wgpu::TextureFormat::Rgba8Unorm,
                wgpu::TextureUsages::RENDER_ATTACHMENT,
            );
            let depth = target(
                wgpu::TextureFormat::Depth32Float,
                wgpu::TextureUsages::RENDER_ATTACHMENT,
            );
            let mut encoder = device.create_command_encoder(&Default::default());
            {
                let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                    label: None,
                    color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                        view: &color,
                        resolve_target: None,
                        depth_slice: None,
                        ops: wgpu::Operations {
                            load: wgpu::LoadOp::Clear(wgpu::Color::BLACK),
                            store: wgpu::StoreOp::Store,
                        },
                    })],
                    depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                        view: &depth,
                        depth_ops: Some(wgpu::Operations {
                            load: wgpu::LoadOp::Clear(1.),
                            store: wgpu::StoreOp::Store,
                        }),
                        stencil_ops: None,
                    }),
                    timestamp_writes: None,
                    occlusion_query_set: None,
                    multiview_mask: None,
                });
                renderer.draw(&mut pass);
            }
            queue.submit(Some(encoder.finish()));
            renderer.scene(&serde_json::json!([])).unwrap();
            renderer.update(&queue, &camera, &terrain, 800, 600);
            assert_eq!(renderer.count, 0);
            assert!(renderer.pick(400., 300.).is_null());
        });
    }
}

#[cfg(test)]
mod terrain_drape_tests {
    #[test]
    fn kilometre_edge_samples_middle_hill() {
        let a = [111.64, 32.75, f64::NAN];
        let b = [111.65, 32.75, f64::NAN];
        let n = super::segment_count(a, b, 5.);
        assert!(n > 180);
        let p = super::interpolate(a, b, 0.5);
        let world = super::surface_position(p, |_, lon| {
            if (lon.to_degrees() - 111.645).abs() < 0.001 {
                300.
            } else {
                0.
            }
        });
        let (lat, _) = crate::geo::geodetic_lat_lon(world);
        assert!((crate::geo::geodetic_height(world, lat) - 302.).abs() < 0.001);
    }
    #[test]
    fn finer_view_and_dateline() {
        let a = [179.999, 0., f64::NAN];
        let b = [-179.999, 0., f64::NAN];
        assert!(super::segment_count(a, b, 5.) < 50);
        assert!(super::segment_count(a, b, 5.) > super::segment_count(a, b, 50.));
    }
    #[test]
    fn explicit_altitude_preserved() {
        let p = [0., 0., 100.];
        let world = super::surface_position(p, |_, _| 900.);
        assert!((world.length() - crate::geo::SEMI_MAJOR_M - 102.).abs() < 0.001);
    }
}

#[cfg(test)]
mod adaptive_tests {
    #[test]
    fn scale_and_zoom() {
        assert_eq!(super::adaptive_step(256., 1e6, 1000), 1.);
        assert_eq!(super::adaptive_step(2560., 1e6, 1000), 10.);
        assert_eq!(super::adaptive_step(256000., 1e6, 1000), 1000.);
        assert_eq!(super::adaptive_step(256000., 3000., 1000), 3.);
        assert_eq!(super::adaptive_step(1e9, 1e9, 1000), 5000.);
    }
    #[test]
    fn bounds_across_dateline() {
        let extent = super::extent_metres(&[[179.999, 0., 0.], [-179.999, 0., 0.]]);
        assert!(extent > 220. && extent < 224.);
        assert!(super::adaptive_step(extent, 1e6, 1000) <= 1.);
    }
}
