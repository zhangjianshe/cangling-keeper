//! Natural Earth place names served as small XYZ JSON tiles by cangling-map.
//! Fetching never blocks the render loop; both platforms share selection,
//! projection and screen-space collision rules.

use std::collections::{HashMap, HashSet};

#[cfg(not(target_arch = "wasm32"))]
use std::{fs, path::PathBuf, thread, time::Duration};

use anyhow::{Context, Result};
use crossbeam_channel::{Receiver, Sender, unbounded};
use glam::{DVec3, Mat4, Vec2, Vec3, Vec4};
use serde::Deserialize;
#[cfg(target_arch = "wasm32")]
use wasm_bindgen_futures::spawn_local;

use crate::{
    camera::OrbitCamera,
    geo,
    terrain::TerrainLayer,
    tile::{TileKey, surface_to_tile},
};

const API_ROOT: &str = "https://agri.cangling.cn:22002/cangling-map/api/placenames/tiles";
const MAX_LABEL_ZOOM: u8 = 9; // Natural Earth source has no min_zoom above 9.
// The label mode follows the apparent globe size, not imagery XYZ zoom. XYZ
// zoom changes with latitude even when the camera distance is unchanged.
const COUNTRY_MODE_EXIT_RADIUS: f64 = 2.35;
const COUNTRY_MODE_ENTER_RADIUS: f64 = 2.60;
const COUNTRY_SOURCE_ZOOM: f64 = 4.0;
const MAX_COUNTRY_LABELS: usize = 28;
const MAX_PENDING: usize = 8;
const MAX_RESIDENT: usize = 1024;
const MAX_DESIRED: usize = 512;
const MAX_LABELS: usize = 60;
const RETRY_FRAMES: u64 = 600;

#[derive(Clone, Debug, Deserialize)]
pub(crate) struct Place {
    pub(crate) id: i64,
    pub(crate) name: String,
    pub(crate) longitude: f64,
    pub(crate) latitude: f64,
    pub(crate) label_rank: i64,
    pub(crate) min_zoom: f64,
    #[serde(default)]
    pub(crate) population: Option<i64>,
}

#[derive(Deserialize)]
struct PlaceTile {
    features: Vec<Place>,
}

#[derive(Deserialize)]
struct CountryData {
    countries: Vec<Place>,
}

struct TileResult {
    key: TileKey,
    result: Result<PlaceTile>,
}

struct ResidentTile {
    features: Vec<Place>,
    last_used: u64,
}

#[derive(Clone, Copy, PartialEq)]
struct LabelViewState {
    eye_m: DVec3,
    projection: Mat4,
    zoom: u8,
    country_mode: bool,
    viewport: (u32, u32),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum LabelKind {
    Country,
    City,
    Province,
    Region,
    Township,
}

#[derive(Clone, Debug)]
pub struct PlaceLabel {
    pub text: String,
    /// Country and administrative labels store their centre here; city labels store the left edge.
    pub position: Vec2,
    pub kind: LabelKind,
}

pub struct PlaceNames {
    countries: Vec<Place>,
    country_mode: bool,
    loaded: HashMap<TileKey, ResidentTile>,
    pending: HashSet<TileKey>,
    retry_after: HashMap<TileKey, u64>,
    result_rx: Receiver<TileResult>,
    #[cfg(target_arch = "wasm32")]
    result_tx: Sender<TileResult>,
    #[cfg(not(target_arch = "wasm32"))]
    request_tx: Sender<TileKey>,
    candidates: Vec<Place>,
    candidate_zoom: Option<u8>,
    candidates_dirty: bool,
    labels: Vec<PlaceLabel>,
    frame: u64,
    last_view_state: Option<LabelViewState>,
}

impl PlaceNames {
    pub fn new() -> Self {
        let (result_tx, result_rx) = unbounded();
        #[cfg(not(target_arch = "wasm32"))]
        let request_tx = {
            let (request_tx, request_rx) = unbounded();
            let client = reqwest::blocking::Client::builder()
                .connect_timeout(Duration::from_secs(3))
                .timeout(Duration::from_secs(10))
                .user_agent("cangling-desktop/0.1 places")
                .build()
                .expect("create place-name HTTP client");
            for worker in 0..3 {
                let requests = request_rx.clone();
                let results = result_tx.clone();
                let client = client.clone();
                thread::Builder::new()
                    .name(format!("place-names-{worker}"))
                    .spawn(move || {
                        for key in requests {
                            let result = load_native(&client, key);
                            if results.send(TileResult { key, result }).is_err() {
                                break;
                            }
                        }
                    })
                    .expect("start place-name worker");
            }
            request_tx
        };
        Self {
            countries: serde_json::from_str::<CountryData>(include_str!(
                "../assets/countries-zh.json"
            ))
            .expect("decode embedded Natural Earth country labels")
            .countries,
            country_mode: true,
            loaded: HashMap::new(),
            pending: HashSet::new(),
            retry_after: HashMap::new(),
            result_rx,
            #[cfg(target_arch = "wasm32")]
            result_tx,
            #[cfg(not(target_arch = "wasm32"))]
            request_tx,
            candidates: Vec::new(),
            candidate_zoom: None,
            candidates_dirty: true,
            labels: Vec::new(),
            frame: 0,
            last_view_state: None,
        }
    }

    pub fn labels(&self) -> &[PlaceLabel] {
        &self.labels
    }

    pub fn is_country_mode(&self) -> bool {
        self.country_mode
    }

    pub fn update(
        &mut self,
        camera: &OrbitCamera,
        terrain: &TerrainLayer,
        visible_samples: &[Vec3],
        image_zoom: u8,
        viewport: (u32, u32),
        terrain_changed: bool,
    ) {
        self.frame += 1;
        while let Ok(message) = self.result_rx.try_recv() {
            self.pending.remove(&message.key);
            match message.result {
                Ok(tile) => {
                    self.retry_after.remove(&message.key);
                    self.candidates_dirty = true;
                    self.loaded.insert(
                        message.key,
                        ResidentTile {
                            features: tile.features,
                            last_used: self.frame,
                        },
                    );
                }
                Err(error) => {
                    log::warn!("place-name tile {:?} failed: {error:#}", message.key);
                    self.retry_after
                        .insert(message.key, self.frame + RETRY_FRAMES);
                }
            }
        }

        let zoom = image_zoom.min(MAX_LABEL_ZOOM);
        self.country_mode = country_mode_at_distance(
            self.country_mode,
            camera.eye_m().length() / geo::SEMI_MAJOR_M,
        );
        if !self.country_mode {
            let desired = visible_tile_keys(visible_samples, zoom);
            for &key in &desired {
                if let Some(tile) = self.loaded.get_mut(&key) {
                    tile.last_used = self.frame;
                } else if !self.pending.contains(&key)
                    && self.pending.len() < MAX_PENDING
                    && self
                        .retry_after
                        .get(&key)
                        .is_none_or(|&until| until <= self.frame)
                {
                    self.pending.insert(key);
                    self.request(key);
                }
            }
        }
        if self.loaded.len() > MAX_RESIDENT {
            let mut oldest: Vec<_> = self
                .loaded
                .iter()
                .map(|(&key, tile)| (key, tile.last_used))
                .collect();
            oldest.sort_by_key(|(_, used)| *used);
            for (key, _) in oldest.into_iter().take(self.loaded.len() - MAX_RESIDENT) {
                self.loaded.remove(&key);
            }
            self.candidates_dirty = true;
        }
        let candidates_changed = self.candidates_dirty || self.candidate_zoom != Some(zoom);
        if candidates_changed {
            self.candidates = collect_candidates(&self.loaded, zoom);
            self.candidate_zoom = Some(zoom);
            self.candidates_dirty = false;
        }
        let view_state = LabelViewState {
            eye_m: camera.eye_m(),
            projection: camera.view_projection(),
            zoom,
            country_mode: self.country_mode,
            viewport,
        };
        if candidates_changed || terrain_changed || self.last_view_state != Some(view_state) {
            self.build_labels(camera, terrain, viewport);
            self.last_view_state = Some(view_state);
        }
    }

    fn request(&self, key: TileKey) {
        #[cfg(not(target_arch = "wasm32"))]
        if self.request_tx.send(key).is_err() {
            log::warn!("place-name workers have stopped");
        }
        #[cfg(target_arch = "wasm32")]
        {
            let tx = self.result_tx.clone();
            spawn_local(async move {
                let result =
                    crate::web_cache::fetch_bytes(&tile_url(key), "cangling-placenames-v1")
                        .await
                        .and_then(|(bytes, _)| parse_tile(&bytes));
                let _ = tx.send(TileResult { key, result });
            });
        }
    }

    fn build_labels(
        &mut self,
        camera: &OrbitCamera,
        terrain: &TerrainLayer,
        (width, height): (u32, u32),
    ) {
        // A loaded tile remains a source of labels as long as its places are
        // on screen. Screen-ray samples only schedule downloads; using them
        // to *filter* labels made entire cities blink during a tiny pan.
        self.labels.clear();
        let mut occupied = Vec::new();
        if self.country_mode {
            for country in &self.countries {
                if country.min_zoom > COUNTRY_SOURCE_ZOOM || self.labels.len() >= MAX_COUNTRY_LABELS
                {
                    continue;
                }
                push_label(
                    &mut self.labels,
                    &mut occupied,
                    camera,
                    terrain,
                    country,
                    LabelKind::Country,
                    (width, height),
                );
            }
            return;
        }
        for place in &self.candidates {
            if self.labels.len() >= MAX_LABELS {
                break;
            }
            push_label(
                &mut self.labels,
                &mut occupied,
                camera,
                terrain,
                place,
                LabelKind::City,
                (width, height),
            );
        }
    }
}

fn country_mode_at_distance(current: bool, eye_radius_earths: f64) -> bool {
    if current {
        eye_radius_earths >= COUNTRY_MODE_EXIT_RADIUS
    } else {
        eye_radius_earths >= COUNTRY_MODE_ENTER_RADIUS
    }
}

pub(crate) fn push_label(
    labels: &mut Vec<PlaceLabel>,
    occupied: &mut Vec<[f32; 4]>,
    camera: &OrbitCamera,
    terrain: &TerrainLayer,
    place: &Place,
    kind: LabelKind,
    (width, height): (u32, u32),
) {
    let Some(point) = project_place(camera, terrain, place, width, height) else {
        return;
    };
    let character_width = if kind == LabelKind::Country {
        22.0
    } else {
        17.0
    };
    let label_width = place
        .name
        .chars()
        .map(|ch| {
            if ch.is_ascii() {
                character_width * 0.55
            } else {
                character_width
            }
        })
        .sum::<f32>()
        .min(300.0);
    let centered = matches!(
        kind,
        LabelKind::Country | LabelKind::Province | LabelKind::Region | LabelKind::Township
    );
    let left = if centered {
        point.x - label_width * 0.5
    } else {
        point.x + 7.0
    };
    let top = point.y
        - if kind == LabelKind::Country {
            15.0
        } else {
            12.0
        };
    let bounds = [
        left - 4.0,
        top - 3.0,
        left + label_width + 5.0,
        top + if kind == LabelKind::Country {
            29.0
        } else {
            23.0
        },
    ];
    if bounds[0] < 8.0
        || bounds[2] > width as f32 - 8.0
        || bounds[1] < 72.0
        || bounds[3] > height as f32 - 30.0
    {
        return;
    }
    // Keep the permanent navigation controls and readouts readable.
    if bounds[2] > width as f32 - 540.0 && bounds[3] > height as f32 - 105.0 {
        return;
    }
    if occupied.iter().any(|other| overlaps(bounds, *other)) {
        return;
    }
    occupied.push(bounds);
    labels.push(PlaceLabel {
        text: place.name.clone(),
        position: Vec2::new(if centered { point.x } else { left }, top),
        kind,
    });
}

pub(crate) fn visible_tile_keys(samples: &[Vec3], zoom: u8) -> Vec<TileKey> {
    let count = 1_i64 << zoom;
    let mut seen = HashSet::new();
    let mut desired = Vec::new();
    for &sample in samples {
        let center = surface_to_tile(sample, zoom);
        // The rays are a sparse grid. Include adjacent XYZ cells so a tile
        // between two rays does not disappear from the request set.
        for (dx, dy) in [
            (0, 0),
            (-1, 0),
            (1, 0),
            (0, -1),
            (0, 1),
            (-1, -1),
            (1, -1),
            (-1, 1),
            (1, 1),
        ] {
            let y = center.y as i64 + dy;
            if !(0..count).contains(&y) {
                continue;
            }
            let key = TileKey {
                z: zoom,
                x: (center.x as i64 + dx).rem_euclid(count) as u32,
                y: y as u32,
            };
            if seen.insert(key) {
                desired.push(key);
                if desired.len() == MAX_DESIRED {
                    return desired;
                }
            }
        }
    }
    desired
}

fn collect_candidates(loaded: &HashMap<TileKey, ResidentTile>, zoom: u8) -> Vec<Place> {
    let mut keys: Vec<_> = loaded.keys().filter(|key| key.z <= zoom).copied().collect();
    // Prefer the finest ready tile when a place exists in several ancestors.
    // This also makes duplicate resolution independent of HashMap iteration.
    keys.sort_by_key(|key| (std::cmp::Reverse(key.z), key.x, key.y));
    let mut seen = HashSet::new();
    let mut candidates = Vec::new();
    for key in keys {
        for place in &loaded[&key].features {
            if place.min_zoom <= zoom as f64 && seen.insert(place.id) {
                candidates.push(place.clone());
            }
        }
    }
    candidates.sort_by(|a, b| {
        a.label_rank
            .cmp(&b.label_rank)
            .then_with(|| b.population.unwrap_or(0).cmp(&a.population.unwrap_or(0)))
            .then_with(|| a.id.cmp(&b.id))
    });
    candidates
}

pub(crate) fn project_place(
    camera: &OrbitCamera,
    terrain: &TerrainLayer,
    place: &Place,
    width: u32,
    height: u32,
) -> Option<Vec2> {
    let latitude = place.latitude.to_radians();
    let longitude = place.longitude.to_radians();
    let elevation = terrain.sample(latitude, longitude).max(0.0) + 30.0;
    let position = geo::geodetic_position(latitude, longitude, elevation);
    let eye = camera.eye_m();
    let normal = DVec3::new(
        latitude.cos() * longitude.sin(),
        latitude.sin(),
        latitude.cos() * longitude.cos(),
    );
    if normal.dot(eye - position) <= 0.0 {
        return None;
    }
    let relative = (position - eye) / geo::SEMI_MAJOR_M;
    let clip = camera.view_projection()
        * Vec4::new(relative.x as f32, relative.y as f32, relative.z as f32, 1.0);
    if clip.w <= 0.0 {
        return None;
    }
    let ndc = clip.truncate() / clip.w;
    if !(0.0..=1.0).contains(&ndc.z) || ndc.x.abs() > 1.0 || ndc.y.abs() > 1.0 {
        return None;
    }
    Some(Vec2::new(
        (ndc.x + 1.0) * width as f32 * 0.5,
        (1.0 - ndc.y) * height as f32 * 0.5,
    ))
}

fn overlaps(a: [f32; 4], b: [f32; 4]) -> bool {
    a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3]
}

fn tile_url(key: TileKey) -> String {
    format!("{API_ROOT}/{}/{}/{}?lang=zh", key.z, key.x, key.y)
}

fn parse_tile(bytes: &[u8]) -> Result<PlaceTile> {
    serde_json::from_slice(bytes).context("decode place-name JSON tile")
}

#[cfg(not(target_arch = "wasm32"))]
fn load_native(client: &reqwest::blocking::Client, key: TileKey) -> Result<PlaceTile> {
    let root = dirs::cache_dir().context("no platform cache directory")?;
    let path: PathBuf = root
        .join("cangling-desktop/placenames/v1")
        .join(key.z.to_string())
        .join(key.x.to_string())
        .join(format!("{}.json", key.y));
    if let Ok(bytes) = fs::read(&path) {
        if let Ok(tile) = parse_tile(&bytes) {
            return Ok(tile);
        }
    }
    let bytes = client
        .get(tile_url(key))
        .send()?
        .error_for_status()?
        .bytes()?;
    let tile = parse_tile(&bytes)?;
    if let Some(parent) = path.parent() {
        if let Err(error) = fs::create_dir_all(parent) {
            log::warn!("place-name cache directory failed: {error}");
            return Ok(tile);
        }
    }
    let temporary = path.with_extension("part");
    if fs::write(&temporary, &bytes).is_ok() {
        if let Err(error) = fs::rename(temporary, path) {
            log::warn!("place-name cache write failed: {error}");
        }
    }
    Ok(tile)
}

#[cfg(test)]
mod tests {
    use super::*;
    use winit::dpi::PhysicalSize;

    #[test]
    fn region_label_keeps_its_geographic_anchor_as_text_centre() {
        let camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let terrain = TerrainLayer::new();
        let region = Place {
            id: 1,
            name: "陕西省".into(),
            longitude: 108.9,
            latitude: 34.3,
            label_rank: 4,
            min_zoom: 0.0,
            population: None,
        };
        let anchor = project_place(&camera, &terrain, &region, 1440, 900).unwrap();
        let mut labels = Vec::new();
        push_label(
            &mut labels,
            &mut Vec::new(),
            &camera,
            &terrain,
            &region,
            LabelKind::Region,
            (1440, 900),
        );
        assert_eq!(labels.len(), 1);
        assert!((labels[0].position.x - anchor.x).abs() < 0.01);
    }

    #[test]
    fn embedded_country_labels_show_at_global_zoom_then_yield_to_cities() {
        let mut names = PlaceNames::new();
        assert_eq!(names.countries.len(), 246);
        let camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let terrain = TerrainLayer::new();
        names.update(&camera, &terrain, &[], 4, (1440, 900), false);
        assert!(names.labels.iter().any(|label| {
            label.text == "中华人民共和国" && label.kind == LabelKind::Country
        }));
        assert!(
            names
                .labels
                .iter()
                .all(|label| label.kind == LabelKind::Country)
        );
        // Imagery XYZ level may change with latitude while eye distance stays
        // fixed. Country labels should not switch to cities during a rotation.
        names.update(&camera, &terrain, &[], 5, (1440, 900), false);
        assert!(
            names
                .labels
                .iter()
                .all(|label| label.kind == LabelKind::Country)
        );
        assert!(names.pending.is_empty());
        names.candidates.push(Place {
            id: 1,
            name: "西安".into(),
            longitude: 108.9,
            latitude: 34.3,
            label_rank: 1,
            min_zoom: 0.0,
            population: Some(12_000_000),
        });
        names.country_mode = country_mode_at_distance(names.country_mode, 2.0);
        names.build_labels(&camera, &terrain, (1440, 900));
        assert!(
            names
                .labels
                .iter()
                .all(|label| label.kind == LabelKind::City)
        );
        assert!(names.labels.iter().any(|label| label.text == "西安"));
    }

    #[test]
    fn country_mode_has_separate_zoom_in_and_zoom_out_thresholds() {
        assert!(country_mode_at_distance(true, 2.50));
        assert!(!country_mode_at_distance(true, 2.34));
        assert!(!country_mode_at_distance(false, 2.50));
        assert!(country_mode_at_distance(false, 2.61));
    }

    #[test]
    fn parses_server_tile_and_uses_public_proxy() {
        let tile = parse_tile(r#"{"z":2,"x":3,"y":1,"features":[{"id":1,"name":"北京","longitude":116.4,"latitude":39.9,"label_rank":1,"min_zoom":2.0,"population":20000000}]}"#.as_bytes()).unwrap();
        assert_eq!(tile.features[0].name, "北京");
        assert_eq!(
            tile_url(TileKey { z: 2, x: 3, y: 1 }),
            "https://agri.cangling.cn:22002/cangling-map/api/placenames/tiles/2/3/1?lang=zh"
        );
    }

    #[test]
    fn collision_rectangles_exclude_only_overlaps() {
        assert!(overlaps([0.0, 0.0, 20.0, 20.0], [10.0, 10.0, 30.0, 30.0]));
        assert!(!overlaps([0.0, 0.0, 20.0, 20.0], [20.0, 0.0, 30.0, 20.0]));
    }

    #[test]
    fn visible_request_tiles_cover_neighbours_across_the_dateline() {
        let point = geo::geodetic_position(0.0, (-179.0_f64).to_radians(), 0.0);
        let sample = (point / geo::SEMI_MAJOR_M).as_vec3();
        let keys = visible_tile_keys(&[sample], 2);
        let center = surface_to_tile(sample, 2);
        assert!(keys.contains(&center));
        assert!(keys.contains(&TileKey {
            z: 2,
            x: 3,
            y: center.y
        }));
    }

    #[test]
    fn ready_tiles_keep_their_places_when_request_samples_change() {
        let mut loaded = HashMap::new();
        for (key, id, name) in [
            (TileKey { z: 4, x: 12, y: 6 }, 1, "北京"),
            (TileKey { z: 4, x: 13, y: 6 }, 2, "天津"),
        ] {
            loaded.insert(
                key,
                ResidentTile {
                    features: vec![Place {
                        id,
                        name: name.into(),
                        longitude: 116.0,
                        latitude: 39.0,
                        label_rank: 1,
                        min_zoom: 2.0,
                        population: Some(1_000_000),
                    }],
                    last_used: 1,
                },
            );
        }
        let names: Vec<_> = collect_candidates(&loaded, 4)
            .into_iter()
            .map(|place| place.name)
            .collect();
        assert_eq!(names, ["北京", "天津"]);
    }
}
