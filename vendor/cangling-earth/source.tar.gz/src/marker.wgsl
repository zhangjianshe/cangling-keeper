struct MarkerUniform {
    center_px: vec2<f32>,
    viewport_px: vec2<f32>,
};

@group(0) @binding(0) var<uniform> marker: MarkerUniform;

struct VertexOutput {
    @builtin(position) position: vec4<f32>,
    @location(0) local_px: vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) index: u32) -> VertexOutput {
    let corners = array<vec2<f32>, 6>(
        vec2<f32>(-1.0, -1.0), vec2<f32>(1.0, -1.0), vec2<f32>(-1.0, 1.0),
        vec2<f32>(-1.0, 1.0), vec2<f32>(1.0, -1.0), vec2<f32>(1.0, 1.0),
    );
    let local_px = corners[index] * 28.0;
    let screen_px = marker.center_px + local_px;
    var output: VertexOutput;
    output.position = vec4<f32>(
        2.0 * screen_px.x / marker.viewport_px.x - 1.0,
        1.0 - 2.0 * screen_px.y / marker.viewport_px.y,
        0.0,
        1.0,
    );
    output.local_px = local_px;
    return output;
}

@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    let p = input.local_px;
    let radius = length(p);
    let shadow_ring = 1.0 - smoothstep(3.3, 5.0, abs(radius - 17.0));
    let ring = 1.0 - smoothstep(0.9, 2.1, abs(radius - 17.0));
    let inner_dot = 1.0 - smoothstep(1.5, 2.8, radius);
    let vertical_tick = (1.0 - smoothstep(0.6, 1.6, abs(p.x)))
        * (1.0 - smoothstep(4.0, 6.0, abs(abs(p.y) - 23.0)));
    let horizontal_tick = (1.0 - smoothstep(0.6, 1.6, abs(p.y)))
        * (1.0 - smoothstep(4.0, 6.0, abs(abs(p.x) - 23.0)));
    let bright = max(max(ring, inner_dot), max(vertical_tick, horizontal_tick));
    let alpha = max(shadow_ring * 0.6, bright);
    let color = mix(vec3<f32>(0.02, 0.06, 0.10), vec3<f32>(1.0, 0.77, 0.24), bright);
    return vec4<f32>(color, alpha);
}
