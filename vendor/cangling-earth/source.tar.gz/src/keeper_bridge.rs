thread_local! {static KEEPER_WINDOW:RefCell<Option<Arc<Window>>>=const {RefCell::new(None)};static KEEPER_RENDERER:RefCell<Option<Rc<RefCell<Option<Renderer>>>>>=const {RefCell::new(None)};static KEEPER_PAUSED:std::cell::Cell<bool>=const {std::cell::Cell::new(false)};}
#[wasm_bindgen]
pub fn keeper_command(method:&str,args:&str)->Result<String,JsValue>{
    let args:serde_json::Value=serde_json::from_str(args).map_err(|_|JsValue::from_str("invalid JSON"))?;
    if method=="pause"{KEEPER_PAUSED.with(|v|v.set(args.as_bool().unwrap_or(true)));KEEPER_WINDOW.with(|w|{if let Some(w)=w.borrow().as_ref(){w.request_redraw();}});return Ok("true".into());}
    KEEPER_RENDERER.with(|slot|{let slot=slot.borrow();let handle=slot.as_ref().ok_or_else(||JsValue::from_str("Earth not started"))?;let mut renderer=handle.borrow_mut();renderer.as_mut().ok_or_else(||JsValue::from_str("Earth not ready"))?.keeper_command(method,&args).map(|v|v.to_string()).map_err(|e|JsValue::from_str(&e))})
}
