thread_local! {static KEEPER_WINDOW:RefCell<Option<Arc<Window>>>=const {RefCell::new(None)};static KEEPER_RENDERER:RefCell<Option<Rc<RefCell<Option<Renderer>>>>>=const {RefCell::new(None)};static KEEPER_PAUSED:std::cell::Cell<bool>=const {std::cell::Cell::new(false)};}
// JS callbacks may re-enter during native events. Return a recoverable busy
// error instead of panicking and permanently breaking the WebAssembly instance.
fn with_keeper_renderer<T>(action:impl FnOnce(&mut Renderer)->Result<T,String>)->Result<T,JsValue>{
    let handle=KEEPER_RENDERER.with(|slot|slot.borrow().clone()).ok_or_else(||JsValue::from_str("Earth not started"))?;
    let mut renderer=handle.try_borrow_mut().map_err(|_|JsValue::from_str("Earth renderer busy; retry after the frame"))?;
    action(renderer.as_mut().ok_or_else(||JsValue::from_str("Earth not ready"))?).map_err(|e|JsValue::from_str(&e))
}
#[wasm_bindgen]
pub fn keeper_command(method:&str,args:&str)->Result<String,JsValue>{
    let args:serde_json::Value=serde_json::from_str(args).map_err(|_|JsValue::from_str("invalid JSON"))?;
    if method=="pause"{KEEPER_PAUSED.with(|v|v.set(args.as_bool().unwrap_or(true)));KEEPER_WINDOW.with(|w|{if let Some(w)=w.borrow().as_ref(){w.request_redraw();}});return Ok("true".into());}
    with_keeper_renderer(|renderer|renderer.keeper_command(method,&args).map(|v|v.to_string()))
}
#[wasm_bindgen]
pub fn keeper_image(id:&str,bytes:&[u8],polygon:&str)->Result<(),JsValue>{
    let points:Vec<[f64;2]>=serde_json::from_str(polygon).map_err(|_|JsValue::from_str("invalid polygon"))?;
    with_keeper_renderer(|renderer|renderer.keeper_image(id,bytes,&points))
}
#[wasm_bindgen]
pub fn keeper_model(id:&str,bytes:&[u8],placement:&str)->Result<(),JsValue>{
    let points:serde_json::Value=serde_json::from_str(placement).map_err(|_|JsValue::from_str("invalid placement"))?;
    with_keeper_renderer(|renderer|renderer.keeper_model(id,bytes,&points))
}
#[wasm_bindgen]
pub fn keeper_tile(id:&str,bytes:&[u8])->Result<(),JsValue>{with_keeper_renderer(|renderer|renderer.keeper_tile(id,bytes))}
