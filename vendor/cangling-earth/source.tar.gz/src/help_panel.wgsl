struct Panel {
    viewport: vec4<f32>,
    rect: vec4<f32>,
};

@group(0) @binding(0) var<uniform> panel: Panel;

struct VertexOutput {
    @builtin(position) position: vec4<f32>,
    @location(0) pixel: vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) index: u32) -> VertexOutput {
    let corners = array<vec2<f32>, 6>(
        vec2<f32>(0.0, 0.0), vec2<f32>(1.0, 0.0), vec2<f32>(0.0, 1.0),
        vec2<f32>(0.0, 1.0), vec2<f32>(1.0, 0.0), vec2<f32>(1.0, 1.0),
    );
    let pixel = panel.rect.xy + corners[index] * panel.rect.zw;
    var output: VertexOutput;
    output.position = vec4<f32>(pixel.x / panel.viewport.x * 2.0 - 1.0,
        1.0 - pixel.y / panel.viewport.y * 2.0, 0.0, 1.0);
    output.pixel = pixel - panel.rect.xy;
    return output;
}

@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    let edge = min(min(input.pixel.x, input.pixel.y),
        min(panel.rect.z - input.pixel.x, panel.rect.w - input.pixel.y));
    if edge < 1.0 {
        return vec4<f32>(0.78, 0.86, 0.94, 0.85);
    }
    return vec4<f32>(0.025, 0.055, 0.105, 0.93);
}
