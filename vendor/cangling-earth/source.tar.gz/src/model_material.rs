//! glTF base-color textures are sRGB; factors and mip filtering are linear.
pub fn sampler(value: gltf::texture::Sampler<'_>) -> wgpu::SamplerDescriptor<'static> {
    use gltf::texture::{MagFilter, MinFilter, WrappingMode};
    let wrap = |v| match v {
        WrappingMode::ClampToEdge => wgpu::AddressMode::ClampToEdge,
        WrappingMode::MirroredRepeat => wgpu::AddressMode::MirrorRepeat,
        WrappingMode::Repeat => wgpu::AddressMode::Repeat,
    };
    let min = value.min_filter().unwrap_or(MinFilter::LinearMipmapLinear);
    wgpu::SamplerDescriptor {
        address_mode_u: wrap(value.wrap_s()),
        address_mode_v: wrap(value.wrap_t()),
        mag_filter: if value.mag_filter() == Some(MagFilter::Nearest) {
            wgpu::FilterMode::Nearest
        } else {
            wgpu::FilterMode::Linear
        },
        min_filter: match min {
            MinFilter::Nearest
            | MinFilter::NearestMipmapNearest
            | MinFilter::NearestMipmapLinear => wgpu::FilterMode::Nearest,
            _ => wgpu::FilterMode::Linear,
        },
        mipmap_filter: match min {
            MinFilter::NearestMipmapLinear | MinFilter::LinearMipmapLinear => {
                wgpu::MipmapFilterMode::Linear
            }
            _ => wgpu::MipmapFilterMode::Nearest,
        },
        lod_max_clamp: if matches!(min, MinFilter::Nearest | MinFilter::Linear) {
            0.0
        } else {
            32.0
        },
        ..Default::default()
    }
}
fn linear(v: u8) -> f32 {
    let v = v as f32 / 255.;
    if v <= 0.04045 {
        v / 12.92
    } else {
        ((v + 0.055) / 1.055).powf(2.4)
    }
}
fn srgb(v: f32) -> u8 {
    let v = if v <= 0.0031308 {
        12.92 * v
    } else {
        1.055 * v.powf(1. / 2.4) - 0.055
    };
    (v.clamp(0., 1.) * 255.).round() as u8
}
pub fn mip_data(source: &image::RgbaImage) -> (u32, Vec<u8>) {
    let (mut w, mut h) = source.dimensions();
    let mut data = source.as_raw().clone();
    let mut count = 1;
    // Premultiplied linear filtering avoids dark fringes around transparent texels.
    let mut current = image::ImageBuffer::<image::Rgba<f32>, Vec<f32>>::from_fn(w, h, |x, y| {
        let p = source.get_pixel(x, y);
        let a = p[3] as f32 / 255.;
        image::Rgba([linear(p[0]) * a, linear(p[1]) * a, linear(p[2]) * a, a])
    });
    while w > 1 || h > 1 {
        w = (w / 2).max(1);
        h = (h / 2).max(1);
        current = image::imageops::resize(&current, w, h, image::imageops::FilterType::Triangle);
        for p in current.pixels() {
            let a = p[3];
            for c in 0..3 {
                data.push(srgb(if a > 1e-8 { p[c] / a } else { 0. }));
            }
            data.push((a.clamp(0., 1.) * 255.).round() as u8);
        }
        count += 1;
    }
    (count, data)
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn mipmaps_filter_linear_and_handle_odd_dimensions() {
        let image = image::RgbaImage::from_fn(2, 1, |x, _| {
            image::Rgba(if x == 0 { [0, 0, 0, 255] } else { [255; 4] })
        });
        let (levels, data) = mip_data(&image);
        assert_eq!(levels, 2);
        assert!((data[8] as i32 - 188).abs() <= 1);
        let (levels, data) = mip_data(&image::RgbaImage::new(3, 5));
        assert_eq!(levels, 3);
        assert_eq!(data.len(), (15 + 2 + 1) * 4);
    }
    #[test]
    fn sampling_respects_wrap_and_filter_modes() {
        let doc=gltf::Gltf::from_slice(br#"{"asset":{"version":"2.0"},"samplers":[{"wrapS":33648,"wrapT":33071,"minFilter":9728,"magFilter":9728}]}"#).unwrap();
        let s = sampler(doc.samplers().next().unwrap());
        assert_eq!(s.address_mode_u, wgpu::AddressMode::MirrorRepeat);
        assert_eq!(s.address_mode_v, wgpu::AddressMode::ClampToEdge);
        assert_eq!(s.min_filter, wgpu::FilterMode::Nearest);
        assert_eq!(s.lod_max_clamp, 0.);
    }
}
