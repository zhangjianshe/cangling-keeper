use bytemuck::{Pod, Zeroable};
use glam::{DVec3, Mat4, Vec2, Vec3, Vec4};
use wgpu::util::DeviceExt;

use crate::{
    camera::{self, OrbitCamera},
    geo,
    terrain::TerrainLayer,
};

const MAX_VERTICES: usize = 98_304;
const HALF_WIDTH_PX: f32 = 1.5;
const MAJOR_BOUNDARY_HALF_WIDTH_PX: f32 = 1.5;
const MAX_GRID_INTERVALS: f64 = 7.0;
const MINOR_OPACITY: f32 = 0.28;
const VISIBILITY_FADE_SECONDS: f32 = 0.5;
// Every finer interval divides the next coarser one. A coarse line therefore
// keeps the same WGS84 coordinate while the intermediate lines fade in/out.
const GRID_STEPS_DEGREES: &[f64] = &[
    0.0001, 0.0005, 0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1.0, 5.0, 15.0, 30.0, 60.0,
];

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct GridVertex {
    position_px: [f32; 2],
    depth: f32,
    side_px: f32,
    opacity: f32,
    style: f32,
}

impl GridVertex {
    const ATTRIBUTES: [wgpu::VertexAttribute; 5] = wgpu::vertex_attr_array![
        0 => Float32x2, 1 => Float32, 2 => Float32, 3 => Float32, 4 => Float32
    ];

    fn layout() -> wgpu::VertexBufferLayout<'static> {
        wgpu::VertexBufferLayout {
            array_stride: std::mem::size_of::<Self>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &Self::ATTRIBUTES,
        }
    }
}

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct GridViewport {
    size_px: [f32; 2],
    visibility: f32,
    padding: f32,
}

#[derive(Clone)]
pub struct GridLabel {
    pub text: String,
    pub position: Vec2,
    pub opacity: f32,
}

#[derive(Default)]
struct GridMesh {
    vertices: Vec<GridVertex>,
    labels: Vec<GridLabel>,
}

struct GridView {
    eye_m: DVec3,
    projection: Mat4,
    size: Vec2,
}

impl GridView {
    fn project(&self, point: DVec3) -> Option<(Vec2, f32)> {
        let relative = (point - self.eye_m) / geo::SEMI_MAJOR_M;
        let clip = self.projection
            * Vec4::new(relative.x as f32, relative.y as f32, relative.z as f32, 1.0);
        if clip.w <= 0.0 {
            return None;
        }
        let ndc = clip.truncate() / clip.w;
        if !(0.0..=1.0).contains(&ndc.z) {
            return None;
        }
        Some((
            Vec2::new(
                (ndc.x + 1.0) * self.size.x * 0.5,
                (1.0 - ndc.y) * self.size.y * 0.5,
            ),
            ndc.z,
        ))
    }
}

pub struct Graticule {
    pipeline: wgpu::RenderPipeline,
    viewport_buffer: wgpu::Buffer,
    viewport_bind_group: wgpu::BindGroup,
    vertex_buffer: wgpu::Buffer,
    vertex_count: u32,
    labels: Vec<GridLabel>,
    target_visible: bool,
    visibility: f32,
}

impl Graticule {
    pub fn new(device: &wgpu::Device, format: wgpu::TextureFormat) -> Self {
        let viewport_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("graticule viewport"),
            contents: bytemuck::bytes_of(&GridViewport {
                size_px: [1.0, 1.0],
                visibility: 0.0,
                padding: 0.0,
            }),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let viewport_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("graticule viewport layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let viewport_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("graticule viewport bind group"),
            layout: &viewport_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: viewport_buffer.as_entire_binding(),
            }],
        });
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("antialiased graticule shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("graticule.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("graticule pipeline layout"),
            bind_group_layouts: &[Some(&viewport_layout)],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("antialiased latitude longitude grid"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[Some(GridVertex::layout())],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                cull_mode: None,
                ..Default::default()
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: Some(false),
                depth_compare: Some(wgpu::CompareFunction::Always),
                stencil: Default::default(),
                bias: Default::default(),
            }),
            multisample: Default::default(),
            multiview_mask: None,
            cache: None,
        });
        let vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("graticule quad vertices"),
            contents: &vec![0_u8; MAX_VERTICES * std::mem::size_of::<GridVertex>()],
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
        });
        Self {
            pipeline,
            viewport_buffer,
            viewport_bind_group,
            vertex_buffer,
            vertex_count: 0,
            labels: Vec::new(),
            target_visible: false,
            visibility: 0.0,
        }
    }

    pub fn toggle(&mut self) {
        self.target_visible = !self.target_visible;
    }

    pub fn labels(&self) -> &[GridLabel] {
        &self.labels
    }

    pub fn update(
        &mut self,
        queue: &wgpu::Queue,
        camera: &OrbitCamera,
        width: u32,
        height: u32,
        visible_samples: &[Vec3],
        terrain: &TerrainLayer,
        delta_seconds: f32,
    ) {
        let step = delta_seconds.clamp(0.0, VISIBILITY_FADE_SECONDS) / VISIBILITY_FADE_SECONDS;
        self.visibility = if self.target_visible {
            (self.visibility + step).min(1.0)
        } else {
            (self.visibility - step).max(0.0)
        };
        if self.visibility == 0.0 {
            self.vertex_count = 0;
            self.labels.clear();
            return;
        }
        let mesh = build_grid_mesh(camera, width, height, visible_samples, terrain);
        self.vertex_count = mesh.vertices.len() as u32;
        self.labels = mesh.labels;
        for label in &mut self.labels {
            label.opacity *= self.visibility;
        }
        queue.write_buffer(
            &self.viewport_buffer,
            0,
            bytemuck::bytes_of(&GridViewport {
                size_px: [width.max(1) as f32, height.max(1) as f32],
                visibility: self.visibility,
                padding: 0.0,
            }),
        );
        if !mesh.vertices.is_empty() {
            queue.write_buffer(&self.vertex_buffer, 0, bytemuck::cast_slice(&mesh.vertices));
        }
    }

    pub fn draw(&self, pass: &mut wgpu::RenderPass<'_>) {
        if self.vertex_count == 0 {
            return;
        }
        pass.set_pipeline(&self.pipeline);
        pass.set_bind_group(0, &self.viewport_bind_group, &[]);
        pass.set_vertex_buffer(0, self.vertex_buffer.slice(..));
        pass.draw(0..self.vertex_count, 0..1);
    }
}

fn build_grid_mesh(
    camera: &OrbitCamera,
    width: u32,
    height: u32,
    visible_samples: &[Vec3],
    terrain: &TerrainLayer,
) -> GridMesh {
    if visible_samples.is_empty() {
        return GridMesh::default();
    }
    let eye_m = camera.eye_m();
    let (_, center_lon) = geo::geodetic_lat_lon(eye_m);
    let mut south = 90.0_f64;
    let mut north = -90.0_f64;
    let mut west = f64::INFINITY;
    let mut east = f64::NEG_INFINITY;
    for sample in visible_samples {
        let point =
            DVec3::new(sample.x as f64, sample.y as f64, sample.z as f64) * geo::SEMI_MAJOR_M;
        let (lat, lon) = geo::geodetic_lat_lon(point);
        south = south.min(lat.to_degrees());
        north = north.max(lat.to_degrees());
        let unwrapped =
            center_lon.to_degrees() + wrap_degrees(lon.to_degrees() - center_lon.to_degrees());
        west = west.min(unwrapped);
        east = east.max(unwrapped);
    }
    // Screen-ray samples are sparse near the limb of a small, fully visible
    // globe. Include the analytical horizon so the grid reaches its edge.
    if eye_m.length() > 1.8 * geo::SEMI_MAJOR_M {
        let outward = eye_m.normalize();
        let east_axis = if outward.y.abs() < 0.99 {
            DVec3::Y.cross(outward).normalize()
        } else {
            DVec3::X.cross(outward).normalize()
        };
        let north_axis = outward.cross(east_axis);
        let horizon_angle = (geo::SEMI_MAJOR_M / eye_m.length()).acos();
        for index in 0..128 {
            let angle = std::f64::consts::TAU * index as f64 / 128.0;
            let point = outward * horizon_angle.cos()
                + (east_axis * angle.cos() + north_axis * angle.sin()) * horizon_angle.sin();
            let (lat, lon) = geo::geodetic_lat_lon(point * geo::SEMI_MAJOR_M);
            south = south.min(lat.to_degrees());
            north = north.max(lat.to_degrees());
            let unwrapped =
                center_lon.to_degrees() + wrap_degrees(lon.to_degrees() - center_lon.to_degrees());
            west = west.min(unwrapped);
            east = east.max(unwrapped);
        }
        if geo::geodetic_lat_lon(eye_m).0.abs() + horizon_angle >= std::f64::consts::FRAC_PI_2 {
            west = center_lon.to_degrees() - 180.0;
            east = center_lon.to_degrees() + 180.0;
        }
    }
    // A tilted camera can see far more ground than the nadir-based nominal
    // estimate. Bound the number of geographic intervals in the *actual*
    // footprint, otherwise one fine level can exhaust the vertex buffer and
    // leave a rectangular block of partially drawn parallels.
    let levels = choose_grid_levels(
        nominal_view_span_degrees(camera, width, height),
        (south, north),
        (west, east),
    );
    let major_step = levels[levels.len().saturating_sub(2)].step;
    south = (south - major_step).max(-90.0);
    north = (north + major_step).min(90.0);
    west -= major_step;
    east += major_step;
    let mut mesh = GridMesh::default();
    let view = GridView {
        eye_m,
        projection: camera.view_projection(),
        size: Vec2::new(width as f32, height as f32),
    };
    let height_offset_m = (camera.eye_clearance_m() * 0.0001).clamp(1.0, 20.0);
    for (level_index, level) in levels.iter().enumerate() {
        if level.opacity <= 0.01 {
            continue;
        }
        let skip_every = if level_index == 0 {
            None
        } else {
            Some((levels[level_index - 1].step / level.step).round() as i32)
        };
        for parallels in [true, false] {
            let (fixed_range, span_range) = if parallels {
                ((south, north), (west, east))
            } else {
                ((west, east), (south, north))
            };
            append_lines(
                &mut mesh,
                parallels,
                fixed_range,
                span_range,
                level.step,
                level.opacity,
                skip_every,
                &view,
                terrain,
                height_offset_m,
            );
        }
    }
    mesh
}

#[derive(Clone, Copy, Debug)]
struct GridLevel {
    step: f64,
    opacity: f32,
}

fn append_lines(
    mesh: &mut GridMesh,
    parallels: bool,
    fixed_range: (f64, f64),
    span_range: (f64, f64),
    step: f64,
    opacity: f32,
    skip_every: Option<i32>,
    view: &GridView,
    terrain: &TerrainLayer,
    height_offset_m: f64,
) {
    let first = (fixed_range.0 / step).ceil() as i32;
    let last = (fixed_range.1 / step).floor() as i32;
    let (first_segment, last_segment, segment_step) = line_segment_bounds(span_range, step);
    let mut last_label_axis = f32::NEG_INFINITY;
    let mut label_count = 0;
    for index in first..=last {
        if skip_every.is_some_and(|multiple| index.rem_euclid(multiple) == 0) {
            continue;
        }
        let fixed = index as f64 * step;
        let mut label_candidate: Option<(f32, Vec2)> = None;
        let mut previous_endpoint = None;
        for segment in first_segment..last_segment {
            if mesh.vertices.len() + 6 > MAX_VERTICES {
                return;
            }
            let a = segment as f64 * segment_step;
            let b = (segment + 1) as f64 * segment_step;
            let (lat_a, lon_a, lat_b, lon_b) = if parallels {
                (fixed, a, fixed, b)
            } else {
                (a, fixed, b, fixed)
            };
            let smoothing = grid_smoothing_delta(lat_b - lat_a, lon_b - lon_a);
            let p = previous_endpoint
                .unwrap_or_else(|| grid_point(lat_a, lon_a, terrain, height_offset_m, smoothing));
            let q = grid_point(lat_b, lon_b, terrain, height_offset_m, smoothing);
            previous_endpoint = Some(q);
            let visible_a = front_facing(p, view.eye_m);
            let visible_b = front_facing(q, view.eye_m);
            if !visible_a && !visible_b {
                continue;
            }
            let (p, q) = if visible_a == visible_b {
                (p, q)
            } else {
                // Clip a crossing segment to the globe silhouette. Dropping
                // the entire segment leaves an obvious gap at the edge.
                let mut low = 0.0;
                let mut high = 1.0;
                for _ in 0..16 {
                    let mid = (low + high) * 0.5;
                    let mid_point = grid_point(
                        lat_a + (lat_b - lat_a) * mid,
                        lon_a + (lon_b - lon_a) * mid,
                        terrain,
                        height_offset_m,
                        smoothing,
                    );
                    if front_facing(mid_point, view.eye_m) == visible_a {
                        low = mid;
                    } else {
                        high = mid;
                    }
                }
                let edge = grid_point(
                    lat_a + (lat_b - lat_a) * (low + high) * 0.5,
                    lon_a + (lon_b - lon_a) * (low + high) * 0.5,
                    terrain,
                    height_offset_m,
                    smoothing,
                );
                if visible_a { (p, edge) } else { (edge, q) }
            };
            let (Some(start), Some(end)) = (view.project(p), view.project(q)) else {
                continue;
            };
            append_antialiased_segment(&mut mesh.vertices, start, end, opacity, 0.0);
            for point in [start.0, end.0] {
                if label_safe(point, parallels, view.size) {
                    let score = if parallels { point.x } else { point.y };
                    if label_candidate.is_none_or(|(best, _)| score < best) {
                        label_candidate = Some((score, point));
                    }
                }
            }
        }
        if opacity < 0.5 || label_count >= 10 || (parallels && fixed.abs() > 89.9) {
            continue;
        }
        if let Some((_, point)) = label_candidate {
            let axis = if parallels { point.y } else { point.x };
            let position = point + Vec2::new(6.0, if parallels { -20.0 } else { 5.0 });
            let overlaps_major = mesh.labels.iter().any(|label| {
                (label.position.x - position.x).abs() < 80.0
                    && (label.position.y - position.y).abs() < 30.0
            });
            if (axis - last_label_axis).abs() >= 72.0 && !overlaps_major {
                mesh.labels.push(GridLabel {
                    text: coordinate_label(fixed, parallels, step),
                    position,
                    opacity,
                });
                last_label_axis = axis;
                label_count += 1;
            }
        }
    }
}

fn line_segment_bounds(span_range: (f64, f64), step: f64) -> (i64, i64, f64) {
    // Anchor every vertex to a geographic coordinate. Segmenting from the
    // current visible edge moved all DEM sample points on every camera pan,
    // so terrain-following grid lines appeared to wobble over the imagery.
    let segment_step = step / 8.0;
    let first = (span_range.0 / segment_step).floor() as i64;
    let last = (span_range.1 / segment_step).ceil() as i64;
    (first, last, segment_step)
}

fn choose_grid_levels(
    nominal_span: f64,
    latitude_range: (f64, f64),
    longitude_range: (f64, f64),
) -> Vec<GridLevel> {
    let visible_span =
        (latitude_range.1 - latitude_range.0).max(longitude_range.1 - longitude_range.0);
    let mut desired = (nominal_span / 6.0).max(visible_span / MAX_GRID_INTERVALS);
    let mut levels = grid_levels(desired);
    while planned_vertex_upper_bound(latitude_range, longitude_range, &levels) > MAX_VERTICES {
        desired *= 1.5;
        levels = grid_levels(desired);
    }
    levels
}

fn planned_vertex_upper_bound(
    latitude_range: (f64, f64),
    longitude_range: (f64, f64),
    levels: &[GridLevel],
) -> usize {
    let padding = levels[levels.len().saturating_sub(2)].step;
    let lat = (
        (latitude_range.0 - padding).max(-90.0),
        (latitude_range.1 + padding).min(90.0),
    );
    let lon = (longitude_range.0 - padding, longitude_range.1 + padding);
    let mut total = 0_usize;
    for (index, level) in levels.iter().enumerate() {
        if level.opacity <= 0.01 {
            continue;
        }
        let skip_every = if index == 0 {
            None
        } else {
            Some((levels[index - 1].step / level.step).round() as i32)
        };
        for (fixed, span) in [(lat, lon), (lon, lat)] {
            let first = (fixed.0 / level.step).ceil() as i32;
            let last = (fixed.1 / level.step).floor() as i32;
            if last < first {
                continue;
            }
            let count = (last - first + 1) as usize;
            let skipped = skip_every.map_or(0, |multiple| {
                (last.div_euclid(multiple) - (first - 1).div_euclid(multiple)) as usize
            });
            total = total.saturating_add(
                (count - skipped)
                    .saturating_mul({
                        let (first, last, _) = line_segment_bounds(span, level.step);
                        last.saturating_sub(first) as usize
                    })
                    .saturating_mul(6),
            );
        }
    }
    total
}

fn append_antialiased_segment(
    vertices: &mut Vec<GridVertex>,
    start: (Vec2, f32),
    end: (Vec2, f32),
    opacity: f32,
    style: f32,
) {
    let delta = end.0 - start.0;
    if !delta.is_finite() || delta.length_squared() < 0.04 {
        return;
    }
    let direction = delta.normalize();
    let normal = Vec2::new(-direction.y, direction.x);
    let a = start.0 - direction * 0.8;
    let b = end.0 + direction * 0.8;
    let half_width = if style > 1.5 {
        MAJOR_BOUNDARY_HALF_WIDTH_PX
    } else {
        HALF_WIDTH_PX
    };
    let vertex = |position: Vec2, depth: f32, side_px: f32| GridVertex {
        position_px: position.to_array(),
        depth,
        side_px,
        opacity,
        style,
    };
    let left_a = vertex(a - normal * half_width, start.1, -half_width);
    let right_a = vertex(a + normal * half_width, start.1, half_width);
    let left_b = vertex(b - normal * half_width, end.1, -half_width);
    let right_b = vertex(b + normal * half_width, end.1, half_width);
    vertices.extend_from_slice(&[left_a, left_b, right_a, right_a, left_b, right_b]);
}

fn label_safe(point: Vec2, parallels: bool, view: Vec2) -> bool {
    if parallels {
        point.x >= 18.0 && point.x < view.x - 130.0 && point.y >= 90.0 && point.y < view.y - 90.0
    } else {
        point.x >= 310.0 && point.x < view.x - 120.0 && point.y >= 170.0 && point.y < view.y - 100.0
    }
}

fn coordinate_label(value: f64, latitude: bool, step: f64) -> String {
    let precision = if step < 0.001 {
        4
    } else if step < 0.01 {
        3
    } else if step < 0.1 {
        2
    } else if step < 1.0 {
        1
    } else {
        0
    };
    let hemisphere = match (latitude, value < 0.0) {
        (true, false) => 'N',
        (true, true) => 'S',
        (false, false) => 'E',
        (false, true) => 'W',
    };
    format!("{:.*}°{hemisphere}", precision, value.abs())
}

fn grid_smoothing_delta(latitude_delta: f64, longitude_delta: f64) -> (f64, f64) {
    let half = latitude_delta.abs().max(longitude_delta.abs()) * 0.5;
    let factor = if half > 0.01 { 0.01 / half } else { 1.0 };
    (
        latitude_delta * 0.5 * factor,
        longitude_delta * 0.5 * factor,
    )
}

fn grid_point(
    latitude: f64,
    longitude: f64,
    terrain: &TerrainLayer,
    offset_m: f64,
    smoothing: (f64, f64),
) -> DVec3 {
    let lat = latitude.clamp(-89.9999, 89.9999).to_radians();
    let lon = wrap_degrees(longitude).to_radians();
    let sample = |lat_deg: f64, lon_deg: f64| {
        terrain.sample(
            lat_deg.clamp(-89.9999, 89.9999).to_radians(),
            wrap_degrees(lon_deg).to_radians(),
        )
    };
    // Smooth over at most about one kilometre. This softens abrupt changes
    // where a fine DEM tile meets a coarser fallback without flattening the
    // hills and valleys that the line needs to follow.
    let height_m = 0.5 * sample(latitude, longitude)
        + 0.25 * sample(latitude - smoothing.0, longitude - smoothing.1)
        + 0.25 * sample(latitude + smoothing.0, longitude + smoothing.1);
    geo::geodetic_position(lat, lon, height_m + offset_m)
}

fn front_facing(point: DVec3, eye_m: DVec3) -> bool {
    point.dot(eye_m - point) > 0.0
}

fn wrap_degrees(degrees: f64) -> f64 {
    (degrees + 180.0).rem_euclid(360.0) - 180.0
}

fn grid_levels(desired: f64) -> Vec<GridLevel> {
    let index = GRID_STEPS_DEGREES
        .iter()
        .position(|step| *step >= desired)
        .unwrap_or(GRID_STEPS_DEGREES.len() - 1);
    let major = GRID_STEPS_DEGREES[index];
    if index == 0 {
        return vec![GridLevel {
            step: major,
            opacity: 1.0,
        }];
    }
    let minor = GRID_STEPS_DEGREES[index - 1];
    let progress = ((major - desired) / (major - minor)).clamp(0.0, 1.0) as f32;
    let fade = progress * progress * (3.0 - 2.0 * progress);
    let mut levels = Vec::with_capacity(3);
    if let Some(parent) = GRID_STEPS_DEGREES.get(index + 1) {
        levels.push(GridLevel {
            step: *parent,
            opacity: 1.0,
        });
    }
    levels.push(GridLevel {
        step: major,
        opacity: if levels.is_empty() {
            1.0
        } else {
            MINOR_OPACITY + (1.0 - MINOR_OPACITY) * fade
        },
    });
    levels.push(GridLevel {
        step: minor,
        opacity: MINOR_OPACITY * fade,
    });
    levels
}

/// A continuous, location-independent estimate of the globe angle spanned by
/// the longer screen dimension when looking toward the Earth's centre.
/// Actual visible samples still determine where to draw, but cannot cause a
/// whole grid level to change when a ray crosses the globe's silhouette.
fn nominal_view_span_degrees(camera: &OrbitCamera, width: u32, height: u32) -> f64 {
    let radius = geo::SEMI_MAJOR_M;
    let eye_radius = camera.eye_m().length().max(radius + 1.0);
    let half_vertical = camera::FIELD_OF_VIEW as f64 * 0.5;
    let aspect = width.max(1) as f64 / height.max(1) as f64;
    let half_horizontal = (aspect * half_vertical.tan()).atan();
    let ray_angle = half_vertical
        .max(half_horizontal)
        .min((radius / eye_radius).asin());
    let half_surface_angle = ((eye_radius / radius) * ray_angle.sin())
        .clamp(-1.0, 1.0)
        .asin()
        - ray_angle;
    2.0 * half_surface_angle.to_degrees()
}

#[cfg(test)]
mod tests {
    use super::*;

    use winit::dpi::PhysicalSize;

    #[test]
    fn graticule_shader_is_valid_wgsl() {
        let module = naga::front::wgsl::parse_str(include_str!("graticule.wgsl"))
            .expect("graticule shader parses");
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&module)
        .expect("graticule shader validates");
    }

    #[test]
    fn nested_grid_levels_blend_without_replacing_major_lines() {
        for pair in GRID_STEPS_DEGREES.windows(2) {
            let ratio = pair[1] / pair[0];
            assert!((ratio - ratio.round()).abs() < 1e-8);
        }
        let above = grid_levels(15.001);
        let below = grid_levels(14.999);
        let opacity_at = |levels: &[GridLevel], step| {
            levels
                .iter()
                .find(|level| level.step == step)
                .map(|level| level.opacity)
                .unwrap_or(0.0)
        };
        assert!((opacity_at(&above, 15.0) - MINOR_OPACITY).abs() < 0.001);
        assert!((opacity_at(&below, 15.0) - MINOR_OPACITY).abs() < 0.001);
        assert!((opacity_at(&above, 30.0) - 1.0).abs() < 0.001);
        assert!((opacity_at(&below, 30.0) - 1.0).abs() < 0.001);
        assert!(below.last().unwrap().opacity <= MINOR_OPACITY);
        assert_eq!(grid_levels(0.00001)[0].step, 0.0001);
    }

    #[test]
    fn nominal_spacing_changes_continuously_with_camera_distance() {
        let camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let span = nominal_view_span_degrees(&camera, 1440, 900);
        assert!(span > 0.0 && span < 180.0);
        let wider = nominal_view_span_degrees(&camera, 1920, 900);
        assert!(wider >= span);
    }

    #[test]
    fn tilted_close_view_uses_a_complete_grid_with_dim_minor_lines() {
        // A narrow nominal span with a much wider actual footprint previously
        // filled MAX_VERTICES halfway through the parallels. The result was a
        // bright rectangular field of horizontal strokes without meridians.
        let lat = (29.105, 29.155);
        let lon = (112.17, 112.24);
        assert!(planned_vertex_upper_bound(lat, lon, &grid_levels(0.00011)) > MAX_VERTICES);
        let levels = choose_grid_levels(0.00066, lat, lon);
        assert!(planned_vertex_upper_bound(lat, lon, &levels) <= MAX_VERTICES);
        assert!(levels.len() >= 2);
        assert!(levels.last().unwrap().opacity <= MINOR_OPACITY);
        assert!(levels.iter().any(|level| level.opacity >= 0.99));
    }

    #[test]
    fn longitude_wraps_across_the_date_line() {
        assert!((wrap_degrees(-358.0) - 2.0).abs() < 1e-12);
        assert!((wrap_degrees(358.0) + 2.0).abs() < 1e-12);
    }

    #[test]
    fn coordinate_labels_use_hemispheres() {
        assert_eq!(coordinate_label(-30.0, true, 10.0), "30°S");
        assert_eq!(coordinate_label(108.5, false, 0.5), "108.5°E");
    }

    #[test]
    fn terrain_grid_smoothing_stays_local() {
        let (latitude, longitude) = grid_smoothing_delta(0.0, 0.04);
        assert_eq!(latitude, 0.0);
        assert!((longitude - 0.01).abs() < 1e-12);
        let (_, close_longitude) = grid_smoothing_delta(0.0, 0.002);
        assert!((close_longitude - 0.001).abs() < 1e-12);
    }

    #[test]
    fn geographic_grid_segments_do_not_shift_with_the_viewport() {
        let left = line_segment_bounds((102.91, 102.98), 0.01);
        let right = line_segment_bounds((102.92, 102.99), 0.01);
        assert_eq!(left.2, right.2);
        let shared = left.0.max(right.0);
        assert!(shared < left.1.min(right.1));
        let left_endpoints = (shared as f64 * left.2, (shared + 1) as f64 * left.2);
        let right_endpoints = (shared as f64 * right.2, (shared + 1) as f64 * right.2);
        assert_eq!(left_endpoints, right_endpoints);
        assert_eq!(
            grid_smoothing_delta(left.2, 0.0),
            grid_smoothing_delta(right.2, 0.0)
        );
    }

    #[test]
    fn startup_view_produces_a_bounded_grid_with_labels() {
        let camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        let samples = camera.visible_surface_samples(10, 7);
        let mesh = build_grid_mesh(&camera, 1440, 900, &samples, &TerrainLayer::new());
        assert!(!mesh.vertices.is_empty());
        assert_eq!(mesh.vertices.len() % 6, 0);
        assert!(mesh.vertices.len() <= MAX_VERTICES);
        assert!(!mesh.labels.is_empty());
        let focal_length = 450.0 / (45.0_f64.to_radians() * 0.5).tan();
        let eye_distance = camera.eye_m().length();
        let rim_radius = focal_length * geo::SEMI_MAJOR_M
            / (eye_distance * eye_distance - geo::SEMI_MAJOR_M.powi(2)).sqrt();
        let outermost_grid_point = mesh
            .vertices
            .iter()
            .map(|vertex| {
                let x = vertex.position_px[0] as f64 - 720.0;
                let y = vertex.position_px[1] as f64 - 450.0;
                x.hypot(y)
            })
            .fold(0.0_f64, f64::max);
        assert!(outermost_grid_point > rim_radius * 0.85);
    }

    #[test]
    fn close_view_grid_fits_the_vertex_budget() {
        let mut camera = OrbitCamera::new(PhysicalSize::new(1440, 900));
        camera.focus_terrain_pilot();
        let samples = camera.visible_surface_samples(10, 7);
        let mesh = build_grid_mesh(&camera, 1440, 900, &samples, &TerrainLayer::new());
        assert!(!mesh.vertices.is_empty());
        assert!(mesh.vertices.len() < MAX_VERTICES);
    }
}

impl Graticule {pub fn keeper_visible(&mut self,value:bool){self.target_visible=value;}}
