struct Camera {
    view_projection: mat4x4<f32>,
    eye: vec4<f32>,
};
@group(0) @binding(0) var<uniform> camera: Camera;
@group(1) @binding(0) var tile_texture: texture_2d<f32>;
@group(1) @binding(1) var tile_sampler: sampler;
struct TileOffset { relative_origin: vec4<f32>, };
@group(1) @binding(2) var<uniform> tile_offset: TileOffset;
struct VertexInput {
    @location(0) position: vec3<f32>,
    @location(1) normal: vec3<f32>,
    @location(2) uv: vec2<f32>,
};
struct VertexOutput {
    @builtin(position) clip_position: vec4<f32>,
    @location(0) uv: vec2<f32>,
    @location(1) normal: vec3<f32>,
    @location(2) position_from_eye: vec3<f32>,
};
@vertex
fn vs_main(input: VertexInput) -> VertexOutput {
    var out: VertexOutput;
    out.position_from_eye = input.position + tile_offset.relative_origin.xyz;
    out.clip_position = camera.view_projection * vec4(out.position_from_eye, 1.0);
    out.normal = input.normal;
    out.uv = input.uv;
    return out;
}
fn safe_normalize(value: vec3<f32>) -> vec3<f32> {
    return value * inverseSqrt(max(dot(value, value), 1e-20));
}
@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    let color = textureSample(tile_texture, tile_sampler, input.uv);
    if color.a < 0.001 { discard; }
    let view = safe_normalize(-input.position_from_eye);
    var normal = safe_normalize(input.normal);
    // The existing renderer is two-sided; keep mirrored/back faces consistently lit.
    if dot(normal, view) < 0.0 { normal = -normal; }
    let light = normalize(vec3<f32>(0.5, 0.8, 0.35));
    let diffuse = max(dot(normal, light), 0.0);
    let fill = max(dot(normal, view), 0.0);
    let half_vector = safe_normalize(light + view);
    let specular = pow(max(dot(normal, half_vector), 0.0), 32.0) * 0.10 * diffuse;
    // Work in linear RGB: texture sampling and target encoding handle sRGB.
    let lit = color.rgb * (0.24 + 0.72 * diffuse + 0.16 * fill) + vec3<f32>(specular);
    return vec4<f32>(lit, color.a);
}
