struct Camera { view_projection: mat4x4<f32>, eye: vec4<f32>, };
@group(0) @binding(0) var<uniform> camera: Camera;
@group(1) @binding(0) var tile_texture: texture_2d<f32>;
@group(1) @binding(1) var tile_sampler: sampler;
struct TileOffset { relative_origin: vec4<f32>, base_color_factor: vec4<f32>, pbr: vec4<f32>, };
@group(1) @binding(2) var<uniform> tile_offset: TileOffset;
@group(1) @binding(3) var normal_texture: texture_2d<f32>;
@group(1) @binding(4) var normal_sampler: sampler;
@group(1) @binding(5) var material_texture: texture_2d<f32>;
@group(1) @binding(6) var material_sampler: sampler;
struct VertexInput {
    @location(0) position: vec3<f32>, @location(1) normal: vec3<f32>,
    @location(2) uv: vec2<f32>, @location(3) normal_uv: vec2<f32>, @location(4) material_uv: vec2<f32>,
};
struct VertexOutput {
    @builtin(position) clip_position: vec4<f32>, @location(0) uv: vec2<f32>,
    @location(1) normal: vec3<f32>, @location(2) position_from_eye: vec3<f32>,
    @location(3) normal_uv: vec2<f32>, @location(4) material_uv: vec2<f32>,
};
@vertex fn vs_main(input: VertexInput) -> VertexOutput {
    var out: VertexOutput;
    out.position_from_eye = input.position + tile_offset.relative_origin.xyz;
    out.clip_position = camera.view_projection * vec4(out.position_from_eye, 1.0);
    out.normal=input.normal;out.uv=input.uv;out.normal_uv=input.normal_uv;out.material_uv=input.material_uv;
    return out;
}
fn safe_normalize(value: vec3<f32>) -> vec3<f32> {return value*inverseSqrt(max(dot(value,value),1e-20));}
@fragment fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    // Sample and differentiate before divergent control flow (also supported by WebGL2).
    let color=textureSample(tile_texture,tile_sampler,input.uv)*tile_offset.base_color_factor;
    let mr=textureSample(material_texture,material_sampler,input.material_uv);
    let mapped=textureSample(normal_texture,normal_sampler,input.normal_uv).xyz*2.0-1.0;
    let px=dpdx(input.position_from_eye)*6378137.0;let py=dpdy(input.position_from_eye)*6378137.0;
    let ux=dpdx(input.normal_uv);let uy=dpdy(input.normal_uv);
    let determinant=ux.x*uy.y-ux.y*uy.x;
    let divisor=select(-1.0,1.0,determinant>=0.0)*max(abs(determinant),1e-8);
    let view=safe_normalize(-input.position_from_eye);
    var normal=safe_normalize(input.normal);
    if dot(normal,view)<0.0 {normal=-normal;}
    if abs(determinant)>1e-8 && tile_offset.pbr.z!=0.0 {
        let raw_t=(px*uy.y-py*ux.y)/divisor;let raw_b=(py*ux.x-px*uy.x)/divisor;
        let tangent=safe_normalize(raw_t-normal*dot(normal,raw_t));
        let handedness=select(-1.0,1.0,dot(cross(normal,tangent),raw_b)>=0.0);
        let bitangent=cross(normal,tangent)*handedness;
        let n=safe_normalize(vec3(mapped.xy*tile_offset.pbr.z,mapped.z));
        if dot(tangent,tangent)>0.5 {normal=safe_normalize(tangent*n.x+bitangent*n.y+normal*n.z);}
    }
    if color.a<0.001 {discard;}
    // glTF metallic-roughness: green=roughness, blue=metallic, both linear.
    let metallic=clamp(mr.b*tile_offset.pbr.x,0.0,1.0);
    let roughness=clamp(mr.g*tile_offset.pbr.y,0.045,1.0);
    let light=normalize(vec3<f32>(0.5,0.8,0.35));let half_vector=safe_normalize(light+view);
    let nl=max(dot(normal,light),0.0);let nv=max(dot(normal,view),0.001);
    let nh=max(dot(normal,half_vector),0.0);let vh=max(dot(view,half_vector),0.0);
    let f0=mix(vec3<f32>(0.04),color.rgb,metallic);
    let fresnel=f0+(vec3<f32>(1.0)-f0)*pow(1.0-vh,5.0);
    let alpha=roughness*roughness;let a2=alpha*alpha;
    let denominator=nh*nh*(a2-1.0)+1.0;
    let distribution=a2/max(3.14159265*denominator*denominator,1e-7);
    let k=(roughness+1.0)*(roughness+1.0)/8.0;
    let visibility=(nl/(nl*(1.0-k)+k))*(nv/(nv*(1.0-k)+k));
    let specular=fresnel*distribution*visibility/max(4.0*nl*nv,1e-5);
    let diffuse=(vec3<f32>(1.0)-fresnel)*(1.0-metallic)*color.rgb/3.14159265;
    // Simple ambient fill; no environment reflections or transmission yet.
    let ambient=color.rgb*(0.20+0.12*nv)*(1.0-0.5*metallic);
    return vec4<f32>(ambient+(diffuse+specular)*nl*2.6,color.a);
}
