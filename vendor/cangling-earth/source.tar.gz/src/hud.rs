use crate::{
    graticule::GridLabel,
    navigation::{NavLayout, ScaleBar},
    placenames::{LabelKind, PlaceLabel},
};
use anyhow::{Context, Result};
use bytemuck::{Pod, Zeroable};
use glam::Vec2;
use glyphon::{
    Attrs, Buffer, Cache, Color, Family, FontSystem, Metrics, Resolution, Shaping, Style,
    SwashCache, TextArea, TextAtlas, TextBounds, TextRenderer, Viewport, Weight,
};
use wgpu::util::DeviceExt;

const HELP_ROWS: [(&str, &str); 14] = [
    ("方向键", "平移地图"),
    ("W / S", "向上 / 向下平移"),
    ("A / D", "绕中心旋转"),
    ("Q / E", "调整倾角"),
    ("+ / -", "放大 / 缩小"),
    ("H", "飞回西安"),
    ("N", "正北朝上"),
    ("G", "显示 / 隐藏经纬网格"),
    ("B", "显示 / 隐藏行政区划边界"),
    ("M", "切换影像"),
    ("T", "聚焦地形"),
    ("R", "切换巡航"),
    ("F1", "关闭帮助"),
    ("鼠标", "左键拖动 / 中键平移 / 右键旋转 / 滚轮缩放"),
];

#[repr(C)]
#[derive(Clone, Copy, Pod, Zeroable)]
struct HelpPanelUniform {
    viewport: [f32; 4],
    rect: [f32; 4],
}

struct HelpPanel {
    pipeline: wgpu::RenderPipeline,
    bind_group: wgpu::BindGroup,
    uniform: wgpu::Buffer,
}

impl HelpPanel {
    fn new(device: &wgpu::Device, format: wgpu::TextureFormat) -> Self {
        let uniform = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("help panel uniform"),
            contents: bytemuck::bytes_of(&HelpPanelUniform {
                viewport: [1.0, 1.0, 0.0, 0.0],
                rect: [0.0, 0.0, 620.0, 516.0],
            }),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("help panel layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX_FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("help panel bind group"),
            layout: &bind_group_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: uniform.as_entire_binding(),
            }],
        });
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("help panel shader"),
            source: wgpu::ShaderSource::Wgsl(include_str!("help_panel.wgsl").into()),
        });
        let layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("help panel pipeline layout"),
            bind_group_layouts: &[Some(&bind_group_layout)],
            immediate_size: 0,
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("help panel pipeline"),
            layout: Some(&layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_main"),
                buffers: &[],
                compilation_options: Default::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: Default::default(),
            multiview_mask: None,
            cache: None,
        });
        Self {
            pipeline,
            bind_group,
            uniform,
        }
    }

    fn update(&self, queue: &wgpu::Queue, width: u32, height: u32, rect: [f32; 4]) {
        queue.write_buffer(
            &self.uniform,
            0,
            bytemuck::bytes_of(&HelpPanelUniform {
                viewport: [width.max(1) as f32, height.max(1) as f32, 0.0, 0.0],
                rect,
            }),
        );
    }

    fn draw<'a>(&'a self, pass: &mut wgpu::RenderPass<'a>) {
        pass.set_pipeline(&self.pipeline);
        pass.set_bind_group(0, &self.bind_group, &[]);
        pass.draw(0..6, 0..1);
    }
}

pub struct Hud {
    font_system: FontSystem,
    swash_cache: SwashCache,
    viewport: Viewport,
    atlas: TextAtlas,
    renderer: TextRenderer,
    logo: Buffer,
    attribution: Buffer,
    attribution_text: String,
    #[cfg(target_arch = "wasm32")]
    cache_label: Buffer,
    #[cfg(target_arch = "wasm32")]
    cache_text: String,
    scale_label: Buffer,
    scale_text: String,
    altitude_label: Buffer,
    altitude_text: String,
    fps_label: Buffer,
    fps_text: String,
    grid_labels: Vec<GridLabel>,
    grid_buffers: Vec<Buffer>,
    place_labels: Vec<PlaceLabel>,
    place_buffers: Vec<Buffer>,
    country_font_family: &'static str,
    help_visible: bool,
    help_panel: HelpPanel,
    help_title: Buffer,
    help_keys: Vec<Buffer>,
    help_descriptions: Vec<Buffer>,
}

impl Hud {
    pub fn new(
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        surface_format: wgpu::TextureFormat,
    ) -> Self {
        let mut font_system = FontSystem::new_with_fonts([
            glyphon::fontdb::Source::Binary(std::sync::Arc::new(include_bytes!(
                "../assets/DejaVuSans-BoldOblique.ttf"
            ))),
            glyphon::fontdb::Source::Binary(std::sync::Arc::new(include_bytes!(
                "../assets/DejaVuSansMono.ttf"
            ))),
            glyphon::fontdb::Source::Binary(std::sync::Arc::new(include_bytes!(
                "../assets/CanglingHudCjk.otf"
            ))),
            glyphon::fontdb::Source::Binary(std::sync::Arc::new(include_bytes!(
                "../assets/CanglingPlaceNamesCjk.otf"
            ))),
        ]);
        #[cfg(not(target_arch = "wasm32"))]
        let country_font_family = load_local_country_font(&mut font_system);
        #[cfg(target_arch = "wasm32")]
        let country_font_family = "Noto Sans CJK SC";
        let swash_cache = SwashCache::new();
        let cache = Cache::new(device);
        let viewport = Viewport::new(device, &cache);
        let mut atlas = TextAtlas::new(device, queue, &cache, surface_format);
        let renderer =
            TextRenderer::new(&mut atlas, device, wgpu::MultisampleState::default(), None);
        let mut logo = Buffer::new(&mut font_system, Metrics::new(35.0, 48.0));
        logo.set_size(Some(600.0), Some(52.0));
        logo.set_text(
            "CANGLING EARTH",
            &Attrs::new()
                .family(Family::Name("DejaVu Sans"))
                .weight(Weight::BOLD)
                .style(Style::Oblique),
            Shaping::Advanced,
            None,
        );
        logo.shape_until_scroll(&mut font_system, false);
        let attribution = Buffer::new(&mut font_system, Metrics::new(12.0, 16.0));
        #[cfg(target_arch = "wasm32")]
        let cache_label = Buffer::new(&mut font_system, Metrics::new(12.0, 16.0));
        let scale_label = Buffer::new(&mut font_system, Metrics::new(13.0, 18.0));
        let altitude_label = Buffer::new(&mut font_system, Metrics::new(13.0, 18.0));
        let fps_label = Buffer::new(&mut font_system, Metrics::new(15.0, 20.0));
        let help_panel = HelpPanel::new(device, surface_format);
        let help_attrs = Attrs::new().family(Family::Name("Noto Sans CJK SC"));
        let mut help_title = Buffer::new(&mut font_system, Metrics::new(22.0, 30.0));
        help_title.set_size(Some(560.0), Some(36.0));
        help_title.set_text(
            "Cangling Earth · 按键说明",
            &help_attrs,
            Shaping::Advanced,
            None,
        );
        help_title.shape_until_scroll(&mut font_system, false);
        let mut help_keys = Vec::with_capacity(HELP_ROWS.len());
        let mut help_descriptions = Vec::with_capacity(HELP_ROWS.len());
        for (key, description) in HELP_ROWS {
            let mut key_buffer = Buffer::new(&mut font_system, Metrics::new(16.0, 24.0));
            key_buffer.set_size(Some(145.0), Some(28.0));
            key_buffer.set_text(key, &help_attrs, Shaping::Advanced, None);
            key_buffer.shape_until_scroll(&mut font_system, false);
            help_keys.push(key_buffer);
            let mut description_buffer = Buffer::new(&mut font_system, Metrics::new(16.0, 24.0));
            description_buffer.set_size(Some(430.0), Some(28.0));
            description_buffer.set_text(description, &help_attrs, Shaping::Advanced, None);
            description_buffer.shape_until_scroll(&mut font_system, false);
            help_descriptions.push(description_buffer);
        }
        Self {
            font_system,
            swash_cache,
            viewport,
            atlas,
            renderer,
            logo,
            attribution,
            attribution_text: String::new(),
            #[cfg(target_arch = "wasm32")]
            cache_label,
            #[cfg(target_arch = "wasm32")]
            cache_text: String::new(),
            scale_label,
            scale_text: String::new(),
            altitude_label,
            altitude_text: String::new(),
            fps_label,
            fps_text: String::new(),
            grid_labels: Vec::new(),
            grid_buffers: Vec::new(),
            place_labels: Vec::new(),
            place_buffers: Vec::new(),
            country_font_family,
            help_visible: false,
            help_panel,
            help_title,
            help_keys,
            help_descriptions,
        }
    }

    pub fn toggle_help(&mut self) {
        self.help_visible = !self.help_visible;
    }

    pub fn set_grid_labels(&mut self, labels: &[GridLabel]) {
        while self.grid_buffers.len() < labels.len() {
            let mut buffer = Buffer::new(&mut self.font_system, Metrics::new(16.0, 22.0));
            buffer.set_size(Some(160.0), Some(26.0));
            self.grid_buffers.push(buffer);
        }
        for (index, label) in labels.iter().enumerate() {
            if self
                .grid_labels
                .get(index)
                .is_some_and(|old| old.text == label.text)
            {
                continue;
            }
            let buffer = &mut self.grid_buffers[index];
            buffer.set_text(
                &label.text,
                &Attrs::new().family(Family::Monospace),
                Shaping::Advanced,
                None,
            );
            buffer.shape_until_scroll(&mut self.font_system, false);
        }
        self.grid_labels = labels.to_vec();
    }

    pub fn set_place_labels(&mut self, labels: &[PlaceLabel]) {
        while self.place_buffers.len() < labels.len() {
            let mut buffer = Buffer::new(&mut self.font_system, Metrics::new(17.0, 24.0));
            buffer.set_size(Some(240.0), Some(26.0));
            self.place_buffers.push(buffer);
        }
        for (index, label) in labels.iter().enumerate() {
            if self
                .place_labels
                .get(index)
                .is_some_and(|old| old.text == label.text && old.kind == label.kind)
            {
                continue;
            }
            let buffer = &mut self.place_buffers[index];
            let country = label.kind == LabelKind::Country;
            buffer.set_metrics(if country {
                Metrics::new(22.0, 30.0)
            } else {
                Metrics::new(17.0, 24.0)
            });
            buffer.set_size(Some(if country { 300.0 } else { 240.0 }), Some(32.0));
            buffer.set_text(
                &label.text,
                &Attrs::new()
                    .family(Family::Name(if country {
                        self.country_font_family
                    } else {
                        "Noto Sans CJK SC"
                    }))
                    .weight(if country {
                        Weight::MEDIUM
                    } else {
                        Weight::NORMAL
                    }),
                Shaping::Advanced,
                None,
            );
            buffer.shape_until_scroll(&mut self.font_system, false);
        }
        self.place_labels = labels.to_vec();
    }

    pub fn set_navigation_readout(
        &mut self,
        scale: Option<ScaleBar>,
        eye_height_m: f64,
        eye_clearance_m: f64,
    ) {
        let scale_text = scale.map(ScaleBar::label).unwrap_or_default();
        if scale_text != self.scale_text {
            self.scale_text = scale_text;
            self.scale_label.set_size(Some(150.0), Some(18.0));
            self.scale_label.set_text(
                &self.scale_text,
                &Attrs::new().family(Family::Name("Cangling HUD CJK")),
                Shaping::Advanced,
                None,
            );
            self.scale_label
                .shape_until_scroll(&mut self.font_system, false);
        }
        let mut altitude_text = if eye_height_m >= 1_000.0 {
            if eye_height_m >= 100_000.0 {
                format!("高度 {:.0} 公里", eye_height_m / 1_000.0)
            } else {
                format!("高度 {:.1} 公里", eye_height_m / 1_000.0)
            }
        } else {
            format!("高度 {:.0} 米", eye_height_m)
        };
        if eye_height_m - eye_clearance_m > 100.0 && eye_clearance_m < 100_000.0 {
            let clearance = if eye_clearance_m >= 1_000.0 {
                format!("{:.1} km", eye_clearance_m / 1_000.0)
            } else {
                format!("{:.0} m", eye_clearance_m)
            };
            altitude_text.push_str(&format!(" / 离地 {clearance}"));
        }
        if altitude_text != self.altitude_text {
            self.altitude_text = altitude_text;
            self.altitude_label.set_size(Some(205.0), Some(18.0));
            self.altitude_label.set_text(
                &self.altitude_text,
                &Attrs::new().family(Family::Name("Cangling HUD CJK")),
                Shaping::Advanced,
                None,
            );
            self.altitude_label
                .shape_until_scroll(&mut self.font_system, false);
        }
    }

    pub fn set_attribution(&mut self, source: &str) {
        let text = format!("{source} | DEM: NOAA NCEI / Copernicus GLO-30 © DLR/Airbus");
        if text == self.attribution_text {
            return;
        }
        self.attribution_text = text;
        self.attribution.set_size(Some(600.0), Some(20.0));
        self.attribution.set_text(
            &self.attribution_text,
            &Attrs::new().family(Family::Monospace),
            Shaping::Advanced,
            None,
        );
        self.attribution
            .shape_until_scroll(&mut self.font_system, false);
    }

    pub fn set_fps(&mut self, fps: f32) {
        let text = format!("FPS {:.0}", fps);
        if text == self.fps_text {
            return;
        }
        self.fps_text = text;
        self.fps_label.set_size(Some(100.0), Some(20.0));
        self.fps_label.set_text(
            &self.fps_text,
            &Attrs::new().family(Family::Monospace),
            Shaping::Advanced,
            None,
        );
        self.fps_label
            .shape_until_scroll(&mut self.font_system, false);
    }

    #[cfg(target_arch = "wasm32")]
    pub fn set_cache_usage(&mut self, bytes: Option<u64>) {
        let Some(bytes) = bytes else {
            return;
        };
        let text = if bytes < 1024 * 1024 {
            format!("站点缓存约 {:.0} KB", bytes as f64 / 1024.0)
        } else {
            format!("站点缓存约 {:.1} MB", bytes as f64 / (1024.0 * 1024.0))
        };
        if text == self.cache_text {
            return;
        }
        self.cache_text = text;
        self.cache_label.set_size(Some(250.0), Some(20.0));
        self.cache_label.set_text(
            &self.cache_text,
            &Attrs::new().family(Family::Name("Cangling HUD CJK")),
            Shaping::Advanced,
            None,
        );
        self.cache_label
            .shape_until_scroll(&mut self.font_system, false);
    }

    pub fn prepare(
        &mut self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        width: u32,
        height: u32,
    ) -> Result<()> {
        self.viewport.update(queue, Resolution { width, height });
        let nav = NavLayout::new(width, height);
        let logo_scale = ((width as f32 - 48.0) / 420.0).clamp(0.3, 1.0);
        let attribution_scale = ((nav.origin.x - 36.0) / 420.0).clamp(0.3, 1.0);
        let logo_bounds = TextBounds {
            left: 0,
            top: 0,
            right: width as i32,
            bottom: height as i32,
        };
        let bounds = TextBounds {
            left: 0,
            top: 0,
            right: (nav.origin.x - 12.0).max(0.0) as i32,
            bottom: height as i32,
        };
        let readout_bounds = TextBounds {
            left: (nav.origin.x - 215.0 * nav.scale).max(0.0) as i32,
            top: 0,
            right: (nav.origin.x - 12.0 * nav.scale).max(0.0) as i32,
            bottom: height as i32,
        };
        let readout_left = nav.origin.x - 150.0 * nav.scale;
        let mut text_areas = vec![
            TextArea {
                buffer: &self.logo,
                left: 24.0,
                top: 16.0,
                scale: logo_scale,
                bounds: logo_bounds,
                default_color: Color::rgb(255, 255, 255),
                custom_glyphs: &[],
            },
            TextArea {
                buffer: &self.attribution,
                left: 24.0,
                top: height.saturating_sub(24) as f32,
                scale: attribution_scale,
                bounds,
                default_color: Color::rgb(218, 226, 235),
                custom_glyphs: &[],
            },
            TextArea {
                buffer: &self.scale_label,
                left: readout_left,
                top: nav.origin.y + 7.0 * nav.scale,
                scale: nav.scale,
                bounds: readout_bounds,
                default_color: Color::rgb(255, 255, 255),
                custom_glyphs: &[],
            },
            TextArea {
                buffer: &self.altitude_label,
                left: readout_left,
                top: nav.origin.y + 46.0 * nav.scale,
                scale: nav.scale,
                bounds: readout_bounds,
                default_color: Color::rgb(235, 242, 240),
                custom_glyphs: &[],
            },
        ];
        if !self.fps_text.is_empty() {
            let text_width = self
                .fps_label
                .layout_runs()
                .next()
                .map_or(0.0, |run| run.line_w);
            text_areas.push(TextArea {
                buffer: &self.fps_label,
                left: width as f32 - 18.0 * nav.scale - text_width * nav.scale,
                top: nav.origin.y - 26.0 * nav.scale,
                scale: nav.scale,
                bounds: logo_bounds,
                default_color: Color::rgb(235, 242, 240),
                custom_glyphs: &[],
            });
        }
        #[cfg(target_arch = "wasm32")]
        if !self.cache_text.is_empty() {
            text_areas.push(TextArea {
                buffer: &self.cache_label,
                left: 24.0,
                top: height.saturating_sub(43) as f32,
                scale: attribution_scale,
                bounds,
                default_color: Color::rgb(218, 226, 235),
                custom_glyphs: &[],
            });
        }
        for (label, buffer) in self.grid_labels.iter().zip(&self.grid_buffers) {
            let alpha = (label.opacity.clamp(0.0, 1.0) * 255.0).round() as u8;
            for (offset, color) in [
                (Vec2::new(1.0, 1.0), Color::rgba(4, 10, 20, alpha)),
                (Vec2::ZERO, Color::rgba(240, 248, 255, alpha)),
            ] {
                text_areas.push(TextArea {
                    buffer,
                    left: label.position.x + offset.x,
                    top: label.position.y + offset.y,
                    scale: 1.0,
                    bounds: logo_bounds,
                    default_color: color,
                    custom_glyphs: &[],
                });
            }
        }
        for (label, buffer) in self.place_labels.iter().zip(&self.place_buffers) {
            let left = if matches!(
                label.kind,
                LabelKind::Country | LabelKind::Province | LabelKind::Region | LabelKind::Township
            ) {
                label.position.x - buffer.layout_runs().next().map_or(0.0, |run| run.line_w) * 0.5
            } else {
                label.position.x
            };
            if label.kind == LabelKind::Province {
                // A soft golden text halo keeps province names legible on both
                // bright terrain and dark imagery without a rectangular badge.
                for (offset, alpha) in [
                    (Vec2::new(-2.0, 0.0), 70),
                    (Vec2::new(2.0, 0.0), 70),
                    (Vec2::new(0.0, -2.0), 70),
                    (Vec2::new(0.0, 2.0), 70),
                    (Vec2::new(-1.0, -1.0), 115),
                    (Vec2::new(1.0, -1.0), 115),
                    (Vec2::new(-1.0, 1.0), 115),
                    (Vec2::new(1.0, 1.0), 115),
                ] {
                    text_areas.push(TextArea {
                        buffer,
                        left: left + offset.x,
                        top: label.position.y + offset.y,
                        scale: 1.0,
                        bounds: logo_bounds,
                        default_color: Color::rgba(255, 210, 64, alpha),
                        custom_glyphs: &[],
                    });
                }
            }
            let alpha = if label.kind == LabelKind::Township {
                153
            } else {
                255
            };
            for (offset, color) in [
                (Vec2::new(1.0, 1.0), Color::rgba(4, 10, 20, alpha)),
                (Vec2::ZERO, Color::rgba(255, 255, 255, alpha)),
            ] {
                text_areas.push(TextArea {
                    buffer,
                    left: left + offset.x,
                    top: label.position.y + offset.y,
                    scale: 1.0,
                    bounds: logo_bounds,
                    default_color: color,
                    custom_glyphs: &[],
                });
            }
        }
        if self.help_visible {
            text_areas.clear();
            let scale = (width as f32 / 660.0)
                .min(height as f32 / 556.0)
                .min(1.0)
                .max(0.01);
            let panel_width = 620.0 * scale;
            let panel_height = 516.0 * scale;
            let left = (width as f32 - panel_width) * 0.5;
            let top = (height as f32 - panel_height) * 0.5;
            self.help_panel
                .update(queue, width, height, [left, top, panel_width, panel_height]);
            text_areas.push(TextArea {
                buffer: &self.help_title,
                left: left + 26.0 * scale,
                top: top + 22.0 * scale,
                scale,
                bounds: logo_bounds,
                default_color: Color::rgb(255, 255, 255),
                custom_glyphs: &[],
            });
            for (index, (key, description)) in self
                .help_keys
                .iter()
                .zip(&self.help_descriptions)
                .enumerate()
            {
                let row_top = top + (70.0 + index as f32 * 30.0) * scale;
                text_areas.push(TextArea {
                    buffer: key,
                    left: left + 28.0 * scale,
                    top: row_top,
                    scale,
                    bounds: logo_bounds,
                    default_color: Color::rgb(172, 210, 245),
                    custom_glyphs: &[],
                });
                text_areas.push(TextArea {
                    buffer: description,
                    left: left + 175.0 * scale,
                    top: row_top,
                    scale,
                    bounds: logo_bounds,
                    default_color: Color::rgb(235, 242, 250),
                    custom_glyphs: &[],
                });
            }
        }
        self.renderer
            .prepare(
                device,
                queue,
                &mut self.font_system,
                &mut self.atlas,
                &self.viewport,
                text_areas,
                &mut self.swash_cache,
            )
            .context("prepare HUD text")
    }

    pub fn render<'pass>(&'pass self, pass: &mut wgpu::RenderPass<'pass>) -> Result<()> {
        self.renderer
            .render(&self.atlas, &self.viewport, pass)
            .context("render HUD text")
    }

    pub fn render_background<'pass>(&'pass self, pass: &mut wgpu::RenderPass<'pass>) {
        if self.help_visible {
            self.help_panel.draw(pass);
        }
    }

    pub fn trim(&mut self) {
        self.atlas.trim();
    }
}

/// Use the user's unmodified Alibaba PuHuiTi installation when available.
/// The font file is deliberately not copied into the project or Web bundle.
#[cfg(not(target_arch = "wasm32"))]
fn load_local_country_font(font_system: &mut FontSystem) -> &'static str {
    use std::path::PathBuf;

    let mut paths: Vec<PathBuf> = std::env::var_os("CANGLING_COUNTRY_FONT")
        .map(PathBuf::from)
        .into_iter()
        .collect();
    if let Some(home) = dirs::home_dir() {
        paths.push(home.join(".local/share/fonts/AlibabaPuHuiTi-3-55-Regular.ttf"));
        paths.push(home.join(".fonts/AlibabaPuHuiTi-3-55-Regular.ttf"));
    }
    for path in paths {
        if !path.is_file() {
            continue;
        }
        if let Err(error) = font_system.db_mut().load_font_file(&path) {
            log::warn!("could not load country font {}: {error}", path.display());
            continue;
        }
        if font_system.db().faces().any(|face| {
            face.families
                .iter()
                .any(|(family, _)| family == "Alibaba PuHuiTi 3.0")
        }) {
            return "Alibaba PuHuiTi 3.0";
        }
    }
    "Noto Sans CJK SC"
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn help_panel_shader_validates() {
        let module = naga::front::wgsl::parse_str(include_str!("help_panel.wgsl"))
            .expect("help panel shader parses");
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::all(),
        )
        .validate(&module)
        .expect("help panel shader validates");
    }

    #[cfg(not(target_arch = "wasm32"))]
    #[test]
    fn help_panel_pipeline_passes_device_validation() {
        let instance = wgpu::Instance::default();
        let Ok(adapter) = pollster::block_on(instance.request_adapter(&Default::default())) else {
            return;
        };
        let (device, queue) = pollster::block_on(adapter.request_device(&Default::default()))
            .expect("request a device for help panel validation");
        let error_scope = device.push_error_scope(wgpu::ErrorFilter::Validation);
        let _hud = Hud::new(&device, &queue, wgpu::TextureFormat::Rgba8UnormSrgb);
        assert!(pollster::block_on(error_scope.pop()).is_none());
    }
}
