//! Browser-owned persistent tile cache. Fetch still obeys normal CORS rules.

use anyhow::{Context, Result, anyhow};
use js_sys::{Array, Function, Promise, Reflect, Uint8Array};
use wasm_bindgen::{JsCast, JsValue};
use wasm_bindgen_futures::JsFuture;
use web_sys::{Cache, Request, Response};

pub async fn fetch_bytes(url: &str, cache_name: &str) -> Result<(Vec<u8>, bool)> {
    let window = web_sys::window().context("browser window is unavailable")?;
    // The page launcher installs a Worker bridge before starting WASM. Keep
    // the direct path for hosts embedding the library without that launcher.
    if let Ok(value) = Reflect::get(&window, &JsValue::from_str("canglingDataFetch"))
        && let Ok(fetch) = value.dyn_into::<Function>()
    {
        let promise = fetch
            .call2(
                &window,
                &JsValue::from_str(url),
                &JsValue::from_str(cache_name),
            )
            .map_err(js_error)?;
        let promise: Promise = promise.dyn_into().map_err(js_error)?;
        let result = JsFuture::from(promise).await.map_err(js_error)?;
        let bytes = Reflect::get(&result, &JsValue::from_str("bytes")).map_err(js_error)?;
        let hit = Reflect::get(&result, &JsValue::from_str("hit"))
            .map_err(js_error)?
            .as_bool()
            .unwrap_or(false);
        return Ok((Uint8Array::new(&bytes).to_vec(), hit));
    }
    let mutable_imagery = cache_name.starts_with("cangling-imagery-agri-");
    let options = web_sys::RequestInit::new();
    if mutable_imagery { options.set_cache(web_sys::RequestCache::NoCache); }
    let request = Request::new_with_str_and_init(url, &options).map_err(js_error)?;

    // CacheStorage requires a secure context. A missing cache must not prevent
    // live tiles from rendering when the browser still permits network fetch.
    let cache = match window.caches() {
        _ if cache_name.is_empty() || mutable_imagery => None,
        Ok(storage) => JsFuture::from(storage.open(cache_name))
            .await
            .ok()
            .and_then(|value| value.dyn_into::<Cache>().ok()),
        Err(_) => None,
    };
    if let Some(cache) = &cache {
        if let Ok(value) = JsFuture::from(cache.match_with_request(&request)).await {
            if let Ok(response) = value.dyn_into::<Response>() {
                return Ok((response_bytes(&response).await?, true));
            }
        }
    }

    let response = JsFuture::from(window.fetch_with_request(&request))
        .await
        .map_err(js_error)?
        .dyn_into::<Response>()
        .map_err(js_error)?;
    if !response.ok() {
        return Err(anyhow!("tile HTTP status {} for {url}", response.status()));
    }
    if let Some(cache) = cache {
        if let Ok(copy) = response.clone() {
            // Quota or cache policy failures leave the live image usable.
            let _ = JsFuture::from(cache.put_with_request(&request, &copy)).await;
        }
    }
    Ok((response_bytes(&response).await?, false))
}

async fn response_bytes(response: &Response) -> Result<Vec<u8>> {
    let buffer = JsFuture::from(response.array_buffer().map_err(js_error)?)
        .await
        .map_err(js_error)?;
    Ok(Uint8Array::new(&buffer).to_vec())
}

pub async fn storage_usage_bytes() -> Result<u64> {
    let window = web_sys::window().context("browser window is unavailable")?;
    let estimate = JsFuture::from(window.navigator().storage().estimate().map_err(js_error)?)
        .await
        .map_err(js_error)?;
    let usage = Reflect::get(&estimate, &JsValue::from_str("usage"))
        .map_err(js_error)?
        .as_f64()
        .context("browser storage estimate has no usage")?;
    Ok(usage.max(0.0) as u64)
}

pub async fn delete_old_caches(prefix: &str, keep: &str) -> Result<()> {
    let window = web_sys::window().context("browser window is unavailable")?;
    let storage = window.caches().map_err(js_error)?;
    let names = JsFuture::from(storage.keys()).await.map_err(js_error)?;
    for name in Array::from(&names)
        .iter()
        .filter_map(|value| value.as_string())
    {
        if name.starts_with(prefix) && name != keep {
            let _ = JsFuture::from(storage.delete(&name)).await;
        }
    }
    Ok(())
}

pub async fn trim_cache(cache_name: &str, max_entries: u32) -> Result<()> {
    let window = web_sys::window().context("browser window is unavailable")?;
    let storage = window.caches().map_err(js_error)?;
    let cache = JsFuture::from(storage.open(cache_name))
        .await
        .map_err(js_error)?
        .dyn_into::<Cache>()
        .map_err(js_error)?;
    let entries = JsFuture::from(cache.keys()).await.map_err(js_error)?;
    let entries = Array::from(&entries);
    let excess = entries.length().saturating_sub(max_entries);
    for index in 0..excess {
        if let Ok(request) = entries.get(index).dyn_into::<Request>() {
            let _ = JsFuture::from(cache.delete_with_request(&request)).await;
        }
    }
    Ok(())
}

fn js_error(value: JsValue) -> anyhow::Error {
    anyhow!("browser operation failed: {value:?}")
}
