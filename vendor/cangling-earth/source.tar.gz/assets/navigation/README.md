# Navigation HUD design assets

These SVGs and PNGs record the earlier sprite design. The current desktop and
browser renderer draws the compass, bars and red grips directly in
`src/navigation.wgsl` at screen resolution. It does not load these PNGs, because
scaling small raster art softened the ring and grip detail. The SVGs remain as
editable design references.

Regenerate all SVG design PNGs from the project root:

```bash
./scripts/svg-to-png.sh
```

The archived SVG and raster sizes match the earlier logical screen dimensions:
44×44 dial, 10×32 needle, 146×14 track, and 10×10 thumb. Rasterize these
references directly at those sizes if needed; the live HUD no longer samples
them.
