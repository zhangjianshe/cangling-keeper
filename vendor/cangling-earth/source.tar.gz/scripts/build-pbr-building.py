#!/usr/bin/env python3
"""Original PBR regression fixture derived from the textured building."""
import runpy,json,struct,pathlib,math
module=runpy.run_path('scripts/build-textured-building.py')
raw=pathlib.Path('assets/textured-building.glb').read_bytes();length=struct.unpack_from('<I',raw,12)[0]
doc=json.loads(raw[20:20+length]);blob=bytearray(raw[28+length:])
def append(data):
    offset=len(blob);blob.extend(data);blob.extend(b'\0'*(-len(blob)%4));doc['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':len(data)});return len(doc['bufferViews'])-1
def texture(pixel):
    rows=b''.join(b'\0'+b''.join(bytes(pixel(x,y)) for x in range(64)) for y in range(64))
    chunk=module['png_chunk'];png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',64,64,8,6,0,0,0))+chunk(b'IDAT',module['zlib'].compress(rows))+chunk(b'IEND',b'')
    image=len(doc['images']);doc['images'].append({'bufferView':append(png),'mimeType':'image/png'})
    index=len(doc['textures']);doc['textures'].append({'source':image,'sampler':0});return index
normal=texture(lambda x,y:(round(128+70*math.sin(x*math.pi/16)),128,round(128+math.sqrt(127**2-(70*math.sin(x*math.pi/16))**2)),255))
mr=texture(lambda x,y:(255,45 if 12<x<52 and 10<y<51 else 220,0,255))
for primitive in doc['meshes'][0]['primitives']:
    a=doc['accessors'][primitive['attributes']['TEXCOORD_0']];v=doc['bufferViews'][a['bufferView']]
    values=struct.unpack_from('<'+'f'*a['count']*2,blob,v['byteOffset'])
    view=append(struct.pack('<'+'f'*len(values),*(x*2 for x in values)))
    primitive['attributes']['TEXCOORD_1']=len(doc['accessors'])
    doc['accessors'].append({'bufferView':view,'componentType':5126,'count':a['count'],'type':'VEC2'})
wall=doc['materials'][0];wall['normalTexture']={'index':normal,'texCoord':1,'scale':0.6}
wall['pbrMetallicRoughness'].update(metallicFactor=1,roughnessFactor=1,metallicRoughnessTexture={'index':mr})
doc['materials'][1]['pbrMetallicRoughness'].update(metallicFactor=1,roughnessFactor=.25)
doc['buffers'][0]['byteLength']=len(blob);doc['asset']['generator']='Cangling original PBR fixture'
j=json.dumps(doc,separators=(',',':')).encode();j+=b' '*(-len(j)%4)
pathlib.Path('assets/pbr-building.glb').write_bytes(struct.pack('<III',0x46546c67,2,28+len(j)+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob)
