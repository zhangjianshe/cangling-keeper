#!/usr/bin/env python3
"""Generate the original low-poly walker placeholder; metres, Y-up, no external assets."""
import json,struct,pathlib
positions=[];indices=[]
def box(cx,cy,cz,x,y,z):
 corners=[(cx+sx*x/2,cy+sy*y/2,cz+sz*z/2) for sx,sy,sz in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
 for face in [(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)]:
  n=len(positions);positions.extend(corners[i] for i in face);indices.extend([n,n+1,n+2,n,n+2,n+3])
for args in [(0,1.03,0,.48,.58,.26),(0,1.53,0,.28,.34,.28),(-.14,.38,0,.18,.76,.22),(.14,.38,0,.18,.76,.22),(-.34,1.0,0,.15,.62,.19),(.34,1.0,0,.15,.62,.19)]:box(*args)
p=struct.pack('<'+'f'*len(positions)*3,*(v for point in positions for v in point));i=struct.pack('<'+'H'*len(indices),*indices);data=p+i;data+=b'\0'*((-len(data))%4)
doc={'asset':{'version':'2.0','generator':'Cangling procedural walker'},'buffers':[{'byteLength':len(data)}],'bufferViews':[{'buffer':0,'byteOffset':0,'byteLength':len(p)},{'buffer':0,'byteOffset':len(p),'byteLength':len(i)}],'accessors':[{'bufferView':0,'componentType':5126,'count':len(positions),'type':'VEC3','min':[min(v[a] for v in positions) for a in range(3)],'max':[max(v[a] for v in positions) for a in range(3)]},{'bufferView':1,'componentType':5123,'count':len(indices),'type':'SCALAR'}],'materials':[{'pbrMetallicRoughness':{'baseColorFactor':[.12,.48,.95,1],'metallicFactor':0,'roughnessFactor':1}}],'meshes':[{'primitives':[{'attributes':{'POSITION':0},'indices':1,'material':0}]}],'nodes':[{'mesh':0}],'scenes':[{'nodes':[0]}],'scene':0}
j=json.dumps(doc,separators=(',',':')).encode();j+=b' '*((-len(j))%4)
output=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(data))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(data),0x004e4942)+data
pathlib.Path('assets/walker.glb').write_bytes(output)
