#!/usr/bin/env python3
"""Original joint-labelled low-poly walker; metres, Y-up, forward -Z."""
import json,struct,pathlib
positions=[];indices=[];meshes=[];nodes=[];views=[];accessors=[];data=bytearray()
def box(cx,cy,cz,x,y,z):
 corners=[(cx+sx*x/2,cy+sy*y/2,cz+sz*z/2) for sx,sy,sz in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
 for face in [(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)]:
  n=len(positions);positions.extend(corners[i] for i in face);indices.extend([n,n+1,n+2,n,n+2,n+3])
def append(raw):
 offset=len(data);data.extend(raw);data.extend(b'\0'*((-len(data))%4));views.append({'buffer':0,'byteOffset':offset,'byteLength':len(raw)});return len(views)-1
parts=[('torso',(0,1.03,0,.48,.58,.26),0),('head',(0,1.53,0,.28,.34,.28),1),('left_leg',(-.14,.38,0,.18,.76,.22),2),('right_leg',(.14,.38,0,.18,.76,.22),2),('left_arm',(-.34,1.0,0,.15,.62,.19),0),('right_arm',(.34,1.0,0,.15,.62,.19),0),('head',(0,1.56,-.147,.22,.09,.02),3)]
for name,args,material in parts:
 positions=[];indices=[];box(*args)
 p=append(struct.pack('<'+'f'*len(positions)*3,*(v for point in positions for v in point)))
 i=append(struct.pack('<'+'H'*len(indices),*indices));a=len(accessors)
 accessors.extend([{'bufferView':p,'componentType':5126,'count':len(positions),'type':'VEC3','min':[min(v[j] for v in positions) for j in range(3)],'max':[max(v[j] for v in positions) for j in range(3)]},{'bufferView':i,'componentType':5123,'count':len(indices),'type':'SCALAR'}])
 nodes.append({'name':name,'mesh':len(meshes)});meshes.append({'primitives':[{'attributes':{'POSITION':a},'indices':a+1,'material':material}]})
colors=[[.12,.48,.95,1],[.72,.79,.88,1],[.08,.15,.28,1],[.02,.08,.14,1]]
doc={'asset':{'version':'2.0','generator':'Cangling procedural joint walker'},'buffers':[{'byteLength':len(data)}],'bufferViews':views,'accessors':accessors,'materials':[{'pbrMetallicRoughness':{'baseColorFactor':c,'metallicFactor':0,'roughnessFactor':1}} for c in colors],'meshes':meshes,'nodes':nodes,'scenes':[{'nodes':list(range(len(nodes)))}],'scene':0}
j=json.dumps(doc,separators=(',',':')).encode();j+=b' '*((-len(j))%4)
output=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(data))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(data),0x004e4942)+data
pathlib.Path('assets/walker.glb').write_bytes(output)
