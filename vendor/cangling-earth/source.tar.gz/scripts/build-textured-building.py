#!/usr/bin/env python3
"""Original deterministic glTF fixture: repeat-window facade and plain roof."""
import json, pathlib, struct, zlib
blob=bytearray(); views=[]; accessors=[]
def chunk(raw):
    offset=len(blob);blob.extend(raw);blob.extend(b'\0'*(-len(blob)%4));views.append({'buffer':0,'byteOffset':offset,'byteLength':len(raw)});return len(views)-1
def accessor(values, kind, dim):
    raw=struct.pack('<'+'f'*len(values)*dim,*(v for row in values for v in row))
    view=chunk(raw); result={'bufferView':view,'componentType':5126,'count':len(values),'type':kind}
    if kind=='VEC3':result.update(min=[min(p[i] for p in values) for i in range(dim)],max=[max(p[i] for p in values) for i in range(dim)])
    accessors.append(result);return len(accessors)-1
# A single window unit; four columns and three rows are produced by UV repetition.
rows=[]
for y in range(64):
    row=bytearray(b'\0')
    for x in range(64):
        glass=12<x<52 and 10<y<51
        color=(55,120,170,255) if glass else (210,195,170,255)
        if glass and (30<=x<=33 or 29<=y<=32):color=(235,240,245,255)
        row.extend(color)
    rows.append(row)
def png_chunk(kind,data):return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data))
png=b'\x89PNG\r\n\x1a\n'+png_chunk(b'IHDR',struct.pack('>IIBBBBB',64,64,8,6,0,0,0))+png_chunk(b'IDAT',zlib.compress(b''.join(rows)))+png_chunk(b'IEND',b'')
image_view=chunk(png)
faces=[ [(-6,0,4),(6,0,4),(6,9,4),(-6,9,4)], [(6,0,-4),(-6,0,-4),(-6,9,-4),(6,9,-4)], [(-6,0,-4),(-6,0,4),(-6,9,4),(-6,9,-4)], [(6,0,4),(6,0,-4),(6,9,-4),(6,9,4)], [(-6,9,4),(6,9,4),(6,9,-4),(-6,9,-4)] ]
primitives=[]
for i,face in enumerate(faces):
    # Unindexed triangles make the fixture easy to inspect and regenerate.
    order=[0,1,2,0,2,3];uv=[(0,3),(4,3),(4,0),(0,0)]
    p=accessor([face[j] for j in order],'VEC3',3);t=accessor([uv[j] for j in order],'VEC2',2)
    primitives.append({'attributes':{'POSITION':p,'TEXCOORD_0':t},'material':int(i==4)})
doc={'asset':{'version':'2.0','generator':'Cangling original texture fixture'},'buffers':[{'byteLength':len(blob)}],'bufferViews':views,'accessors':accessors,'images':[{'bufferView':image_view,'mimeType':'image/png'}],'samplers':[{'wrapS':10497,'wrapT':10497,'magFilter':9729,'minFilter':9987}],'textures':[{'source':0,'sampler':0}],'materials':[{'pbrMetallicRoughness':{'baseColorTexture':{'index':0},'baseColorFactor':[1,1,1,1]}},{'pbrMetallicRoughness':{'baseColorFactor':[.25,.3,.35,1]}}],'meshes':[{'primitives':primitives}],'nodes':[{'mesh':0}],'scenes':[{'nodes':[0]}],'scene':0}
j=json.dumps(doc,separators=(',',':')).encode();j+=b' '*(-len(j)%4)
out=struct.pack('<III',0x46546c67,2,28+len(j)+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob
pathlib.Path('assets/textured-building.glb').write_bytes(out)
