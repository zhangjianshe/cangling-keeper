#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

if ! command -v wasm-bindgen >/dev/null 2>&1; then
  echo 'wasm-bindgen CLI is required: cargo install wasm-bindgen-cli --version 0.2.129 --locked' >&2
  exit 1
fi

cargo build --release --lib --target wasm32-unknown-unknown --no-default-features --features web
mkdir -p web/pkg
wasm-bindgen target/wasm32-unknown-unknown/release/cangling_desktop.wasm \
  --out-dir web/pkg --target web --no-typescript

echo 'Web build ready: python3 webgpu-check/server.py'
echo 'Backend check and Earth viewer: python3 webgpu-check/server.py'
